#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
const int MAXN = 5100;
typedef long long ll;

int n, m, p;
int fa[MAXN];

int getf(int x){return fa[x] = ((fa[x] == -1 || fa[x] == x) ? x : getf(fa[x]));}

int main(){
	scanf("%d %d %d", &n, &m, &p);
	memset(fa, -1, sizeof(fa));
	for(int mi, mj, i = 1; i <= m; i++){
		scanf("%d %d", &mi, &mj);
		fa[getf(mi)] = getf(mj);
	}
	for(int pi, pj, i = 1; i <= p; i++){
		scanf("%d %d", &pi, &pj);
		printf("%s\n", getf(pi) == getf(pj) ? "Yes" : "No");
	}
	return 0;
}

