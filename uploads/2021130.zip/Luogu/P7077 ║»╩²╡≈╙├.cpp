#include<bits/stdc++.h>
using namespace std;
const int MAXN = 100100;
const int MAXM = 100100;
const int MAXE = 1000100 + MAXM;
const int MAXQ = 100100;
const int MOD = 998244353;
#define mod(x) ((x) % MOD)

struct node{
	int opt, p, v;
	node(int aopt = 0, int ap = 0, int av = 0){
		opt = aopt; p = ap; v = av;
	}
};

int n, m, q;
int a[MAXN], f[MAXM];
node arr[MAXM];
int tot, frt[MAXM], nxt[MAXE], ed[MAXE], indeg[MAXM], oudeg[MAXM];
int vis[MAXN];
vector<int> pref[MAXN];

void add_edge(int u, int v){
	ed[++tot] = v;
	oudeg[u]++;
	indeg[v]++;
	nxt[tot] = frt[u]; frt[u] = tot;
}

void dfs(int u){
	vis[u] = 1;
	if(arr[u].opt == 1){
		pref[u].push_back(1);
		return;
	}else if(arr[u].opt == 2){
		pref[u].push_back(arr[u].v);
		return;
	}else{
		int v;
		pref[u].resize(oudeg[u]);
		for(int cnt = oudeg[u] - 1, i = frt[u]; i; i = nxt[i], cnt--){
			v = ed[i];
			if(!vis[v]) dfs(v);
			pref[u][cnt] = pref[v][0];
		}
		for(int i = oudeg[u] - 2; i + 1; i--){
			pref[u][i] = mod(1ll * pref[u][i] * pref[u][i + 1]);
		}
		return;
	}
}

int main(){
	scanf("%d", &n);
	for(int i = 1; i <= n; i++){
		scanf("%d", &a[i]);
	}
	memset(indeg, 0, sizeof(indeg));
	memset(oudeg, 0, sizeof(oudeg));
	scanf("%d", &m);
	for(int i = 1; i <= m; i++){
		scanf("%d", &arr[i].opt);
		if(arr[i].opt == 1){
			scanf("%d %d", &arr[i].p, &arr[i].v);
		}else if(arr[i].opt == 2){
			scanf("%d", &arr[i].v);
		}else{
			int cj;
			scanf("%d", &cj);
			for(int gji, j = 1; j <= cj; j++){
				scanf("%d", &gji);
				add_edge(i, gji);
			}
		}
	}
	scanf("%d", &q);
	for(int qi, i = 1; i <= q; i++){
		scanf("%d", &qi);
		add_edge(m + 1, qi);
	}
	memset(vis, 0, sizeof(vis));
	dfs(m + 1);
	//debug
//	for(int i = 1; i <= m; i++){
//		printf(":%d(%d): ", i, oudeg[i]);
//		for(int j = 0; j < oudeg[i]; j++){
//			printf("%d ", pref[i][j]);
//		}
//		printf("\n");
//	}
	//-----
	memset(f, 0, sizeof(f));
	f[m + 1] = 1;
	queue<int> que;
	int u, v;
	for(int i = 1; i <= m; i++){
		if(!indeg[i]) que.push(i);
	}
	que.push(m + 1);
	while(!que.empty()){
		u = que.front(); que.pop();
		for(int cnt = oudeg[u] - 1, i = frt[u]; i; i = nxt[i], cnt--){
			v = ed[i];
			if(!(--indeg[v])) que.push(v);
			if(!vis[u]) continue;
			f[v] = mod(1ll * f[v] + 1ll * f[u] * ((cnt < oudeg[u] - 1) ? pref[u][cnt + 1] : 1));
		}
	}
	//debug
//	for(int i = 1; i <= m; i++){
//		printf(":%d: %d\n", i, f[i]);
//	}
	//-----
	for(int i = 1; i <= n; i++){
		a[i] = mod(1ll * a[i] * pref[m + 1][0]);
	}
	for(int i = 1; i <= m; i++){
		if(arr[i].opt == 1){
			a[arr[i].p] = mod(1ll * a[arr[i].p] + 1ll * arr[i].v * f[i]);
		}
	}
	for(int i = 1; i <= n; i++){
		printf("%d ", a[i]);
	}
	printf("\n");
	return 0;
}
