#include<bits/stdc++.h>
using namespace std;
const int MAXN = 50100;
const int MAXM = 100100;
typedef long long ll;

struct edge{int v, w; edge(int av = 0, int aw = 0){v = av; w = aw;}};

int n, m;
int query[MAXN];
int tot, frt[MAXN], nxt[MAXM]; edge ed[MAXM];
int dis[MAXN][30], fa[MAXN][30];
int atot, ctot, dtot;
pair<int, int> tops[MAXN];
int flg[MAXN], cover[MAXN], seq[MAXN], need[MAXN];

inline void add_edge(int u, int v, int w){
	ed[++tot] = edge(v, w);
	nxt[tot] = frt[u]; frt[u] = tot;
}

void dfs1(int u){
	int v, w;
	for(int i = frt[u]; i; i = nxt[i]){
		v = ed[i].v;
		w = ed[i].w;
		if(v != fa[u][0]){
			fa[v][0] = u;
			dis[v][0] = w;
			dfs1(v);
		}
	}
}

bool dfs2(int u){
	int v, ret = 0;
	if(flg[u]) return 1;
	for(int i = frt[u]; i; i = nxt[i]){
		v = ed[i].v;
		if(v != fa[u][0]){
			ret = 1;
			if(!dfs2(v)){
				return 0;
			}
		}
	}
	if(!ret) return 0;
	else return 1;
}

bool cmp1(pair<int, int> x, pair<int, int> y){
	return x.first < y.first;
}

bool cmp2(int x, int y){
	return x < y;
}

bool check(int mid){
	atot = ctot = dtot = 0;
	memset(tops, 0, sizeof(tops));
	memset(flg, 0, sizeof(flg));
	memset(cover, 0, sizeof(cover));
	memset(seq, 0, sizeof(seq));
	memset(need, 0, sizeof(need));
	for(int u, tmps, i = 1; i <= m; i++){
		u = query[i];
		tmps = 0;
		for(int j = 25; j >= 0; j--){
			if(fa[u][j] > 1 && tmps + dis[u][j] <= mid){
				tmps += dis[u][j];
				u = fa[u][j];
			}
		}
		if(fa[u][0] == 1 && tmps + dis[u][0] <= mid){
			tops[++atot] = make_pair(mid - tmps - dis[u][0], u);
		}else{
			flg[u] = 1;
		}
	}
	for(int v, i = frt[1]; i; i = nxt[i]){
		v = ed[i].v;
		if(!dfs2(v)){
			cover[v] = 1;
		}
	}
//	printf(":");
//	for(int v, i = frt[1]; i; i = nxt[i]){
//		v = ed[i].v;
//		printf("%d ", cover[v]);
//	}
//	printf("\n");
	sort(tops + 1, tops + atot + 1, cmp1);
	for(int v, i = 1; i <= atot; i++){
		v = tops[i].second;
		if(cover[v] && tops[i].first < dis[v][0]){
			cover[v] = 0;
		}else{
			seq[++ctot] = tops[i].first;
		}
	}
	for(int v, i = frt[1]; i; i = nxt[i]){
		v = ed[i].v;
		if(cover[v]){
			need[++dtot] = dis[v][0];
		}
	}
	sort(seq + 1, seq + ctot + 1, cmp2);
	sort(need + 1, need + dtot + 1, cmp2);
	int ipos = 1, jpos = 1;
	while(ipos <= ctot && jpos <= dtot){
		if(seq[ipos] >= need[jpos]){
			ipos++;
			jpos++;
		}else{
			ipos++;
		}
	}
	if(jpos > dtot) return true;
	else return false;
}

int main(){
	int l, r, mid, ans;
	scanf("%d", &n);
	for(int u, v, w, i = 1; i <= n - 1; i++){
		scanf("%d %d %d", &u, &v, &w);
		add_edge(u, v, w);
		add_edge(v, u, w);
		r = r + w;
	}
	dis[1][0] = 0;
	fa[1][0] = 0;
	dfs1(1);
	for(int i = 1; i <= 25; i++){
		for(int j = 1; j <= n; j++){
			fa[j][i] = fa[fa[j][i - 1]][i - 1];
			dis[j][i] = dis[j][i - 1] + dis[fa[j][i - 1]][i - 1];
		}
	}
	scanf("%d", &m);
	for(int i = 1; i <= m; i++){
		scanf("%d", &query[i]);
	}
	ans = -1;
	while(l <= r){
		mid = (l + r) >> 1;
		if(check(mid)){
			ans = mid;
			r = mid - 1;
		}else{
			l = mid + 1;
		}
//		printf(":%d %d %d\n", l, r, ans);
	}
	printf("%d\n", ans);
	return 0;
}
