#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFll 0x3f3f3f3f3f3f3f3fll
#define mp(x, y) make_pair(x, y)
const int MAXN = 50;
const int MOD = 2017;
typedef long long ll;
typedef pair<int, int> pii;

struct mat{
	int mp[MAXN][MAXN];
	mat(){memset(mp, 0, sizeof(mp));}
}I;

int n, m, t;
mat graph;

mat mul(const mat &x, const mat &y){
	mat ans;
	for(int i = 0; i <= n; i++){
		for(int j = 0; j <= n; j++){
			for(int k = 0; k <= n; k++){
				ans.mp[i][j] = (ans.mp[i][j] + (x.mp[i][k] * y.mp[k][j] % MOD)) % MOD;
			}
		}
	}
	return ans;
}

mat qpow(const mat &x, int pwr){
	if(pwr == 0) return I;
	if(pwr == 1) return x;
	mat tmps = qpow(x, pwr >> 1);
	if(pwr % 2 == 0) return mul(tmps, tmps);
	else return mul(mul(tmps, tmps), x);
}

int main(){int _task = 1; //scanf("%d", &_task);
while(_task--){
	scanf("%d %d", &n, &m);
	for(int u, v, i = 1; i <= m; i++){
		scanf("%d %d", &u, &v);
		graph.mp[u][v] = graph.mp[v][u] = 1;
	}
	for(int i = 0; i <= n; i++){
		graph.mp[i][0] = 1;
		graph.mp[i][i] = 1;
		I.mp[i][i] = 1;
	}
	scanf("%d", &t);
	mat res = qpow(graph, t);
	int ans = 0;
	for(int j = 0; j <= n; j++){
		ans = (ans + res.mp[1][j]) % MOD;
	}
	printf("%d\n", ans);
}
	return 0;
}

