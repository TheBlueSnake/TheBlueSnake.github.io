#include<bits/stdc++.h>
using namespace std;
const int MAXN = 110;
const int MOD = 1000000007;
typedef long long ll;

struct matrix{
	ll c, r, mat[MAXN][MAXN];
	void clear(int ac = 0, int ar = 0){memset(mat, 0, sizeof(mat)); c = ac; r = ar;}
	matrix operator* (matrix x) const{
		matrix ret; ret.clear(x.c, r);
		for(int i = 1; i <= ret.c; i++){
			for(int j = 1; j <= ret.r; j++){
				for(int k = 1; k <= c; k++){
					(ret.mat[i][j] += (mat[i][k] * x.mat[k][j] % MOD)) %= MOD;
				}
			}
		}
		return ret;
	}
};

ll n, k;
matrix ans;


matrix I(int x){
	matrix ret; ret.clear(x, x);
	for(int i = 1; i <= x; i++) ret.mat[i][i] = 1;
	return ret;
}

matrix qpow(matrix x, ll pwr){
	matrix ret; ret = I(x.c);
	while(pwr){
		if(pwr & 1) ret = ret * x;
		x = x * x;
		pwr >>= 1;
	}
	return ret;
}

int main(){
	scanf("%lld %lld", &n, &k);
	ans.clear(n, n);
	for(int i = 1; i <= n; i++){
		for(int j = 1; j <= n; j++){
			scanf("%lld", &ans.mat[i][j]);
		}
	}
	ans = qpow(ans, k);
	for(int i = 1; i <= n; i++){
		for(int j = 1; j <= n; j++){
			printf("%lld ", ans.mat[i][j]);
		}
		printf("\n");
	}
	return 0;
}
