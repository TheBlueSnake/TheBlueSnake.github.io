#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFll 0x3f3f3f3f3f3f3f3fll
#define mp(x, y) make_pair(x, y)
//const int MAXN = ;
typedef long long ll;
typedef pair<int, int> pii;

ll n, m, k, p;

int main(){//freopen(".in", "r", stdin); freopen(".out", "w", stdout);
int _task = 1; //scanf("%d", &_task);
while(_task--){
	scanf("%lld %lld %lld %lld", &n, &m, &k, &p);
	ll maxi = min(k / p, m);
	ll remain = k - maxi * p;
	ll available = (n - p) * (maxi - 1);
	if(remain > available){
		printf("NO\n");
		return 0;
	}else{
		printf("YES\n");
		for(int i = 1; i <= p; i++){
			printf("%lld %lld\n", maxi, m - maxi);
		}
		for(int i = 1; i <= n - p; i++){
			printf("%lld %lld\n", min(remain, maxi - 1), m - min(remain, maxi - 1));
			remain -= min(remain, maxi - 1);
		}
	}
}
	return 0;
}

