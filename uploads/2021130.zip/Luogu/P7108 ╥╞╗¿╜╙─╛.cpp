#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFll 0x3f3f3f3f3f3f3f3fll
#define mp(x, y) make_pair(x, y)
//const int MAXN = ;
const int MOD = 1000000007;
//const int MOD = 998244353;
typedef long long ll;
typedef pair<int, int> pii;
ll qmod(ll x){return x < 0 ? qmod(x + MOD) : (x > MOD ? x - MOD : x);}

ll a, b, h;

ll qpow(ll base, ll pwr){
	ll res = 1;
	while(pwr){
		if(pwr & 1) res = res * base % MOD;
		base = base * base % MOD;
		pwr = pwr >> 1;
	}
	return res;
}

ll sigma(ll sz, ll height){
	if(sz == 1) return height + 1;
	return qmod(qpow(sz, height + 1) - 1) * (qpow((sz - 1), MOD - 2)) % MOD;
}

int main(){//freopen(".in", "r", stdin); freopen(".out", "w", stdout);
int _task = 1; scanf("%d", &_task);
while(_task--){
	scanf("%lld %lld %lld", &a, &b, &h);
	ll sza = sigma(a, h);
	ll szb = sigma(b, h);
	ll leafa = qpow(a, h);
	ll leafb = qpow(b, h);
//	printf(":%lld %lld %lld %lld\n", sza, szb, leafa, leafb);
	if(h == 0){
		printf("%lld\n", a);
	}else if(a > b){
		printf("%lld\n", (szb * (a - b) % MOD + leafb * b % MOD) % MOD);
	}else if(a == b){
		printf("%lld\n", leafb * a % MOD);
	}else{
		ll removed = qmod(leafb - leafa);
		printf("%lld\n", ((removed + leafb * a % MOD - removed) % MOD + MOD) % MOD);
	}
}
	return 0;
}

