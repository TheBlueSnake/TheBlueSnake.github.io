#include<bits/stdc++.h>
using namespace std;
const int MAXN = 25100;
const int MAXM = 100;

int t, n, val[MAXN], ans, maximum;
bool f[MAXN * MAXM];

bool cmp(const int &x, const int &y);

int main(){
	freopen("money.in", "r", stdin);
	freopen("money.out", "w", stdout);
	scanf("%d", &t); while(t--){
		scanf("%d", &n); ans = n;
		for(int i = 1; i <= n; i++)
			scanf("%d", &val[i]),
			maximum = max(maximum, val[i]);
		sort(val + 1, val + n + 1, cmp);
		memset(f, false, sizeof(f));
		f[0] = true;
		for(int i = 1; i <= n; i++){
			if(f[val[i]]) {ans--; continue;}
			for(int j = val[i]; j <= maximum; j++)
				f[j] = f[j] | f[j - val[i]];
		}
		printf("%d\n", ans);
	}
	return 0;
}

bool cmp(const int &x, const int &y){
	return x < y;
}
