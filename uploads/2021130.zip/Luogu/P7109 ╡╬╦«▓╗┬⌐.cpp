#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFll 0x3f3f3f3f3f3f3f3fll
#define mp(x, y) make_pair(x, y)
const int MAXN = 1100;
//const int MOD = 1000000007;
//const int MOD = 998244353;
typedef long long ll;
typedef pair<int, int> pii;
//inline ll qmod(ll x){return x > MOD ? x - MOD : x;}

int n;
int val[MAXN], cur[MAXN];

int pour(int i, int j){
	int tmps;
	printf("? %d %d\n", i, j);
	fflush(stdout);
	scanf("%d", &tmps);
	return tmps;
}

int solve(int x){
	if(cur[x] != -1) return cur[x];
	if(x == 1) return cur[x] = pour(1, 1);
	int sum_pour = 0;
	for(int i = 0; (1 << i) <= x - 1; i++){
		if(cur[1 << i] != 0){
			sum_pour += cur[1 << i];
			cur[1 << i] = 0;
			if(pour(1 << i, x)){
				cur[1 << i] = -1;
				cur[x] = x;
				return x - sum_pour + solve(1 << i);
			}
		}
	}
	int pour_out = 0;
	for(int i = 15; i >= 1; i--){
		if(x > (1 << i)){
			if(!pour(x, 1 << i)){
				cur[1 << i] = -1;
				cur[x] = 0;
				return pour_out + solve(1 << i) - sum_pour;
			}
			pour_out += 1 << i;
			cur[1 << i] = 1 << i;
		}
	}
	cur[x] = 0;
	if(pour(x, 1)){
		cur[1] = 1;
		return pour_out + 1 - sum_pour;
	}else{
		cur[1] = 0;
		return pour_out - sum_pour;
	}
}

int main(){//freopen(".in", "r", stdin); freopen(".out", "w", stdout);
int _task = 1; //scanf("%d", &_task);
while(_task--){
	scanf("%d", &n);
	memset(val, -1, sizeof(val));
	memset(cur, -1, sizeof(cur));
	val[1] = cur[1] = pour(1, 1);
	for(int i = 2; i <= n; i++){
		if(pour(i, i)){
			val[i] = cur[i] = i;
		}
	}
	for(int i = 2; i <= n; i++){
		if(val[i] == -1){
			val[i] = solve(i);
		}
	}
	printf("! ");
	for(int i = 1; i <= n; i++){
		printf("%d ", val[i]);
	}
	printf("\n");
	fflush(stdout);
}
	return 0;
}

