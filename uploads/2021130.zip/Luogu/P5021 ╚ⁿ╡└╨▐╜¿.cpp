#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef multiset<ll>::iterator _it;
const int MAXN = 50100;
const int MAXM = 100100;

struct edge{int st, ed; ll len; edge(int ast = 0, int aed = 0, ll alen = 0){st = ast; ed = aed; len = alen;}};

int n, m;
int tot, frt[MAXN], nxt[MAXM]; edge edg[MAXM];
multiset<ll> st[MAXN];
int res;

inline void add_edge(int u, int v, ll len){
	edg[++tot] = edge(u, v, len);
	nxt[tot] = frt[u]; frt[u] = tot;
}
ll dfs(int x, int fa, ll mid){
	int v, dis;
	st[x].clear();
	for(int i = frt[x]; i; i = nxt[i]){
		v = edg[i].ed;
		if(v != fa){
			dis = dfs(v, x, mid) + edg[i].len;
			if(dis >= mid) res++;
			else st[x].insert(dis);
		}
	}
	ll ret = 0, val;
	while(!st[x].empty()){
		if(st[x].size() == 1) return max(ret, *st[x].begin());
		val = *st[x].begin();
		st[x].erase(st[x].begin());
		_it tmps = st[x].lower_bound(mid - val);
		if(tmps == st[x].end()){
			ret = max(ret, val);
		}else{
			res++;
			st[x].erase(tmps);
		}
	}
	return ret;
}
bool judge(ll mid){
	res = 0;
	dfs(1, 0, mid);
	return res >= m;
}

int main(){
	freopen("track.in", "r", stdin);
	freopen("track.out", "w", stdout);
	int u, v; ll l;
	ll lft, rht, mid, ans;
	lft = rht = mid = ans = 0;
	scanf("%d %d", &n, &m);
	for(int i = 1; i < n; i++){
		scanf("%d %d %lld", &u, &v, &l);
		add_edge(u, v, l);
		add_edge(v, u, l);
		rht += l;
	}
	while(lft <= rht){
		mid = (lft + rht) >> 1;
		if(judge(mid)) ans = mid, lft = mid + 1;
		else rht = mid - 1;
	}
	printf("%lld\n", ans);
	return 0;
}
