#include<bits/stdc++.h>
using namespace std;
const int MAXN = 40000100;
const int MOD = 1 << 30;
typedef long long ll;

int n, type;
int arr[MAXN], b[MAXN];
int f[MAXN];
ll sum[MAXN];
int pre[MAXN], d[MAXN];
int hd, tl, que[MAXN];

void input(int flag){
	if(flag){
		int x, y, z, m;
		scanf("%d %d %d %d %d %d", &x, &y, &z, &b[1] ,&b[2], &m);
		for(int i = 3; i <= n; i++){
			b[i] = (1ll * x * b[i - 1] + 1ll * y * b[i - 2] + z) % MOD;
		}
		int prev = 0, xi;
		int l, r;
		for(int i = 1; i <= m; i++){
			scanf("%d %d %d", &xi, &l, &r);
			for(int j = prev + 1; j <= xi; j++){
				arr[j] = (b[j] % (r - l + 1)) + l;
			}
			prev = xi;
		}
	}else{
		for(int i = 1; i <= n; i++){
			scanf("%d", &arr[i]);
		}
	}
}

int main(){
	scanf("%d %d", &n, &type);
	input(type);
	sum[0] = 0;
	for(int i = 1; i <= n; i++){
		sum[i] = sum[i - 1] + arr[i];
	}
	hd = 1; tl = 0;
	que[++tl] = 0;
	for(int i = 1; i <= n; i++){
		while(hd < tl && 2ll * sum[que[hd + 1]] - sum[pre[que[hd + 1]]] <= sum[i]) hd++;
		pre[i] = que[hd];
		while(hd <= tl && 2ll * sum[i] - sum[pre[i]] <= 2ll * sum[que[tl]] - sum[pre[que[tl]]]) tl--;
		que[++tl] = i;
	}
	int now = n; __int128 ans = 0, tmps = 1;
	while(now){
		tmps = sum[now] - sum[pre[now]];
		tmps *= sum[now] - sum[pre[now]];
		ans += tmps;
		now = pre[now];
	}
	int res[50], head = 0;
	while(ans){
		res[++head] = ans % 10;
		ans = ans / 10;
	}
	while(head){
		printf("%d", res[head--]);
	}
	printf("\n");
	return 0;
}

