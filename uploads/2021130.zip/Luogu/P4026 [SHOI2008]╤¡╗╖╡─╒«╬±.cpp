#include<bits/stdc++.h>
using namespace std;
const int MAXN = 1100;
const int kk[] = {-1, 100, 50, 20, 10, 5, 1};
#define INF 0x3f3f3f3f

int x1, x2, x3;
int a[10], b[10], c[10], sum[10];
int f[10][MAXN][MAXN];

int main(){
	scanf("%d %d %d", &x1, &x2, &x3);
	memset(a, 0, sizeof(a));
	memset(b, 0, sizeof(b));
	memset(c, 0, sizeof(c));
	for(int i = 1; i <= 6; i++){
		scanf("%d", &a[i]);
		a[0] += a[i] * kk[i];
		sum[i] += a[i];
	}
	for(int i = 1; i <= 6; i++){
		scanf("%d", &b[i]);
		b[0] += b[i] * kk[i];
		sum[i] += b[i];
	}
	for(int i = 1; i <= 6; i++){
		scanf("%d", &c[i]);
		c[0] += c[i] * kk[i];
		sum[i] += c[i];
	}
	memset(f, 0x3f, sizeof(f));
	int tot = a[0] + b[0] + c[0];
	f[0][a[0]][b[0]] = 0;
	//a[0], b[0], c[0]��ABC���˵�Ǯ��֮��
	//tot����Ǯ��
	//sum[i]�ǵ�i�ֳ�Ʊ������ 
	for(int i = 1; i <= 6; i++){
		for(int j = 0; j <= tot; j++){ //j��A�е�Ǯ�� 
			for(int k = 0; k + j <= tot; k++){ //k��B�е�Ǯ�� 
				if(f[i - 1][j][k] == INF) continue;
				for(int p = 0; p <= sum[i]; p++){ //p��A��������p��i�೮Ʊ 
					for(int q = 0; q + p <= sum[i]; q++){ //q��B��������q��i�೮Ʊ 
						int deltaA = j - a[i] * kk[i] + p * kk[i]; //��������A�ж���Ǯ 
						int deltaB = k - b[i] * kk[i] + q * kk[i];
						if(deltaA >= 0 && deltaB >= 0 && tot - deltaA - deltaB >= 0){
							int numA = a[i] - p;
							int numB = b[i] - q;
							int numC = c[i] - (sum[i] - p - q);
							f[i][deltaA][deltaB] = min(f[i][deltaA][deltaB], 
							f[i - 1][j][k] + ((abs(numA) + abs(numB) + abs(numC)) >> 1));
						}
					}
				}
			}
		}
	}
	int finalA = a[0] - x1 + x3; //������A�ж���Ǯ 
	int finalB = b[0] - x2 + x1;
	int finalC = c[0] - x3 + x2;
	if(finalA < 0 || finalB < 0 || finalC < 0 || f[6][finalA][finalB] == INF){
		printf("impossible\n");
	}else{
		printf("%d\n", f[6][finalA][finalB]);
	}
	return 0;
}
