#include<bits/stdc++.h>
using namespace std;
const int MAXN = 200100;
const int MAXK = 200100;
const int MAXM = 800100;
typedef long long ll;
typedef pair<ll, int> pii;

struct edge{
	ll v, l;
	edge(ll av = 0, ll al = 0){
		v = av; l = al;
	}
};

ll n, k;
ll tot, frt[MAXN + MAXK], nxt[MAXM]; edge ed[MAXM];
ll dis[MAXN + MAXK];

void add_edge(ll u, ll v, ll l){
//	printf("%d -> %d: %d\n", u, v, l);
	ed[++tot] = edge(v, l);
	nxt[tot] = frt[u]; frt[u] = tot;
}

void dijkstra(ll st){
	ll u, v, vis[MAXN + MAXK];
	priority_queue<pii, vector<pii>, greater<pii> > que;
	memset(vis, 0, sizeof(vis));
	memset(dis, 0x3f, sizeof(dis));
	que.push(make_pair(0, st)); dis[st] = 0;
	while(!que.empty()){
		u = que.top().second; que.pop();
		if(!vis[u]){
			vis[u] = 1;
			for(ll i = frt[u]; i; i = nxt[i]){
				v = ed[i].v;
				if(dis[v] > dis[u] + ed[i].l){
					dis[v] = dis[u] + ed[i].l;
					que.push(make_pair(dis[v], v));
				}
			}
		}
	}
}

int main(){
	scanf("%lld %lld", &n, &k);
	for(ll ksize, i = 1; i <= k; i++){
		scanf("%lld", &ksize);
		for(ll ti, wi, j = 1; j <= ksize; j++){
			scanf("%lld %lld", &ti, &wi);
			add_edge(ti + k, i, wi);
			add_edge(i, ti + k, wi);
		}
	}
	dijkstra(k + 1);
	for(ll i = k + 1; i <= k + n; i++){
		printf("%lld ", dis[i]);
	}
	return 0;
}
