#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
const int MAXN = 100100;
typedef long long ll;

ll n, k, e[MAXN], pref[MAXN];
ll f[MAXN][2];
deque<pair<ll, ll> > que;

int main(){
	scanf("%lld %lld", &n, &k);
	memset(pref, 0, sizeof(pref));
	for(ll i = 1; i <= n; i++){
		scanf("%lld", &e[i]);
		pref[i] = pref[i - 1] + e[i];
	}
	memset(f, 0, sizeof(f));
	que.push_back(make_pair(0, 0));
	for(ll i = 1; i <= n; i++){
		f[i][0] = max(f[i - 1][0], f[i - 1][1]);
		while(!que.empty() && que.front().first < i - k) que.pop_front();
		f[i][1] = que.front().second + pref[i];
		while(!que.empty() && que.back().second < f[i][0] - pref[i]) que.pop_back();
		que.push_back(make_pair(i, f[i][0] - pref[i]));
//		for(int j = 1; j <= k; j++){
//			if(i - j < 0) break;
//			f[i][1] = max(f[i][1], f[i - j][0] + pref[i] - pref[i - j]);
//		}
	}
	printf("%lld\n", max(f[n][0], f[n][1]));
	return 0;
}

