#include<bits/stdc++.h>
using namespace std;
const int val[] = {-1, 100, 50, 20, 10, 5, 1};
const int MAXN = 4100;
const int INF = 0x3f3f3f3f;

int x1, x2, x3;
int a[10], b[10], c[10], sum[10];
int f[MAXN][MAXN];

void upd(int &x, int val){
	x = min(x, val);
}

int main(){
	scanf("%d %d %d", &x1, &x2, &x3);
	for(int i = 1; i <= 6; i++){
		scanf("%d", &a[i]);
		a[0] += a[i] * val[i];
		sum[i] += a[i];
	}
	for(int i = 1; i <= 6; i++){
		scanf("%d", &b[i]);
		b[0] += b[i] * val[i];
		sum[i] += b[i];
	}
	for(int i = 1; i <= 6; i++){
		scanf("%d", &c[i]);
		c[0] += c[i] * val[i];
		sum[i] += c[i];
	}
//	printf(":");
//	for(int i = 1; i <= 6; i++){
//		printf("%d ", sum[i]);
//	}
//	printf("\n");
	memset(f, 0x3f, sizeof(f));
	f[x1 - x3 + 2000][x2 - x3 + 2000] = 0;
	for(int i = 0; i <= 5; i++){
		for(int j = -2000 + 2000; j <= 2000 + 2000; j++){
			for(int k = -2000 + 2000; k <= 2000 + 2000; k++){
				if(f[j][k] != INF){
//					printf(":%d:f[%d][%d] = %d\n", i, j - 2000, k - 2000, f[j][k]);
					for(int x1 = -sum[i]; x1 <= sum[i]; x1++){ //x1��A��B
						for(int x2 = -sum[i]; x2 <= sum[i]; x2++){ //x2��B��C
							int valA = a[i] - x1;
							int valB = b[i] + x1 - x2;
							int valC = c[i] + x2;
							if(valA < 0 || valB < 0 || valC < 0) continue;
							upd(f[j - x1 * val[i]][k - x2 * val[i]], f[j][k] + abs(x1) + abs(x2));
						}
					}
					for(int x1 = -sum[i]; x1 <= sum[i]; x1++){ //x1��B��C
						for(int x2 = -sum[i]; x2 <= sum[i]; x2++){ //x2��C��A
							int valA = a[i] + x2;
							int valB = b[i] - x1;
							int valC = c[i] + x1 - x2;
							if(valA < 0 || valB < 0 || valC < 0) continue;
							upd(f[j + x2 * val[i]][k + x2 * val[i] - x1 * val[i]],
								f[j][k] + abs(x1) + abs(x2));
						}
					}
					for(int x1 = -sum[i]; x1 <= sum[i]; x1++){ //x1��C��A
						for(int x2 = -sum[i]; x2 <= sum[i]; x2++){ //x2��A��B
							int valA = a[i] + x1 - x2;
							int valB = b[i] + x2;
							int valC = c[i] - x1;
							if(valA < 0 || valB < 0 || valC < 0) continue;
							upd(f[j + x1 * val[i] - x2 * val[i]][k + x1 * val[i]],
								f[j][k] + abs(x1) + abs(x2));
						}
					}
				}
			}
		}
	}
	int finalA = a[0] - x1 + x3; //������A�ж���Ǯ 
	int finalB = b[0] - x2 + x1;
	int finalC = c[0] - x3 + x2;
	if(finalA < 0 || finalB < 0 || finalC < 0 || f[0 + 2000][0 + 2000] == INF){
		printf("impossible\n");
	}else{
		printf("%d\n", f[0 + 2000][0 + 2000]);
	}
	return 0;
}
