#include<bits/stdc++.h>
using namespace std;
const int MAXN = 5100;
const int MAXM = 10100;

int n, m;
int tot, frt[MAXN], nxt[MAXM], ed[MAXM], deg[MAXN];
int ans[MAXN];
int nou, nov, flag;

void add_edge(int u, int v){
	ed[++tot] = v; deg[v]++;
	nxt[tot] = frt[u]; frt[u] = tot;
}

bool cmp(const int &x, const int &y){
	return x < y;
}

void dfs1(int u, int fa){
	ans[++ans[0]] = u;
	int arr[50]; arr[0] = 0;
	for(int v, i = frt[u]; i; i = nxt[i]){
		v = ed[i];
		if(v != fa){
			arr[++arr[0]] = v;
		}
	}
	sort(arr + 1, arr + arr[0] + 1, cmp);
	for(int i = 1; i <= arr[0]; i++){
		dfs1(arr[i], u);
	}
}

void dfs2(int u, int fa){
	int arr[50]; arr[0] = 0;
	if(ans[++ans[0]] > u || flag){
		ans[ans[0]] = u;
		flag = 1;
	}else if(ans[ans[0]] < u){
		flag = 2;
		return;
	}
	for(int v, i = frt[u]; i; i = nxt[i]){
		v = ed[i];
		if(v != fa && !(u == nou && v == nov) && !(u == nov && v == nou)){
			arr[++arr[0]] = v;
		}
	}
	sort(arr + 1, arr + arr[0] + 1, cmp);
	for(int i = 1; i <= arr[0]; i++){
		dfs2(arr[i], u);
		if(flag == 2) return;
	}
}

int main(){
	freopen("travel.in", "r", stdin);
	freopen("travel.out", "w", stdout);
	scanf("%d %d", &n, &m);
	for(int u, v, i = 1; i <= m; i++){
		scanf("%d %d", &u, &v);
		add_edge(u, v);
		add_edge(v, u);
	}
	assert(m == n || m == n - 1);
	if(m == n - 1){
		ans[0] = 0;
		dfs1(1, 0);
		for(int i = 1; i <= n; i++){
			printf("%d ", ans[i]);
		}
		printf("\n");
		return 0;
	}
	if(m == n){
		for(int i = 1; i <= n; i++) ans[i] = n - i + 1;
		for(int i = 1; i <= tot; i += 2){
			ans[0] = flag = 0;
			nou = ed[i]; nov = ed[i + 1];
//			printf(":%d %d\n", nou, nov);
			if(deg[nou] - 1 == 0 || deg[nov] - 1 == 0){
				continue;
			}
//			printf("::");
			dfs2(1, 0);
//			printf("\n");
//			printf(":");
//			for(int j = 1; j <= n; j++){
//				printf("%d ", ans[j]);
//			}
//			printf("\n");
		}
		for(int i = 1; i <= n; i++){
			printf("%d ", ans[i]);
		}
		printf("\n");
	}
	return 0;
}
