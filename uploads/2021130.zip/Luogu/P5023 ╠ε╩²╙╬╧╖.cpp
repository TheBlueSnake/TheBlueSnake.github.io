#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFll 0x3f3f3f3f3f3f3f3fll
#define mp(x, y) make_pair(x, y)
//const int MAXN = ;
const int MOD = 1000000007;
typedef long long ll;
typedef pair<int, int> pii;

ll n, m;

int main(){
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
int _task = 1; //scanf("%d", &_task);
while(_task--){
	scanf("%lld %lld", &n, &m);
	if(n > m) swap(n, m);
	assert(n <= 8);
	if(n == 1){
		ll ans = 1;
		for(int i = 1; i <= m; i++){
			ans = (ans << 1) % MOD;
		}
		printf("%lld\n", ans);
		return 0;
	}else if(n == 2){
		ll ans = 4;
		for(int i = 1; i <= m - 1; i++){
			ans = ans * 3 % MOD;
		}
		printf("%lld\n", ans);
		return 0;
	}else if(n == 3){
		ll ans = 112;
		for(int i = 1; i <= m - 3; i++){
			ans = ans * 3 % MOD;
		}
		printf("%lld\n", ans);
		return 0;
	}else if(n == 4){
		if(m == 4){printf("912\n"); return 0;}
		ll ans = 2688;
		for(int i = 1; i <= m - 4 - 1; i++){
			ans = ans * 3 % MOD;
		}
		printf("%lld\n", ans);
		return 0;
	}else if(n == 5){
		if(m == 5){printf("7136\n"); return 0;}
		ll ans = 21312;
		for(int i = 1; i <= m - 5 - 1; i++){
			ans = ans * 3 % MOD;
		}
		printf("%lld\n", ans);
		return 0;
	}else if(n == 6){
		if(m == 6){printf("56768\n"); return 0;}
		ll ans = 170112;
		for(int i = 1; i <= m - 6 - 1; i++){
			ans = ans * 3 % MOD;
		}
		printf("%lld\n", ans);
		return 0;
	}else if(n == 7){
		if(m == 7){printf("453504\n"); return 0;}
		ll ans = 1360128;
		for(int i = 1; i <= m - 7 - 1; i++){
			ans = ans * 3 % MOD;
		}
		printf("%lld\n", ans);
		return 0;
	}else if(n == 8){
		if(m == 8){printf("3626752\n"); return 0;}
		ll ans = 10879488;
		for(int i = 1; i <= m - 8 - 1; i++){
			ans = ans * 3 % MOD;
		}
		printf("%lld\n", ans);
		return 0;
	}
}
	return 0;
}

