#include<bits/stdc++.h>
using namespace std;
const int MAXN = 100100;
const int INF = 0x3f3f3f3f;
typedef long long ll;

ll n, m, q, u, v, t;
double p;
ll pos, a[MAXN];
deque<ll> que1, que2;

bool cmp(ll x, ll y){
	return x > y;
}

ll nxt(){
	ll ret, flg;
	if(pos <= n){
		ret = a[pos];
		flg = 1;
	}else{
		ret = -INF;
		flg = -1;
	}
	if(!que1.empty() && ret < que1.front()){
		ret = que1.front();
		flg = 2;
	}
	if(!que2.empty() && ret < que2.front()){
		ret = que2.front();
		flg = 3;
	}
	if(flg == 1){
		pos++;
	}else if(flg == 2){
		que1.pop_front();
	}else{
		que2.pop_front();
	}
	return ret;
}

int main(){
	scanf("%lld %lld %lld %lld %lld %lld", &n, &m, &q, &u, &v, &t);
	p = 1.0 * u / v;
	for(ll i = 1; i <= n; i++){
		scanf("%lld", &a[i]);
	}
	sort(a + 1, a + n + 1, cmp);
	pos = 1;
	ll dq = 0;
	for(ll i = 1; i <= m; i++){
		ll tp = nxt() + dq;
		que1.push_back(floor(1.0 * p * tp) - dq - q);
		que2.push_back(tp - floor(1.0 * p * tp) - dq - q);
		if(i % t == 0){
			printf("%lld ", tp);
		}
		dq += q;
	}
	printf("\n");
	for(ll i = 1; i <= n + m; i++){
		ll tp = nxt();
		if(i % t == 0){
			printf("%lld ", tp + dq);
		}
	}
	printf("\n");
	return 0;
}
