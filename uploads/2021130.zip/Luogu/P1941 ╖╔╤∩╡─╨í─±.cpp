#include<bits/stdc++.h>
using namespace std;
const int MAXN = 10100;
const int MAXM = 1100;
#define INF 0x3f3f3f3f

struct node{
	int p, l, h;
	node(int ap = 0, int al = 0, int ah = 0){
		p = ap; l = al; h = ah;
	}
};

int n, m, k;
int incl[MAXN], decl[MAXN];
node arr[MAXN];
int f[MAXN][MAXM];

bool cmp(node x, node y){
	return x.p < y.p;
}

int main(){
	scanf("%d %d %d", &n, &m, &k);
	for(int i = 0; i <= n - 1; i++){
		scanf("%d %d", &incl[i], &decl[i]);
	}
	for(int i = 1; i <= k; i++){
		scanf("%d %d %d", &arr[i].p, &arr[i].l, &arr[i].h);
	}
	sort(arr + 1, arr + k + 1, cmp);
//	for(int i = 1; i <= k; i++){
//		printf(":%d %d %d:\n", arr[i].p, arr[i].l, arr[i].h);
//	}
	memset(f, 0x3f, sizeof(f));
	f[0][0] = INF;
	int anspass = 0;
	for(int i = 1; i <= m; i++) f[0][i] = 0;
	int obs = 1;
	for(int i = 1; i <= n; i++){
		while(arr[obs].p < i) obs++;
		for(int j = incl[i - 1]; j <= m; j++){
			f[i][j] = min(f[i][j], min(f[i - 1][j - incl[i - 1]], f[i][j - incl[i - 1]]) + 1);
		}
		for(int j = m - incl[i - 1]; j <= m; j++){
			f[i][m] = min(f[i][m], min(f[i - 1][j], f[i][j]) + 1);
		}
		for(int j = 1; j + decl[i -  1] <= m; j++){
			f[i][j] = min(f[i][j], f[i - 1][j + decl[i - 1]]);
		}
		f[i][0] = INF;
//		printf("::%d %d\n", arr[obs].p, obs);
		if(arr[obs].p == i){
			for(int j = 0; j <= arr[obs].l; j++) f[i][j] = INF;
			for(int j = arr[obs].h; j <= m; j++) f[i][j] = INF;
			bool flg = false;
			for(int j = 1; j <= m; j++){
				if(f[i][j] < 0x3f000000){
					flg = true;
					break;
				}
			}
			if(flg) anspass++;
		}
//		for(int j = 1; j <= m; j++)
//			printf(":f[%d][%d] = %d\n", i, j, f[i][j]);
	}
	int ans = INF;
	for(int i = 1; i <= m; i++){
		ans = min(ans, f[n][i]);
	}
	if(ans <= 0x3f000000){
		printf("1\n%d\n", ans);
		return 0;
	}else{
		printf("0\n%d\n", anspass);
		return 0;
	}
	return 0;
}
