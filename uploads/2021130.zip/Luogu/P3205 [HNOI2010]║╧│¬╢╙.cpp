#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
const int MAXN = 1100;
const int MOD = 19650827;
typedef long long ll;

int n, arr[MAXN];
int f[MAXN][MAXN][2];

int main(){int _task = 1; //scanf("%d", &_task);
	while(_task--){
		scanf("%d", &n);
		for(int i = 1; i <= n; i++){
			scanf("%d", &arr[i]);
		}
		memset(f, 0, sizeof(f));
		for(int i = 1; i <= n; i++){
			f[i][i][0] = 1;
			f[i][i][1] = 0;
//			printf(":f[%d][%d][0] = %d\n", i, i, f[i][i][0]);
//			printf(":f[%d][%d][1] = %d\n", i, i, f[i][i][1]);
		}
		for(int i = 2; i <= n; i++){
			for(int j = 1; i + j - 1 <= n; j++){
				int e = i + j - 1;
				f[j][e][0] = (1ll * f[j + 1][e][0] * (arr[j] < arr[j + 1]) % MOD
						   + 1ll * f[j + 1][e][1] * (arr[j] < arr[e]) % MOD) % MOD;
				f[j][e][1] = (1ll * f[j][e - 1][0] * (arr[j] < arr[e]) % MOD
						   + 1ll * f[j][e - 1][1] * (arr[e - 1] < arr[e]) % MOD) % MOD;
//				printf(":f[%d][%d][0] = %d\n", j, e, f[j][e][0]);
//				printf(":f[%d][%d][1] = %d\n", j, e, f[j][e][1]);
			}
		}
		printf("%d\n", (f[1][n][0] + f[1][n][1]) % MOD);
	}
	return 0;
}

