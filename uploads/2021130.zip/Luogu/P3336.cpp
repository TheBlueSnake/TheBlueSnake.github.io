#include<bits/stdc++.h>
using namespace std;
const int MAXN = 1000100;
const int MOD = 19940417;
typedef long long ll;

struct node{
	ll val, pos;
	node(int apos = 0, int aval = 0){val = aval; pos = apos;}
	bool operator==(node &y) const{
		return this->val == y.val && this->pos == y.pos;
	};
};

ll n, k;
node p[MAXN];
ll f[MAXN][2], maximum[MAXN][2];

bool cmp(const node &x, const node &y);
inline ll qpow(ll x, ll pw);
inline ll llmax(const ll &x, const ll &y);

int main(){
	scanf("%lld %lld", &n, &k);
	for(int i = 1; i <= k; i++)
		scanf("%lld %lld", &p[i].pos, &p[i].val);
	p[++k] = node(0, 0);
	p[++k] = node(n, 0);
	sort(p + 1, p + k + 1, cmp);
	k = unique(p + 1, p + k + 1) - p - 1;
	memset(f, 0, sizeof(f));
	memset(maximum, -1, sizeof(maximum));
	f[1][0] = 1; f[1][1] = 0;
	maximum[1][0] = 0; maximum[1][1] = -1;

	int x1, x2, v1, v2, tmps;
	int vala, valb;
	for(int i = 2; i <= k; i++){
		x1 = p[i - 1].pos; x2 = p[i].pos;
		v1 = p[i - 1].val; v2 = p[i].val;
		// printf("%d %d %d %d\n", x1, v1, x2, v2);

		valb = x2 - v2 - x1 - v1;
		vala = valb - 2;

		// f[i][0] <== f[i - 1][0]
		// 1 down - 2 down
		if(v1 - v2 == x2 - x1){
			f[i][0] = (f[i][0] + f[i - 1][0]) % MOD;
			if(maximum[i - 1][0] >= 0)
				maximum[i][0] = llmax(maximum[i][0], llmax(maximum[i - 1][0], v1));
		} else if(vala >= 0){
			f[i][0] = (f[i][0] + f[i - 1][0] * qpow(2, vala >> 1) % MOD) % MOD;
			if(maximum[i - 1][0] >= 0)
				maximum[i][0] = llmax(maximum[i][0], llmax(maximum[i - 1][0], llmax(v1, v2 + ((vala + 2) >> 1))));
		}

		// f[i][0] <== f[i - 1][1]
		// 1 up - 2 down
		if(vala >= 0){
			f[i][0] = (f[i][0] + f[i - 1][1] * (qpow(2, (vala >> 1) + 1) - 1 + MOD) % MOD) % MOD;
			if(maximum[i - 1][1] >= 0)
				maximum[i][0] = llmax(maximum[i][0], llmax(maximum[i - 1][1], llmax(v1 + ((vala + 2) >> 1), v2 + ((vala + 2) >> 1))));
		}
		tmps = (x2 + v2 - x1 + v1) >> 1;
		if(v1 <= tmps && v2 < tmps){
			f[i][0] = (f[i][0] + f[i - 1][1]) % MOD;
			if(maximum[i - 1][1] >= 0)
				maximum[i][0] = llmax(maximum[i][0], llmax(maximum[i - 1][1], tmps));
		}

		// f[i][1] <== f[i - 1][0]
		// 1 down - 2 up
		if(v2){
			if(valb >= 0){
				f[i][1] = (f[i][1] + f[i - 1][0] * qpow(2, max(0, (valb >> 1) - 1)) % MOD) % MOD;
				if(maximum[i - 1][0] >= 0)
					maximum[i][1] = llmax(maximum[i][1], llmax(maximum[i - 1][0], llmax(v1, llmax(v2, valb >> 1))));
			}
		}

		// f[i][1] <== f[i - 1][1]
		// 1 up - 2 up
		if(v2){
			if(v2 - v1 == x2 - x1){
				f[i][1] = (f[i][1] + f[i - 1][1]) % MOD;
				if(maximum[i - 1][1] >= 0)
					maximum[i][1] = llmax(maximum[i][1], llmax(maximum[i - 1][1], v2));
			} else{
				if(valb >= 0){
					f[i][1] = (f[i][1] + f[i - 1][1] * qpow(2, valb >> 1) % MOD) % MOD;
					if(maximum[i - 1][1] >= 0)
						maximum[i][1] = llmax(maximum[i][1], llmax(maximum[i - 1][1], llmax(v1 + (valb >> 1), v2)));
				}
			}
		}
	}
	printf("%lld %lld\n", f[k][0], maximum[k][0]);
	return 0;
}

bool cmp(const node &x, const node &y){
	return x.pos < y.pos;
}

inline ll qpow(ll x, ll pw){
	ll tmps = x, ret = 1;
	while(pw){
		if(pw & 1) ret = ret * tmps % MOD;
		tmps = tmps * tmps % MOD;
		pw >>= 1;
	}
	return ret;
}

inline ll llmax(const ll &x, const ll &y){
	return x > y ? x : y;
}
