#include<bits/stdc++.h>
using namespace std;
const int MAXN = 110;

int n, arr[MAXN], flg[MAXN];
int f[MAXN][MAXN], g[MAXN][MAXN];
int ans;

int main(){
	char str[5];
	scanf("%d", &n);
	for(int i = 1; i <= n; i++){
		scanf("%s", str + 1);
		scanf("%d", &arr[i]);
		arr[i + n] = arr[i];
		flg[i - 1] = flg[n + i - 1] = str[1] == 't' ? 0 : 1;//0:+, 1:*
	}
//	for(int i = 1; i <= n + n; i++) printf(":%d %c\n", arr[i], flg[i] == 0 ? '+' : '*');
	memset(f, 0xf0, sizeof(f));
	memset(g, 0x3f, sizeof(g));
	for(int i = 1; i <= n + n; i++) f[i][i] = g[i][i] = arr[i];
	for(int l = 2; l <= n; l++){
		for(int i = 1; i + l - 1 <= n + n; i++){
			int j = i + l - 1;// i to j
			for(int k = i; k <= j - 1; k++){// (i, k) _ (k + 1, j)
				if(flg[k] == 0){
					f[i][j] = max(f[i][j], f[i][k] + f[k + 1][j]);
					g[i][j] = min(g[i][j], g[i][k] + g[k + 1][j]);
				}else{
					f[i][j] = max(f[i][j], max(max(
							  f[i][k] * f[k + 1][j], 
							  f[i][k] * g[k + 1][j]), max(
							  g[i][k] * f[k + 1][j],
							  g[i][k] * g[k + 1][j])));
					g[i][j] = min(g[i][j], min(min(
							  f[i][k] * f[k + 1][j], 
							  f[i][k] * g[k + 1][j]), min(
							  g[i][k] * f[k + 1][j],
							  g[i][k] * g[k + 1][j])));
				}
			}
		}
	}
	ans = 0;
	for(int i = 1; i <= n; i++){
		ans = max(ans, f[i][i + n - 1]);
	}
	printf("%d\n", ans);
	for(int i = 1; i <= n; i++){
		if(f[i][i + n - 1] == ans){
			printf("%d ", i);
		}
	}
	return 0;
}
