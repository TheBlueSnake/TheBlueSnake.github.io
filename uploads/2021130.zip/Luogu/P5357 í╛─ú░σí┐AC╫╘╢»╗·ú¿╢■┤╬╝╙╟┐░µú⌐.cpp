#include<bits/stdc++.h>
using namespace std;
const int MAXN = 200100;
const int MAXL = 200100;
const int MAXQ = 2000100;

int n, edpos[MAXN << 1];
char input[MAXQ];
int tot, ch[MAXL][30], fail[MAXL], cnt[MAXL];
int etot, frt[MAXL], nxt[MAXL], ed[MAXL];

int update(int &pos){return pos = (pos == 0 ? ++tot : pos);}

void add_edge(int u, int v){
	ed[++etot] = v;
	nxt[etot] = frt[u]; frt[u] = etot;
}

int insert(char *str){
	int len = strlen(str);
	int pos = 0;
	for(int i = 0; i < len; i++){
		pos = update(ch[pos][str[i] - 'a']);
	}
	return pos;
}

void build(){
	queue<int> que;
	int pos;
	memset(fail, 0, sizeof(fail));
	for(int i = 0; i < 26; i++){
		if(ch[0][i]) que.push(ch[0][i]);
	}
	while(!que.empty()){
		pos = que.front(); que.pop();
		for(int i = 0; i < 26; i++){
			if(ch[pos][i]){
				fail[ch[pos][i]] = ch[fail[pos]][i];
				que.push(ch[pos][i]);
			}else{
				ch[pos][i] = ch[fail[pos]][i];
			}
		}
	}
}

void query(char *str){
	memset(cnt, 0, sizeof(cnt));
	int len = strlen(str);
	int pos = 0;
	for(int i = 0; i < len; i++){
		pos = ch[pos][str[i] - 'a'];
		cnt[pos]++;
	}
}

void dfs(int u){
	int v;
	for(int i = frt[u]; i; i = nxt[i]){
		v = ed[i];
		dfs(v);
		cnt[u] += cnt[v];
	}
}

int main(){
	tot = 0;
	memset(ch, 0, sizeof(ch));
	scanf("%d", &n);
	for(int i = 1; i <= n; i++){
		scanf("%s", input + 1);
		edpos[i] = insert(input + 1);
	}
	build();
	scanf("%s", input + 1);
	query(input + 1);
	etot = 0;
	memset(frt, 0, sizeof(frt));
	for(int i = 1; i <= tot; i++) add_edge(fail[i], i);
	dfs(0);
	for(int i = 1; i <= n; i++) printf("%d\n", cnt[edpos[i]]);
	return 0;
}
