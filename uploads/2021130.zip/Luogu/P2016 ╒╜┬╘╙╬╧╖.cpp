#include<bits/stdc++.h>
using namespace std;
const int MAXN = 2100;
const int MAXM = 4100;

int n;
int rev[MAXN], f[MAXN][2];
vector<int> r[MAXN];
int tot, frt[MAXN], nxt[MAXM], ed[MAXM];

void add_edge(int u, int v){
	ed[++tot] = v;
	nxt[tot] = frt[u]; frt[u] = tot;
}
void dfs(int u, int fa){
	int v;
	f[u][0] = 0; f[u][1] = 1;
	for(int i = frt[u]; i; i = nxt[i]){
		v = ed[i];
		if(v != fa){
			dfs(v, u);
			f[u][0] += f[v][1];
			f[u][1] += min(f[v][1], f[v][0]);
		}
	}
//	printf(":%d, %d %d\n", u, f[u][0], f[u][1]);
}

int main(){
	scanf("%d", &n);
	for(int k, pi, i = 1; i <= n; i++){
		scanf("%d", &pi);
		scanf("%d", &k);
		rev[pi] = i;
		for(int input, j = 1; j <= k; j++){
			scanf("%d", &input);
			r[i].push_back(input);
		}
	}
	for(int i = 1; i <= n; i++){
		int len = r[i].size();
		for(int j = 0; j < len; j++){
			add_edge(i, rev[r[i][j]]);
			add_edge(rev[r[i][j]], i);
//			printf(":%d %d\n", i, rev[r[i][j]]);
		}
	}
	dfs(1, 0);
	printf("%d\n", min(f[1][0], f[1][1]));
	return 0;
}
