#include<bits/stdc++.h>
using namespace std;
const int MAXN = 110;
#define INF 0x3f3f3f3f

int n;
char str[MAXN];
int f[MAXN][MAXN];

int calc(int i, int j, int k){
	if((j - i + 1) % k != 0) return INF;
	int parts = (j - i + 1) / k;
	for(int p = i; p <= i + k - 1; p++){
		for(int pt = k; p + pt <= j; pt += k){
			if(str[p + pt] != str[p]) return INF;
		}
	}
	if(parts == 1) return k;
	if(parts < 10) return min(j - i + 1, f[i][i + k - 1] + 2 + 1);
	if(parts < 100) return f[i][i + k - 1] + 2 + 2;
	return f[i][i + k - 1] + 2 + 3;
}

int main(){
	scanf("%s", str + 1);
	n = strlen(str + 1);
	memset(f, 0x3f, sizeof(f));
	for(int i = 1; i <= n; i++) f[i][i] = 1;
	for(int l = 2; l <= n; l++){
		for(int i = 1; i + l - 1 <= n; i++){
			int j = i + l - 1;
			for(int k = 1; k <= l; k++){
				f[i][j] = min(f[i][j], calc(i, j, k));
			}
			for(int k = i; k <= j - 1; k++){
				f[i][j] = min(f[i][j], f[i][k] + f[k + 1][j]);
			}
//			printf(":f[%d][%d] = %d\n", i, j, f[i][j]);
		}
	}
	printf("%d\n", f[1][n]);
	return 0;
}
