#include<bits/stdc++.h>
using namespace std;
const int MAXS = 110;
const int MAXN = 110;
const int MAXM = 20100;

int s, n, m;
int arr[MAXS][MAXN];
int f[MAXN][MAXM];

bool cmp(int x, int y){
	return x < y;
}

int main(){
	scanf("%d %d %d", &s, &n, &m);
	for(int i = 1; i <= s; i++){
		for(int j = 1; j <= n; j++){
			scanf("%d", &arr[j][i]);
		}
	}
	for(int i = 1; i <= n; i++){
		sort(arr[i] + 1, arr[i] + s + 1, cmp);
	}
//	for(int i = 1; i <= n; i++){
//		for(int j = 1; j <= s; j++){
//			printf(":arr[%d][%d] = %d\n", i, j, arr[i][j]);
//		}
//	}
	memset(f, 0, sizeof(f));
	for(int i = 1; i <= n; i++){
		for(int j = 1; j <= m; j++){
			f[i][j] = f[i - 1][j];
			for(int k = 1; k <= s; k++){
				if(j - arr[i][k] - arr[i][k] - 1 >= 0){
					f[i][j] = max(f[i][j], f[i - 1][j - arr[i][k] - arr[i][k] - 1] + k * i);
//					printf(":%d %d %d %d\n", i, j, k, f[i][j]);
				}
			}
//			printf("f[%d][%d] = %d\n", i, j, f[i][j]);
		}
	}
	int ans = 0;
	for(int i = 0; i <= m; i++)
		ans = max(ans, f[n][i]);
	printf("%d\n", ans);
	return 0;
}
