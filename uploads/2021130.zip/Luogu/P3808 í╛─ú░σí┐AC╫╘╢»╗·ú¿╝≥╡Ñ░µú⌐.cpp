#include<bits/stdc++.h>
using namespace std;
const int MAXN = 1000100;
const int MAXL = 1000100;

int n;
char input[MAXL];
int tot, ch[MAXL][30], fail[MAXL], cnt[MAXL], vis[MAXL];

int update(int &pos){return pos = (pos == 0 ? ++tot : pos);}

void insert(char *str){
	int len = strlen(str);
	int pos = 0;
	for(int i = 0; i < len; i++){
		pos = update(ch[pos][str[i] - 'a']);
	}
	cnt[pos]++;
}

void build(){
	int pos;
	queue<int> que;
	memset(fail, 0, sizeof(fail));
	for(int i = 0; i < 26; i++){
		if(ch[0][i])
			que.push(ch[0][i]);
	}
	while(!que.empty()){
		pos = que.front(); que.pop();
		for(int i = 0; i < 26; i++){
			if(ch[pos][i]){
				fail[ch[pos][i]] = ch[fail[pos]][i];
				que.push(ch[pos][i]);
			}else{
				ch[pos][i] = ch[fail[pos]][i];
			}
		}
	}
}

int query(char *str){
	memset(vis, 0, sizeof(vis));
	int len, pos, res;
	len = strlen(str);
	pos = res = 0;
	for(int i = 0; i < len; i++){
		pos = ch[pos][str[i] - 'a'];
		for(int j = pos; j && !vis[j]; j = fail[j]){
			res += cnt[j];
			vis[j] = 1;
		}
	}
	return res;
}

int main(){
	tot = 0;
	scanf("%d", &n);
	for(int i = 1; i <= n; i++){
		scanf("%s", input + 1);
		insert(input + 1);
	}
	build();
	scanf("%s", input + 1);
	int ans = query(input + 1);
	printf("%d\n", ans);
	return 0;
}
