#include<bits/stdc++.h>
using namespace std;
const int MAXN = 110;
const int MAXL = 3100;

struct node{
	int t, f, h;
	node(int at = 0, int af = 0, int ah = 0){
		t = at; f = af; h = ah;
	}
};

int d, g;
node arr[MAXN];
int f[MAXN][MAXL];

bool cmp(const node &x, const node &y){
	return x.t < y.t;
}

int main(){
	scanf("%d %d", &d, &g);
	int sumlife = 10;
	for(int i = 1; i <= g; i++){
		scanf("%d %d %d", &arr[i].t, &arr[i].f, &arr[i].h);
		sumlife += arr[i].f;
	}
	sort(arr + 1, arr + g + 1, cmp);
	memset(f, 0x80, sizeof(f));
	f[0][10] = 0;
	int ans = 10;
	for(int i = 0; i < g; i++){
		for(int j = 0; j <= sumlife; j++){
			if(f[i][j] < 0) continue;
			if(j >= arr[i + 1].t){
				f[i + 1][j + arr[i + 1].f] = max(f[i + 1][j + arr[i + 1].f], f[i][j]);
				f[i + 1][j] = max(f[i + 1][j], f[i][j] + arr[i + 1].h);
				if(f[i + 1][j] >= d){
					printf("%d\n", arr[i + 1].t);
					return 0;
				}
				ans = max(ans, j + arr[i + 1].f);
			}
		}
	}
	printf("%d\n", ans);
	return 0;
}
