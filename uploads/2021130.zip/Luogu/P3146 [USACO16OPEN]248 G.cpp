#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
const int MAXN = 300;
typedef long long ll;

int n, arr[MAXN];
int f[MAXN][MAXN], ans;

int main(){int _task = 1; //scanf("%d", &_task);
	while(_task--){
		int ans = 0;
		scanf("%d", &n);
		for(int i = 1; i <= n; i++){
			scanf("%d", &arr[i]);
			ans = max(ans, arr[i]);
		}
		memset(f, 0, sizeof(f));
		for(int i = 1; i <= n; i++) f[i][i] = arr[i];
		for(int i = 2; i <= n; i++){
			for(int j = 1; j + i - 1 <= n; j++){
				int endpos = j + i - 1;
				for(int k = j; k <= endpos - 1; k++){
					if(f[j][k] == f[k + 1][endpos]){
						f[j][endpos] = max(f[j][endpos], f[j][k] == f[k + 1][endpos] ? f[j][k] + 1 : f[k + 1][endpos]);
					}
				}
				ans = max(ans, f[j][endpos]);
			}
		}
		printf("%d\n", ans);
	}
	return 0;
}

