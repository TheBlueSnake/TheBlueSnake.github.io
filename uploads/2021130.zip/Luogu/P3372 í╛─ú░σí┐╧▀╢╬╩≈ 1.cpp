#include<bits/stdc++.h>
using namespace std;
const int MAXN = 100100;
typedef long long ll;

ll n, m, arr[MAXN];
ll tr[MAXN << 2], col[MAXN << 2];

void pushup(ll x){
	tr[x] = tr[x << 1] + tr[x << 1 | 1];
}

void pushdown(ll x, ll l, ll r){
	if(col[x]){
		if(l != r){
			ll mid = (l + r) >> 1;
			tr[x << 1] += col[x] * (mid - l + 1);
			tr[x << 1 | 1] += col[x] * (r - (mid + 1) + 1);
			col[x << 1] += col[x];
			col[x << 1 | 1] += col[x];
		}
		col[x] = 0;
	}
}

void build(ll x, ll l, ll r){
	if(l == r){
		tr[x] = arr[l];
		return;
	}else{
		ll mid = (l + r) >> 1;
		build(x << 1, l, mid);
		build(x << 1 | 1, mid + 1, r);
		pushup(x);
	}
}

void modify(ll x, ll l, ll r, ll al, ll ar, ll val){
	if(al <= l && r <= ar){
		tr[x] += val * (r - l + 1);
		col[x] += val;
		return;
	}else{
		ll mid = (l + r) >> 1;
        pushdown(x, l, r);
		if(al <= mid) modify(x << 1, l, mid, al, ar, val);
		if(mid + 1 <= ar) modify(x << 1 | 1, mid + 1, r, al, ar, val);
		pushup(x);
	}
}

ll query(ll x, ll l, ll r, ll al, ll ar){
//	printf(":%d %d\n", l, r);
	if(al <= l && r <= ar){
		return tr[x];
	}else{
		ll mid = (l + r) >> 1, ret = 0;
		pushdown(x, l, r);
		if(al <= mid) ret += query(x << 1, l, mid, al, ar);
		if(mid + 1 <= ar) ret += query(x << 1 | 1, mid + 1, r, al, ar);
		return ret;
	}
}

int main(){
	scanf("%lld %lld", &n, &m);
	memset(tr, 0, sizeof(tr));
	memset(col, 0, sizeof(col));
	for(ll i = 1; i <= n; i++){
		scanf("%lld", &arr[i]);
	}
	build(1, 1, n);
	for(ll x, y, k, opt, i = 1; i <= m; i++){
		scanf("%lld", &opt);
		if(opt == 1){
			scanf("%lld %lld %lld", &x, &y, &k);
			modify(1, 1, n, x, y, k);
		}else{
			scanf("%lld %lld", &x, &y);
			printf("%lld\n", query(1, 1, n, x, y));
		}
	}
	return 0;
}
