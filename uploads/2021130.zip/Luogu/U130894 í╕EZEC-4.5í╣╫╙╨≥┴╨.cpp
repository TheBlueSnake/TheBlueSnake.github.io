#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
const int MAXN = 1000100;
typedef long long ll;

ll n, k, mod;
ll arr[MAXN];

int main(){int _task = 1; //scanf("%d", &_task);
	while(_task--){
		scanf("%lld %lld %lld", &n, &k, &mod);
		for(int i = 1; i <= n; i++){
			scanf("%lld", &arr[i]);
		}
		if(k == 0){
			ll ans = 0;
			for(int i = 1; i <= n; i++)
				ans = (ans + (arr[i] * arr[i] % mod)) % mod;
			printf("%lld\n", ans);
			return 0;
		}
	}
	return 0;
}

