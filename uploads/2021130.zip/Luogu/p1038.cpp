#include <bits/stdc++.h>
using namespace std;
int n,p;
int relu(int x){
    if(x>0)return  x;
    else return 0;
}
struct neural{
    int layer;
    int u;
    int state;
    int to[110];
    int w[110];
    int fr[110];
    int frw[110];
    int frtot=0;
    int tot=0;
}nr[110];
int layer[110][110],tot[110],dep;
int vis[110];
int main(){
    scanf("%d%d",&n,&p);
    for(int i=1;i<=n;i++)
        scanf("%d%d",&nr[i].state,&nr[i].u);
    for(int i=1;i<=p;i++){
        int fr,to,w;
        scanf("%d%d%d",&fr,&to,&w);
        nr[fr].to[++nr[fr].tot]=to;
        nr[fr].w[nr[fr].tot]=w;
        nr[to].frtot++;
        nr[to].fr[nr[to].frtot]=fr;
        nr[to].frw[nr[to].frtot]=w;
    }
    queue<int> q;
    for(int i=1;i<=n;i++)
        if(nr[i].frtot==0){
            nr[i].layer=1;
            layer[1][++tot[1]]=i;
            vis[i]=1;
            q.push(i);
        }
    while(!q.empty()){
        int now=q.front();
        q.pop();
        for(int i=1;i<=nr[now].tot;i++){
            if(!vis[nr[now].to[i]]){
                layer[nr[now].layer+1][++tot[nr[now].layer+1]]=nr[now].to[i];
                nr[nr[now].to[i]].layer=nr[now].layer+1;
                dep=nr[nr[now].to[i]].layer;
                q.push(nr[now].to[i]);
                vis[nr[now].to[i]]=1;
            }
        }
    }
    for(int i=2;i<=dep;i++)
        for(int j=1;j<=tot[i];j++){
            int now=layer[i][j];
            for(int k=1;k<=nr[now].frtot;k++){
                nr[now].state+=(relu(nr[nr[now].fr[k]].state)*nr[now].frw[k]);
            }
            nr[now].state-=nr[now].u;
            // cout<<now<<' '<<nr[now].state<<endl;
        }
    // cout<<tot[dep];
    // cout<<nr[6].state;
    // for(int i=1;i<=n;i++)
    //     cout<<nr[i].state<<' ';
    // cout<<endl;
    int flg=0;
    for(int i=1;i<=tot[dep];i++)
        if(nr[layer[dep][i]].state>0)flg=1;
    if(!flg){
        printf("NULL");
        return 0;
    }
    
    for(int i=1;i<=tot[dep];i++)
        if(nr[layer[dep][i]].state>0)
            printf("%d %d\n",layer[dep][i],nr[layer[dep][i]].state);
    return 0;
}
