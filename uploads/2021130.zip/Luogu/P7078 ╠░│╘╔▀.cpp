#include<bits/stdc++.h>
using namespace std;
const int MAXN = 1000100;
typedef long long ll;
typedef pair<int, int> pii;
typedef long long ll;
#define mp(x, y) make_pair(x, y)

ll n;
ll a[MAXN];

inline ll read(){
	char ch = getchar(); ll res = 0; bool f = 1;
	while('0' > ch || ch > '9') f ^= (ch == '-'), ch = getchar();
	while('0' <= ch && ch <= '9') res = (res << 3) + (res << 1) + (ch - '0'), ch = getchar();
	return f ? res : -res;
}

int main(){
	ll _tsks, flg = 1; _tsks = read(); while(_tsks--){
		if(flg){ flg = 0;
			n = read();
			for(ll i = 1; i <= n; i++){
				a[i] = read() << 32 | i;
			}
		}else{
			ll k;
			ll ki;
			k = read();
			for(int i = 1; i <= k; i++){
				ki = read();
				a[ki] = read() << 32 | ki;
			}
		}
		deque<ll> que1, que2;
		for(ll i = 1; i <= n; i++){
			que1.push_back(a[i]);
		}
		ll ans = 0;
		while(true){
			if(que1.size() + que2.size() == 2){
				ans = 1;
				break;
			}
			ll maxi, mini, id;
			mini = que1.front() >> 32; que1.pop_front();
			if(que2.empty() || (!que1.empty() && que1.back() > que2.back())){
				maxi = que1.back() >> 32;
				id = que1.back() & ((1ll << 32) - 1ll);
				que1.pop_back();
			}else{
				maxi = que2.back() >> 32;
				id = que2.back() & ((1ll << 32) - 1ll);
				que2.pop_back();
			}
			ll nw = (maxi - mini) << 32 | id;
			if(que1.empty() || que1.front() > nw){
				ans = que1.size() + que2.size() + 2;
				ll cnt = 0;
				while(true){
					cnt++;
					if(que1.size() + que2.size() + 1 == 2){
						if(cnt % 2 == 0) ans--;
						break;
					}
					ll maxi2, id2;
					if(que2.empty() || (!que1.empty() && que1.back() > que2.back())){
						maxi2 = que1.back() >> 32;
						id2 = que1.back() & ((1ll << 32) - 1ll);
						que1.pop_back();
					}else{
						maxi2 = que2.back() >> 32;
						id2 = que2.back() & ((1ll << 32) - 1ll);
						que2.pop_back();
					}
					nw = ((maxi2 - (nw >> 32)) << 32) | id2;
					if((que1.empty() || nw < que1.front()) && (que2.empty() || nw < que2.front()));
					else{
						if(cnt % 2 == 0) ans--;
						break;
					}
				}
				break;
			}else{
				que2.push_front(nw);
			}
		}
		printf("%lld\n", ans);
	}
	return 0;
}
