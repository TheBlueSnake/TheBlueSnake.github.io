#include<bits/stdc++.h>
using namespace std;

int n, m;


int main(){
	printf("1\n2\n3\n3\n4\n5\n");
	return 0;
}
