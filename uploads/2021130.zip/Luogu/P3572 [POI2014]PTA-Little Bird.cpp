#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
#define mp(x, y) make_pair(x, y)
const int MAXN = 1000100;
typedef long long ll;
typedef pair<int, int> pii;

int n, k, d[MAXN];
int f[MAXN];
int hd, tl, que[MAXN];

int main(){
	scanf("%d", &n);
	for(int i = 1; i <= n; i++){
		scanf("%d", &d[i]);
	}
	int _task = 1; scanf("%d", &_task);
	while(_task--){
		hd = 1; tl = 0;
		scanf("%d", &k);
		f[1] = 0;
		for(int i = 2; i <= n; i++) f[i] = INF;
		que[++tl] = 1;
		for(int i = 2; i <= n; i++){
			while(hd <= tl && que[hd] < i - k) hd++;
			if(d[que[hd]] <= d[i]) f[i] = f[que[hd]] + 1;
			else f[i] = f[que[hd]];
			while(hd <= tl && (f[que[tl]] > f[i] ||
				  f[que[tl]] == f[i] && d[que[tl]] < d[i])) tl--;
			que[++tl] = i;
//			for(int j = i - 1; j >= i - k; j--){
//				if(j < 0) break;
//				f[i] = min(f[i], f[j] + (d[i] >= d[j]));
//			}
		}
		printf("%d\n", f[n]);
	}
	return 0;
}

