#include<bits/stdc++.h>
using namespace std;
const int MAXN = 200;
const int MAXL = 10100;
const int MAXS = 1000100;

int n;
string str[MAXN], ques;
int edpos[MAXN];
int tot, ch[MAXL][30], cnt[MAXL], fail[MAXL];

int update(int &pos){return pos = (pos == 0 ? ++tot : pos);}

int insert(string s){
	int len = s.size();
	int pos = 0;
	for(int i = 0; i < len; i++){
		pos = update(ch[pos][s[i] - 'a']);
	}
	return pos;
}

void build(){
	int pos;
	queue<int> que;
	memset(fail, 0, sizeof(fail));
	for(int i = 0; i < 26; i++){
		if(ch[0][i])
			que.push(ch[0][i]);
	}
	while(!que.empty()){
		pos = que.front(); que.pop();
		for(int i = 0; i < 26; i++){
			if(ch[pos][i]){
				fail[ch[pos][i]] = ch[fail[pos]][i];
				que.push(ch[pos][i]);
			}else{
				ch[pos][i] = ch[fail[pos]][i];
			}
		}
	}
}

void query(string s){
	memset(cnt, 0, sizeof(cnt));
	int len = s.size();
	int pos = 0;
	for(int i = 0; i < len; i++){
		pos = ch[pos][s[i] - 'a'];
		for(int j = pos; j; j = fail[j]){
			cnt[j]++;
		}
	}
}

int main(){
	while(scanf("%d", &n)){
		if(n == 0) break;
		tot = 0;
		memset(ch, 0, sizeof(ch));
		for(int i = 1; i <= n; i++){
			cin >> str[i];
			edpos[i] = insert(str[i]);
		}
		build();
		cin >> ques;
		query(ques);
		int ans = 0;
		for(int i = 1; i <= n; i++){
			ans = max(ans, cnt[edpos[i]]);
		}
		cout << ans << endl;
		for(int i = 1; i <= n; i++){
			if(cnt[edpos[i]] == ans)
				cout << str[i] << endl;
		}	
	}	
	return 0;
}
