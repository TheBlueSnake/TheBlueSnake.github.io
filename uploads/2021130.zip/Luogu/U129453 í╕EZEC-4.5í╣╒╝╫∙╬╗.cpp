#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
//const int MAXN = ;
typedef long long ll;

ll n, k;
map<ll, ll> mp;

ll solve(ll x, ll y){
	if(mp.find(x) != mp.end()) return mp[x];
	if(x - 2 < y * 2 + 1) return 0;
	else return mp[x] = solve((x + 1) >> 1, y) + solve(x + 1 - ((x + 1) >> 1), y) + 1;
}

int main(){int _task = 1; //scanf("%d", &_task);
	while(_task--){
		scanf("%lld %lld", &n, &k);
		if(k * 2 + 2 > n){
			printf("1\n");
			return 0;
		}else{
			mp.clear();
			ll ans = 2 + solve((n + 2) >> 1, k) + solve(n + 2 - ((n + 2) >> 1), k);
			printf("%lld\n", ans);
		}
	}
	return 0;
}

