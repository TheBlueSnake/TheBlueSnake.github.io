#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
const int MAXN = 300100;
typedef long long ll;

int n, arr[MAXN];
int f[60][MAXN];

int main(){int _task = 1; //scanf("%d", &_task);
	while(_task--){
		int ans = 0;
		scanf("%d", &n);
		for(int i = 1; i <= n; i++){
			scanf("%d", &arr[i]);
			f[arr[i]][i] = i + 1;
		}
		for(int i = 1; i <= 58; i++){
			for(int j = 1; j <= n; j++){
				if(!f[i][j]) f[i][j] = f[i - 1][f[i - 1][j]];
				if(f[i][j]) ans = max(ans, i);	
			}
		}
		printf("%d\n", ans);
	}
	return 0;
}

