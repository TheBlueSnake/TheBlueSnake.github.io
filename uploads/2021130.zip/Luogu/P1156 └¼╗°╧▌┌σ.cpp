#include<bits/stdc++.h>
using namespace std;
const int MAXN = 110;
const int MAXL = 1100;
const int MAXH = 110;

struct node{
	int t, f, h;
	node(int at = 0, int af = 0, int ah = 0){
		t = at; f = af; h = ah;
	}
};

int d, n;
node arr[MAXN];
int f[MAXN][MAXH];//�߶ȶѵ�j��ʱ�����֧������ 

bool cmp(const node &x, const node &y){
	return x.t < y.t;
}

int main(){
	scanf("%d %d", &d, &n);
	for(int i = 1; i <= n; i++){
		scanf("%d %d %d", &arr[i].t, &arr[i].f, &arr[i].h);
	}
	sort(arr + 1, arr + n + 1, cmp);
	memset(f, 0, sizeof(f));
	f[0][0] = 10;
	int ans = 0;
	for(int i = 0; i < n; i++){
		ans = max(ans, f[i][0]);
		for(int j = 0; j <= d; j++){
			if(f[i][j] < arr[i + 1].t){
				continue;
			}
			if(j + arr[i + 1].h >= d){
				printf("%d\n", arr[i + 1].t);
				return 0;
			}
			f[i + 1][j + arr[i + 1].h] = max(f[i + 1][j + arr[i + 1].h], f[i][j]);
			f[i + 1][j] = max(f[i + 1][j], f[i][j] + arr[i + 1].f);
		}
	}
	ans = max(ans, f[n][0]);
	printf("%d\n", ans);
	return 0;
}
