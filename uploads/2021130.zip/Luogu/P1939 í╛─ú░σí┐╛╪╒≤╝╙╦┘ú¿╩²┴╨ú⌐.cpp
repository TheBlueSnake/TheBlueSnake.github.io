#include<bits/stdc++.h>
using namespace std;
const int MAXN = 5;
const int MOD = 1000000007;
typedef long long ll;

struct matrix{
	ll c, r, mat[MAXN][MAXN];
	void clear(int ac = 0, int ar = 0){memset(mat, 0, sizeof(mat)); c = ac; r = ar;}
	matrix operator* (matrix x) const{
		matrix ret; ret.clear(x.c, r);
		for(int i = 1; i <= ret.c; i++){
			for(int j = 1; j <= ret.r; j++){
				for(int k = 1; k <= c; k++){
					(ret.mat[i][j] += (mat[i][k] * x.mat[k][j] % MOD)) %= MOD;
				}
			}
		}
		return ret;
	}
};

ll T, n;
matrix A, F;

matrix I(int x){
	matrix ret; ret.clear(x, x);
	for(int i = 1; i <= x; i++) ret.mat[i][i] = 1;
	return ret;
}

matrix qpow(matrix &init, matrix x, ll pwr){
	matrix ret = init;
	while(pwr){
		if(pwr & 1) ret = ret * x;
		x = x * x;
		pwr >>= 1;
	}
	return ret;
}

int main(){
	A.clear(1, 3);
	A.mat[1][1] = 1;
	F.clear(3, 3); 
	F.mat[1][1] = F.mat[1][2] = F.mat[2][3] = F.mat[3][1] = 1;
	scanf("%lld", &T); while(T--){
		scanf("%d", &n);
		matrix ans = qpow(A, F, n - 1);
		printf("%lld\n", ans.mat[1][1]);
	}
	return 0;
}
