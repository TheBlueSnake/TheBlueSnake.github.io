#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
const int MAXN = 2100;
typedef long long ll;

int n, m;
int mp[MAXN][MAXN], f[MAXN][MAXN], g[MAXN][MAXN];

bool solve(int mid){
	memset(g, 0, sizeof(g));
	g[1][1] = 0;
	for(int i = 1; i <= n; i++)
		for(int j = 1; j <= m; j++){
			if(i == 1 && j == 1) continue;
			g[i][j] = max(max(g[i - 1][j], g[i][j - 1]) + mp[i][j], max(f[i - 1][j], f[i][j - 1]));
		}
	printf("%d\n", g[n][m]);
	return g[n][m] >= mid;
}

int main(){int _task = 1; //scanf("%d", &_task);
	while(_task--){
		scanf("%d %d", &n, &m);
		for(int i = 1; i <= n; i++)
			for(int j = 1; j <= m; j++){
				scanf("%d", &mp[i][j]);
			}
		memset(f, 0, sizeof(f));
		for(int i = 1; i <= n; i++){
			for(int j = 1; j <= m; j++){
				f[i][j] = max(f[i - 1][j], f[i][j - 1]) + mp[i][j];
			}
		}
		int lft = 1, rht = f[n][m], mid, ans;
		while(lft <= rht){
			mid = (lft + rht) >> 1;
			if(solve(mid)) ans = mid, rht = mid - 1;
			else lft = mid + 1;
		}
	}
	return 0;
}

