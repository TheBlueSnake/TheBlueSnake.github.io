#include<bits/stdc++.h>
using namespace std;
const int MAXN = 100100;
typedef long long ll;

ll n, m, p, arr[MAXN];
ll tr[MAXN << 2], col1[MAXN << 2], col2[MAXN << 2];

void pushup(ll x){
	tr[x] = (tr[x << 1] + tr[x << 1 | 1]) % p;
}

void pushdown(ll x, ll l, ll r){
	if(col1[x] || col2[x] != 1){
		if(l != r){
			ll mid = (l + r) >> 1;
			tr[x << 1] = (tr[x << 1] * col2[x] % p + col1[x] * (mid - l + 1) % p) % p;
			tr[x << 1 | 1] = (tr[x << 1 | 1] * col2[x] % p + col1[x] * (r - (mid + 1) + 1) % p) % p;
			col1[x << 1] = (col1[x << 1] * col2[x] % p + col1[x]) % p;
			col1[x << 1 | 1] = (col1[x << 1 | 1] * col2[x] % p + col1[x]) % p;
			col2[x << 1] = (col2[x << 1] * col2[x]) % p;
			col2[x << 1 | 1] = (col2[x << 1 | 1] * col2[x]) % p;
		}
		col1[x] = 0;
		col2[x] = 1;
	}
}

void build(ll x, ll l, ll r){
	col1[x] = 0;
	col2[x] = 1;
	if(l == r){
		tr[x] = arr[l];
	}else{
		int mid = (l + r) >> 1;
		build(x << 1, l, mid);
		build(x << 1 | 1, mid + 1, r);
		pushup(x);
	}
}

void modify_mul(ll x, ll l, ll r, ll al, ll ar, ll val){
	if(al <= l && r <= ar){
		tr[x] = (tr[x] * val) % p;
		col1[x] = (col1[x] * val) % p;
		col2[x] = (col2[x] * val) % p;
		return;
	}else{
		ll mid = (l + r) >> 1;
		pushdown(x, l, r);
		if(al <= mid) modify_mul(x << 1, l, mid, al, ar, val);
		if(mid + 1 <= ar) modify_mul(x << 1 | 1, mid + 1, r, al, ar, val);
		pushup(x);
	}
}

void modify_add(ll x, ll l, ll r, ll al, ll ar, ll val){
	if(al <= l && r <= ar){
		tr[x] = (tr[x] + val * (r - l + 1)) % p;
		col1[x] = (col1[x] + val) % p;
	}else{
		ll mid = (l + r) >> 1;
		pushdown(x, l, r);
		if(al <= mid) modify_add(x << 1, l, mid, al, ar, val);
		if(mid + 1 <= ar) modify_add(x << 1 | 1, mid + 1, r, al, ar, val);
		pushup(x);
	}
}

ll query(ll x, ll l, ll r, ll al, ll ar){
	if(al <= l && r <= ar){
		return tr[x];
	}else{
		ll mid = (l + r) >> 1, ret = 0;
		pushdown(x, l, r);
		if(al <= mid) ret = (ret + query(x << 1, l, mid, al, ar)) % p;
		if(mid + 1 <= ar) ret = (ret + query(x << 1 | 1, mid + 1, r, al, ar)) % p;
		return ret;
	}
}

void prt(ll x, ll l, ll r){
	printf(":(%lld %lld %lld) %lld %lld %lld\n", x, l, r, tr[x], col1[x], col2[x]);
	if(l != r){
		ll mid = (l + r) >> 1;
		prt(x << 1, l, mid);
		prt(x << 1 | 1, mid + 1, r);
	}
}

int main(){
	scanf("%lld %lld %lld", &n, &m, &p);
	memset(tr, 0, sizeof(tr));
	for(ll i = 1; i <= n; i++){
		scanf("%lld", &arr[i]);
	}
	build(1, 1, n);
	for(ll opt, x, y, k, i = 1; i <= m; i++){
		scanf("%lld", &opt);
//		prt(1, 1, n);
		if(opt == 1){
			scanf("%lld %lld %lld", &x, &y, &k);
			modify_mul(1, 1, n, x, y, k);
		}else if(opt == 2){
			scanf("%lld %lld %lld", &x, &y, &k);
			modify_add(1, 1, n, x, y, k);
		}else{
			scanf("%lld %lld", &x, &y);
			printf("%lld\n", query(1, 1, n, x, y));
		}
	}
	return 0;
}
