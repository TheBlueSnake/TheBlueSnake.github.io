#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFll 0x3f3f3f3f3f3f3f3fll
#define mp(x, y) make_pair(x, y)
const int MAXN = 300100;
const int MAXM = 600100;
typedef long long ll;
typedef pair<int, int> pii;

int n, m;
int tot, frt[MAXN], nxt[MAXM], ed[MAXM];
int ans, f[MAXN], cnt[MAXN];

void add_edge(int u, int v){
	ed[++tot] = v;
	nxt[tot] = frt[u]; frt[u] = tot;
}

void update(int &maxi, int &secmaxi, int val){
	if(val <= secmaxi) return;
	else if(val <= maxi){
		secmaxi = val;
		return;
	}else{
		secmaxi = maxi;
		maxi = val;
		return;
	}
}

void dfs(int u, int fa){
	int v, maxi = 0, secmaxi = 0;
	cnt[u] = 0;
	for(int i = frt[u]; i; i = nxt[i]){
		v = ed[i];
		if(v != fa){
			cnt[u]++;
			dfs(v, u);
			update(maxi, secmaxi, f[v]);
		}
	}
	ans = max(ans, maxi + secmaxi + cnt[u] + 1 + (fa != 0));
	f[u] = maxi + cnt[u];
}

int main(){int _task = 1; //scanf("%d", &_task);
while(_task--){
	scanf("%d %d", &n, &m);
	for(int u, v, i = 1; i <= m; i++){
		scanf("%d %d", &u, &v);
		add_edge(u, v);
		add_edge(v, u);
	}
	memset(f, 0, sizeof(f));
	dfs(1, 0);
	printf("%d\n", ans);
}
	return 0;
}

