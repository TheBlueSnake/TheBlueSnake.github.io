#include<bits/stdc++.h>
using namespace std;
const int MAXN = 110;
const int MAXM = 10100;

struct node{
	int a, b;
	node(int aa = 0, int ab = 0){
		a = aa; b = ab;
	}
};

int n;
node arr[MAXN];
int sumli, sumsz, ansk, tmps;
int f[MAXN][MAXM];

bool cmp(node &x, node &y){
	return x.b > y.b || x.b == y.b && x.a > y.a;
}

int main(){
	scanf("%d", &n);
	for(int i = 1; i <= n; i++){
		scanf("%d", &arr[i].a);
		sumli += arr[i].a;
	}
	for(int i = 1; i <= n; i++){
		scanf("%d", &arr[i].b);
	}
	sort(arr + 1, arr + n + 1, cmp);
	ansk = 0;
	tmps = sumli;
	for(int i = 1; i <= n; i++){
		if(tmps > arr[i].b){
			tmps -= arr[i].b;
		}else{
			ansk = i;
			break;
		}
	}
	printf("%d ", ansk);
	for(int i = 1; i <= ansk; i++) sumsz += arr[i].b;
	memset(f, 0x80, sizeof(f));
	f[0][0] = 0;
	for(int i = 1; i <= n; i++){
		for(int j = ansk; j >= 1; j--){
			for(int k = sumsz; k >= arr[i].b; k--){
				f[j][k] = max(f[j][k], f[j - 1][k - arr[i].b] + arr[i].a);
			}
		}
	}
	int ans = 0;
	for(int i = sumli; i <= sumsz; i++){
		ans = max(ans, f[ansk][i]);
	}
	printf("%d\n", sumli - ans);
	return 0;
}
