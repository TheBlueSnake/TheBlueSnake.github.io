#include<bits/stdc++.h>
using namespace std;
const int MAXN = 64;

int n;
char str[MAXN];
int f[MAXN][MAXN][2];

bool chk(int i, int j){
	if((j - i + 1) % 2 != 0) return false;
	int mid = (i + j) >> 1;
	for(int p = i; p <= mid; p++){
		if(str[p] != str[p + mid - i + 1]){
			return false;
		}	
	}
	return true;
}

int main(){
	scanf("%s", str + 1);
	n = strlen(str + 1);
	memset(f, 0x3f, sizeof(f));
	for(int i = 1; i <= n; i++)
		for(int j = i; j <= n; j++)
			f[i][j][0] = f[i][j][1] = j - i + 1;
	for(int l = 2; l <= n; l++){
		for(int i = 1; i + l - 1 <= n; i++){
			int j = i + l - 1;
			if(chk(i, j)){
				f[i][j][0] = min(f[i][(i + j) / 2][0] + 1, f[i][j][0]);
			}
			for(int k = i; k <= j - 1; k++){
				f[i][j][0] = min(f[i][j][0], f[i][k][0] + j - (k + 1) + 1);
				f[i][j][1] = min(
							 f[i][j][1],
							 min(f[i][k][0], f[i][k][1]) + min(f[k + 1][j][0], f[k + 1][j][1]) + 1
							 );
			}
		}
	}
	printf("%d\n", min(f[1][n][0], f[1][n][1]));
	return 0;
}
