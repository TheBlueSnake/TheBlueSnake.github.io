#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
const int MAXN = 5100;
const int MAXM = 5100;
typedef long long ll;

ll n, m, k, arr[MAXN];
ll hd[MAXM], tl[MAXM], que[MAXM][MAXN];
ll f[MAXN][MAXM];

int main(){
	scanf("%lld %lld %lld", &n, &k, &m);
	for(int i = 1; i <= n; i++){
		scanf("%lld", &arr[i]);
	}
	memset(f, 0x80, sizeof(f));
	f[0][0] = 0;
	for(ll i = 1; i <= m; i++) hd[i] = 1;
	for(ll i = 1; i <= m; i++) tl[i] = 0;
	memset(que, 0, sizeof(que));
	que[0][++tl[0]] = 0;
	for(ll i = 1; i <= n; i++){
		for(ll j = m; j >= 1; j--){
			while(hd[j - 1] <= tl[j - 1] && que[j - 1][hd[j - 1]] < i - k) hd[j - 1]++;
			if(hd[j - 1] <= tl[j - 1]){
				f[i][j] = f[que[j - 1][hd[j - 1]]][j - 1] + arr[i];
				while(hd[j] <= tl[j] && f[que[j][tl[j]]][j] <= f[i][j]) tl[j]--;
				que[j][++tl[j]] = i;
			}
		}
	}
	ll ans = -INF;
	for(ll i = n - k + 1; i <= n; i++){
		ans = max(ans, f[i][m]);
	}
	if(ans == -INF) printf("-1\n");
	else printf("%lld\n", ans);
	return 0;
}
