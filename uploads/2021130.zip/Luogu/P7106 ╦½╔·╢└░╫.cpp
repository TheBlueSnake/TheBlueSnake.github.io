#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFll 0x3f3f3f3f3f3f3f3fll
#define mp(x, y) make_pair(x, y)
const int MAXN = 10;
typedef long long ll;
typedef pair<int, int> pii;

char str[MAXN];
int todig(char c){
	if('0' <= c && c <= '9') return c - '0';
	else return c - 'A' + 10;
}
char tohex(int val){
	if(val <= 9) return '0' + val;
	else return 'A' + val - 10;
}

int main(){//freopen(".in", "r", stdin); freopen(".out", "w", stdout);
int _task = 1; //scanf("%d", &_task);
while(_task--){
	scanf("%s", str + 1);
	int r, g, b;
	r = todig(str[2]) * 16 + todig(str[3]);
	g = todig(str[4]) * 16 + todig(str[5]);
	b = todig(str[6]) * 16 + todig(str[7]);
//	printf(":%d %d %d\n", r, g, b);
	r = 255 - r;
	g = 255 - g;
	b = 255 - b;
//	printf(":%d %d %d\n", r, g, b);
	printf("#");
	printf("%c%c", tohex(r / 16), tohex(r % 16));
	printf("%c%c", tohex(g / 16), tohex(g % 16));
	printf("%c%c", tohex(b / 16), tohex(b % 16));
	printf("\n");
}
	return 0;
}

