#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFll 0x3f3f3f3f3f3f3f3fll
#define mp(x) make_pair(x)
const int MAXN = 7200;
typedef long long ll;
typedef pair<int, int> pii;

int n, arr[MAXN];
ll f[MAXN][MAXN];

int main(){int _task = 1; scanf("%d", &_task);
while(_task--){
	scanf("%d", &n);
	for(int i = 1; i <= n; i++){
		scanf("%d", &arr[i]);
	}
	for(int i = 1; i <= n; i++){
		f[i][i] = 0;
		f[i][i + 1] = arr[i];
	}
	for(int l = 3; l <= n; l++){
		for(int i = 1; i + l - 1 <= n; i++){
			int j = i + l - 1;
			for(int k = i + 1; k <= j - 1; k++){
				f[i][j] = min(f[i][j], max(f[i][k], f[k + 1][j]) + arr[k]);
			}
		}
	}
	printf("%lld\n", f[1][n]);
}
	return 0;
}
