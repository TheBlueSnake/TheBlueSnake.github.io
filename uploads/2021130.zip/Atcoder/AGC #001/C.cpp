#include<bits/stdc++.h>
using namespace std;
const int MAXN = 2100;
const int MAXM = 4100;

int n, k;
int tot, frt[MAXN], nxt[MAXM]; int ed[MAXM];
int deg[MAXN], dep[MAXN], cnt[MAXN], ans;

inline void add_edge(int u, int v){
	ed[++tot] = v; deg[v]++;
	nxt[tot] = frt[u]; frt[u] = tot;
}
void dfs(int u, int fa){
	int v;
	for(int i = frt[u]; i; i = nxt[i]){
		v = ed[i];
		if(v != fa){
			dep[v] = dep[u] + 1;
			dfs(v, u);
		}
	}
}

int main(){
	scanf("%d %d", &n, &k);
	for(int u, v, i = 1; i <= n - 1; i++){
		scanf("%d %d", &u, &v);
		add_edge(u, v);
		add_edge(v, u);
	}
	int root = -1;
	for(int i = 1; i <= n; i++){
		if(deg[i] == 1 && root == -1){
			root = i;
			break;
		}
	}
	dep[root] = 0;
	dfs(root, -1);
	memset(cnt, 0, sizeof(cnt));
	int maxdep = 0;
	for(int i = 1; i <= n; i++){
		cnt[dep[i]]++;
		maxdep = max(maxdep, dep[i]);
	}
	ans = 0;
//	int blablabla = 0;
	for(int lft = 1, rht = maxdep, i = 0; maxdep - i >= k + 1; i++){
		if(cnt[lft] > cnt[rht]) ans += cnt[rht--];
		else ans += cnt[lft++];
//		printf(":%d\n", ++blablabla);
	}
	printf("%d\n", ans);
	return 0;
}
