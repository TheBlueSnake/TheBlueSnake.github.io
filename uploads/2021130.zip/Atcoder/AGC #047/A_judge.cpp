#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MAXN = 200100;

string input;
int n;
ll arr[MAXN];
int cnt2[MAXN], cnt5[MAXN];
ll ans;

int main(){
	scanf("%d", &n);
	memset(cnt2, 0, sizeof(cnt2));
	memset(cnt5, 0, sizeof(cnt5));
	for(int i = 1; i <= n; i++){
		cin >> input;
		int flag = -1;
		int length = input.size();
		for(int j = 0; j < length; j++){
			if(input[j] == '.'){
				flag = 0;
				continue;
			}
			arr[i] = arr[i] * 10 + input[j] - '0';
			if(flag != -1) flag++;
		}
		if(flag == -1) flag = 0;
		for(; flag < 9; flag++) arr[i] = arr[i] * 10;
//		printf(":%lld\n", arr[i]);
		while(arr[i] % 2 == 0){
			cnt2[i]++;
			arr[i] /= 2;
		}
		while(arr[i] % 5 == 0){
			cnt5[i]++;
			arr[i] /= 5;
		}
	}
	for(int i = 1; i <= n; i++)
		for(int j = i + 1; j <= n; j++){
			if(cnt2[i] + cnt2[j] >= 18 && cnt5[i] + cnt5[j] >= 18){
				ans++;
			}
		}
		printf("%lld\n", ans);
	return 0;
}
