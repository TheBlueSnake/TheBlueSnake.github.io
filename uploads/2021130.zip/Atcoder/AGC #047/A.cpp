#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MAXN = 200100;

string input;
int n;
ll arr[MAXN];
int cnt2[MAXN], cnt5[MAXN], mp[32][32];
ll ans;

int main(){
	scanf("%d", &n);
	memset(cnt2, 0, sizeof(cnt2));
	memset(cnt5, 0, sizeof(cnt5));
	memset(mp, 0, sizeof(mp));
	for(int i = 1; i <= n; i++){
		cin >> input;
		int flag = -1;
		int length = input.size();
		for(int j = 0; j < length; j++){
			if(input[j] == '.'){
				flag = 0;
				continue;
			}
			arr[i] = arr[i] * 10 + input[j] - '0';
			if(flag != -1) flag++;
		}
		if(flag == -1) flag = 0;
		for(; flag < 9; flag++) arr[i] = arr[i] * 10;
		while(arr[i] % 2 == 0){
			cnt2[i]++;
			arr[i] /= 2;
		}
		while(arr[i] % 5 == 0){
			cnt5[i]++;
			arr[i] /= 5;
		}
		if(cnt2[i] > 18) cnt2[i] = 18;
		if(cnt5[i] > 18) cnt5[i] = 18;
		mp[cnt2[i]][cnt5[i]]++;
	}
	//18 * "0" = (18 * "2") * (18 * "5")
//	for(int i = 18; i >= 0; i--){
//		for(int j = 18; j >= 0; j--){
//			mp[i][j] += mp[i + 1][j] + mp[i][j + 1] - mp[i + 1][j + 1];
//		}
//	}
//	for(int i = 1; i <= 18; i++){
//		for(int j = 1; j <= 18; j++) 
//			printf("%d ", mp[i][j]);
//		printf("\n");
//	}
	ans = 0;
	for(int i = 1; i <= n; i++){
		mp[cnt2[i]][cnt5[i]]--;
		for(int j = 18 - cnt2[i]; j <= 18; j++)
			for(int k = 18 - cnt5[i]; k <= 18; k++)
				ans += mp[j][k];
//		ans += mp[18 - cnt2[i]][18 - cnt5[i]];
//		if(cnt2[i] >= 9 && cnt5[i] >= 9) ans--;
	}
	printf("%lld\n", ans);
	return 0;
}
