#include<bits/stdc++.h>
using namespace std;
const int MAXN = 10;
const int MAXM = 10;

int h, w, k, mp[MAXN][MAXM];
int row[MAXN], col[MAXM], ans;

char getch(){
	char tmps = getchar();
	while(tmps != '#' && tmps != '.') tmps = getchar();
	return tmps;
}

int main(){
	scanf("%d %d %d", &h, &w, &k); k = -k;
	for(int i = 0; i < h; i++)
		for(int j = 0; j < w; j++){
			mp[i][j] = getch() == '#' ? 1 : 0;
			k += mp[i][j];
		}
	for(int i = 0; i < h; i++)
		for(int j = 0; j < w; j++)
			row[i] += mp[i][j];
	for(int i = 0; i < w; i++)
		for(int j = 0; j < h; j++)
			col[i] += mp[j][i];
	ans = 0;
	for(int i = 0; i < (1 << h); i++)
		for(int j = 0; j < (1 << w); j++){
			int tmps = k;
			for(int pi = 0; pi < h; pi++)
				if(i & (1 << pi)) tmps -= row[pi];
			for(int pj = 0; pj < w; pj++)
				if(j & (1 << pj)) tmps -= col[pj];
			for(int pi = 0; pi < h; pi++)
				for(int pj = 0; pj < w; pj++){
					if((i & (1 << pi)) && (j & (1 << pj)))
						tmps += mp[pi][pj];
				}
//			printf("%d %d %d\n", i, j, tmps);
			if(tmps == 0) ans++;
		}
	printf("%d\n", ans);
	return 0;
}
