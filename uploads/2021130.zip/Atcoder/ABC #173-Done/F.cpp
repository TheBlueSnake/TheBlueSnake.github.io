#include<bits/stdc++.h>
using namespace std;
const int MAXN = 200100;
const int MAXM = 200100;
typedef long long ll;

struct node{ll u, v; node(ll au = 0, ll av = 0){u = au; v = av;}};

ll n;
node ed[MAXM];
ll ans = 0;

int main(){
	scanf("%lld", &n);
	for(int i = 1; i <= n - 1; i++){
		scanf("%lld %lld", &ed[i].u, &ed[i].v);
		if(ed[i].u > ed[i].v) swap(ed[i].u, ed[i].v);
	}
	for(ll i = 1; i <= n; i++) ans = ans + i * (n - i + 1);
	for(ll i = 1; i <= n - 1; i++) ans = ans - ed[i].u * (n - ed[i].v + 1);
	printf("%lld\n", ans);
	return 0;
}
