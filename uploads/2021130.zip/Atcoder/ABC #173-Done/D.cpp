#include<bits/stdc++.h>
using namespace std;
const int MAXN = 200100;
typedef long long ll;

ll n, val[MAXN << 1];
ll ans = 0;

bool cmp(const ll &x, const ll &y){return x > y;}

int main(){
	scanf("%lld", &n);
	for(ll i = 1; i <= n; i++) scanf("%lld", &val[i]);
	sort(val + 1, val + n + 1, cmp);
	for(ll i = n; i >= 1; i--) val[i << 1] = val[i], val[(i << 1) - 1] = val[i];
//	for(int i = 1; i <= (n << 1); i++) printf("%d ", val[i]); printf("\n");
	for(ll i = 1; i <= n; i++) ans += val[i];
	ans -= val[1];
	printf("%lld\n", ans);
	return 0;
}
