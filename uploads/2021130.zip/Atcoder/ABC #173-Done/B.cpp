#include<bits/stdc++.h>
using namespace std;

int n;
int cnt[4];
string str;

int main(){
	memset(cnt, 0, sizeof(cnt));
	scanf("%d", &n);
	for(int i = 1; i <= n; i++){
		cin >> str;
		if(str == "AC") cnt[0]++;
		else if(str == "WA") cnt[1]++;
		else if(str == "TLE") cnt[2]++;
		else if(str == "RE") cnt[3]++;
	}
	printf("AC x %d\n", cnt[0]);
	printf("WA x %d\n", cnt[1]);
	printf("TLE x %d\n", cnt[2]);
	printf("RE x %d\n", cnt[3]);
	return 0;
}
