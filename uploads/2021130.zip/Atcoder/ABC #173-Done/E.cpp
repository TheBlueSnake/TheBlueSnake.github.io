#include<bits/stdc++.h>
using namespace std;
const int MAXN = 200100;
const int MOD = 1e9 + 7;
typedef long long ll;

ll n, k, arr[MAXN], ans, flg;

inline ll fabs(const ll &x){return x < 0 ? -x : x;}
bool cmp(const ll &x, const ll &y){return fabs(x) > fabs(y);}
ll qpow(ll x, ll pwr){
	if(pwr == 0) return 1;
	ll tmps = qpow(x, pwr >> 1);
	if(pwr & 1) return (tmps * tmps % MOD) * x % MOD;
	else return tmps * tmps % MOD;
}

int main(){
	scanf("%lld %lld", &n, &k);
	bool flag = false;
	for(ll i = 1; i <= n; i++){
		scanf("%lld", &arr[i]);
		if(arr[i] > 0) flag = true;
	}
	sort(arr + 1, arr + n + 1, cmp);
	if(!flag && k % 2 == 1){
		ans = 1;
		for(ll i = n; i >= n - k + 1; i--)
			ans = ans * arr[i] % MOD;
		ans = (ans + MOD) % MOD;
		printf("%lld\n", ans);
		return 0;
	}
	if(n == k){
		ans = 1;
		for(ll i = 1; i <= k; i++) ans = ans * arr[i] % MOD;
		printf("%lld\n", (ans + MOD) % MOD);
		return 0;
	}
	ans = 1; flg = 1;
	for(ll i = 1; i <= k; i++){
		if(arr[i] < 0) flg = flg ^ 1;
		ans = ans * fabs(arr[i]) % MOD;
	}
	if(flg) printf("%lld\n", ans);
	else{
		if(ans == 0){
			printf("%lld\n", 0);
			return 0;
		}
		ll next_pos = -1, next_neg = -1;
		for(ll i = k + 1; i <= n; i++){
			if(arr[i] > 0 && next_pos == -1) next_pos = arr[i];
			else if(arr[i] <= 0 && next_neg == -1) next_neg = -arr[i];
		}
		ll last_pos = -1, last_neg = -1;
		for(ll i = k; i >= 1; i--){
			if(arr[i] > 0 && last_pos == -1) last_pos = arr[i];
			else if(arr[i] < 0 && last_neg == -1) last_neg = -arr[i];
		}
//		printf(":%lld %lld %lld %lld %lld\n", ans, last_pos, last_neg, next_pos, next_neg);
		if((last_pos == -1 || next_neg == -1) && (next_pos == -1 || last_neg == -1)) ans = (-ans + MOD) % MOD;
		else if(last_neg == -1 || next_pos == -1) ans = (ans * qpow(last_pos, MOD - 2) % MOD) * next_neg % MOD;
		else if(last_pos == -1 || next_neg == -1) ans = (ans * qpow(last_neg, MOD - 2) % MOD) * next_pos % MOD;
		else if(last_pos * next_pos > last_neg * next_neg) ans = (ans * qpow(last_neg, MOD - 2) % MOD) * next_pos % MOD;
		else ans = (ans * qpow(last_pos, MOD - 2) % MOD) * next_neg % MOD;
		printf("%lld\n", ans);
	}
	return 0;
}
