#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
const int MAXN = 110;
typedef long long ll;

int n, arr[MAXN], cnt[MAXN];

bool cmp(const int &x, const int &y){
	return x < y;
}

int main(){int _task = 1; scanf("%d", &_task);
	while(_task--){
		scanf("%d", &n);
		for(int i = 1; i <= n; i++)
			scanf("%d", &arr[i]);
		memset(cnt, 0, sizeof(cnt));
		for(int i = 1; i <= n; i++)
			cnt[arr[i]]++;
		int ans = 0, flag = 0;
//		printf(":%d\n", cnt[0]);
		for(int i = 0; i <= 100; i++){
//			printf(":%d %d %d\n", i, ans, flag);
			if(flag == 0){
				if(cnt[i] >= 2){
					continue;
				}else if(cnt[i] == 1){
					ans += i;
					flag = 1;
				}else{
					ans += i + i;
					flag = 2;
				}
			}else if(flag == 1){
				if(cnt[i] >= 1){
					continue;
				}else if(cnt[i] == 0){
					ans += i;
					flag = 2;
				}
			}
			if(flag == 2) break;
		}
		printf("%d\n", ans);
	}
	return 0;
}

