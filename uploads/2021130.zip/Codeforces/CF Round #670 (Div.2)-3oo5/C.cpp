#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
const int MAXN = 100100;

int n;
vector<int> ed[MAXN];
int fa[MAXN], sz[MAXN], mx[MAXN], cent1, cent2, tmps;

inline void add_edge(int u, int v){
	ed[u].push_back(v);
}

void dfs1(int u, int f){
	int v, len = ed[u].size();
	sz[u] = 1;
	fa[u] = f;
	for(int i = 0; i <= len - 1; i++){
		v = ed[u][i];
		if(v != f){
			dfs1(v, u);
			sz[u] += sz[v];
			mx[u] = max(mx[u], sz[v]);
		}
	}
	mx[u] = max(mx[u], n - sz[u]);
	if(mx[u] < mx[cent1]){
		cent1 = u;
		cent2 = 0;
	}else if(mx[u] == mx[cent1]){
		cent2 = u;
	}
}

void dfs2(int u, int nope, int f){
	int v, len = ed[u].size();
	fa[u] = f;
//	printf("::%d, %d\n", u, len);
	if(len == 1){
		tmps = u;
		return;
	}
	for(int i = 0; i < len; i++){
		v = ed[u][i];
		if(v != nope && v != f){
			dfs2(v, nope, u);
			break;
		}
	}
}

int main(){
	int tsk = 1; scanf("%d", &tsk);
	while(tsk--){
		cent1 = cent2 = 0;
		memset(sz, 0, sizeof(sz));
		memset(mx, 0, sizeof(mx));
		mx[0] = INF;
		scanf("%d", &n);
		for(int i = 1; i <= n; i++) ed[i].clear();
		for(int u, v, i = 1; i <= n - 1; i++){
			scanf("%d %d", &u, &v);
			add_edge(u, v);
			add_edge(v, u);
		}
		dfs1(1, 0);
//		printf(":%d %d\n", cent1, cent2);
//		printf(":"); for(int i = 1; i <= n; i++) printf("%d ", sz[i]); printf("\n");
		if(cent2 == 0){
			printf("%d %d\n", 1, ed[1][0]);
			printf("%d %d\n", 1, ed[1][0]);
			continue;
		}
		if(fa[cent1] == cent2) swap(cent1, cent2);
		tmps = -1;
		dfs2(cent1, cent2, 0);
		printf("%d %d\n", fa[tmps], tmps);
		printf("%d %d\n", tmps, cent2);
	}
	return 0;	
}

