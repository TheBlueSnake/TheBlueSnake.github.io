#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFll 0x3f3f3f3f3f3f3f3fll
const int MAXN = 100100;
typedef long long ll;

ll n, arr[MAXN], pos[MAXN], neg[MAXN];

bool cmp(const int &x, const int &y){
	return abs(x) > abs(y);
}

int main(){int _task = 1; scanf("%d", &_task);
	while(_task--){
		scanf("%lld", &n);
		for(ll i = 1; i <= n; i++){
			scanf("%lld", &arr[i]);
		}
		ll pcnt = 0, ncnt = 0;
		for(int i = 1; i <= n; i++){
			if(arr[i] >= 0) pos[++pcnt] = arr[i];
			else neg[++ncnt] = arr[i];
		}
		sort(pos + 1, pos + pcnt + 1, cmp);
		sort(neg + 1, neg + ncnt + 1, cmp);
		ll ans = -INFll, tmps = 1ll;
		if(pcnt >= 5){
			tmps = 1ll;
			for(int i = 1; i <= 5; i++) tmps = tmps * pos[i];
			ans = max(ans, tmps);
//			printf(":5 %d\n", tmps);
		}
		if(pcnt >= 4 && ncnt >= 1){
			tmps = 1ll;
			for(int i = pcnt; i >= pcnt - 3; i--) tmps = tmps * pos[i];
			for(int i = ncnt; i >= ncnt; i--) tmps = tmps * neg[i];
			ans = max(ans, tmps);
//			printf(":4 %d\n", tmps);
		}
		if(pcnt >= 3 && ncnt >= 2){
			tmps = 1ll;
			for(int i = 1; i <= 3; i++) tmps = tmps * pos[i];
			for(int i = 1; i <= 2; i++) tmps = tmps * neg[i];
			ans = max(ans, tmps);
//			printf(":3 %d\n", tmps);
		}
		if(pcnt >= 2 && ncnt >= 3){
			tmps = 1ll;
			for(int i = pcnt; i >= pcnt - 1; i--) tmps = tmps * pos[i];
			for(int i = ncnt; i >= ncnt - 2; i--) tmps = tmps * neg[i];
			ans = max(ans, tmps);
//			printf(":2 %d\n", tmps);
		}
		if(pcnt >= 1 && ncnt >= 4){
			tmps = 1ll;
			for(int i = 1; i <= 1; i++) tmps = tmps * pos[i];
			for(int i = 1; i <= 4; i++) tmps = tmps * neg[i];
			ans = max(ans, tmps);
//			printf(":1 %d\n", tmps);
		}
		if(ncnt >= 5){
			tmps = 1ll;
			for(int i = ncnt; i >= ncnt - 4; i--) tmps = tmps * neg[i];
			ans = max(ans, tmps);
//			printf(":0 %d\n", tmps);
		}
		printf("%lld\n", ans);
	}
	return 0;
}

