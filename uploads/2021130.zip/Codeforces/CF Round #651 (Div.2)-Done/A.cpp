#include<bits/stdc++.h>
using namespace std;
 
int T;
int n;
 
int main(){
	scanf("%d", &T); while(T--){
		scanf("%d", &n);
		printf("%d\n", n >> 1);
	}
	return 0;
}
