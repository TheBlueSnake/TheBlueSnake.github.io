#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
 
ll T;
ll n;
 
int main(){
	scanf("%lld", &T); while(T--){
		scanf("%lld", &n); ll ans = 0;
		ll remainer = n, two_pwr = 1, pwr = 0;
		if(remainer == 1){printf("FastestFinger\n"); continue;}
		else if(remainer % 2 == 1){printf("Ashishgup\n"); continue;}
		while(remainer % 2 == 0) two_pwr <<= 1, remainer >>= 1;
		for(int i = 3; i * i <= remainer; i++)
			while(remainer % i == 0) pwr++, remainer /= i;
		if(remainer != 1) pwr++;
		if(pwr == 0 && two_pwr == 2){printf("Ashishgup\n"); continue;}
		else if(pwr == 0 && two_pwr != 2){printf("FastestFinger\n"); continue;}
		else if(pwr == 1 && two_pwr == 2){printf("FastestFinger\n"); continue;}
		else if(pwr == 1 && two_pwr != 2){printf("Ashishgup\n"); continue;}
		else if(pwr >= 2 && two_pwr == 2){printf("Ashishgup\n"); continue;}
		else if(pwr >= 2 && two_pwr != 2){printf("Ashishgup\n"); continue;}
	}
	return 0;
}
