#include<bits/stdc++.h>
using namespace std;
const int MAXN = 2100;
 
int T;
int n, arr[MAXN], odd[MAXN], even[MAXN];
 
int main(){
	scanf("%d", &T); while(T--){
		scanf("%d", &n); n <<= 1;
		odd[0] = even[0] = 0;
		for(int i = 1; i <= n; i++){
			scanf("%d", &arr[i]);
			if(arr[i] % 2 == 1) odd[++odd[0]] = i;
			else even[++even[0]] = i;
		}
//		printf(":%d %d\n", odd[0], even[0]);
		if(odd[0] % 2 == 0 && even[0] % 2 == 0){
			if(odd[0] != 0){
				for(int i = 1; i + 1 <= odd[0] - 2; i += 2) printf("%d %d\n", odd[i], odd[i + 1]);
				for(int i = 1; i + 1 <= even[0]; i += 2) printf("%d %d\n", even[i], even[i + 1]);
			}else{
				for(int i = 1; i + 1 <= odd[0]; i += 2) printf("%d %d\n", odd[i], odd[i + 1]);
				for(int i = 1; i + 1 <= even[0] - 2; i += 2) printf("%d %d\n", even[i], even[i + 1]);
			}
		}else{
			for(int i = 1; i + 1 <= odd[0]; i += 2) printf("%d %d\n", odd[i], odd[i + 1]);
			for(int i = 1; i + 1 <= even[0]; i += 2) printf("%d %d\n", even[i], even[i + 1]);
		}
	}
	return 0;
}
