#include<bits/stdc++.h>
using namespace std;
const int MAXN = 200100;
const int INF = 0x3f3f3f3f;
 
int n, k, arr[MAXN];
 
bool judge1(int x){ //1, 3, 5, 7, ...
	int demand = ((k + 1) >> 1);
	for(int i = 1; i <= n - (k % 2 == 0); i++){
		if(arr[i] <= x) demand--, i++;
	}
	return demand <= 0;
}
bool judge2(int x){
	int demand = (k >> 1);
	for(int i = 2; i <= n - (k % 2 == 1); i++){
		if(arr[i] <= x) demand--, i++;
	}
	return demand <= 0;
}
 
int main(){
	scanf("%d %d", &n, &k);
	for(int i = 1; i <= n; i++) scanf("%d", &arr[i]);
	int lft = 1, rht = INF, mid, ans = INF + 1;
	while(lft <= rht){
		mid = (lft + rht) >> 1;
		if(judge1(mid) || judge2(mid)) ans = mid, rht = mid - 1;
		else lft = mid + 1;
	}
	printf("%d\n", ans);
	return 0;
}
