#include<bits/stdc++.h>
using namespace std;
const int MAXN = 1000100;
const int INF = 0x3f3f3f3f;
 
int n;
char str1[MAXN], str2[MAXN];
int cnt, maximum, minimum;
 
int main(){
	scanf("%d", &n);
	scanf("%s", str1 + 1);
	scanf("%s", str2 + 1);
	int cnt1 = 0, cnt2 = 0;
	for(int i = 1; i <= n; i++){
		if(str1[i] == '1') cnt1++;
		if(str2[i] == '1') cnt2++;
	}
//	printf(":%d %d\n", cnt1, cnt2);
	if(cnt1 != cnt2){
		printf("-1\n");
		return 0;
	}
	cnt = 0; maximum = 0; minimum = INF;
	for(int i = 1; i <= n; i++){
		cnt += str1[i] == '1' ? 0 : 1;
		cnt -= str2[i] == '0' ? 1 : 0;
//		printf(":%d %d %d\n", maximum, minimum, cnt);
		maximum = max(maximum, cnt);
		minimum = min(minimum, cnt);
	}
	printf("%d\n", abs(maximum - minimum));
	return 0;
}
