#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
typedef long long ll;

ll a, b, c;

int main(){int _task = 1; scanf("%d", &_task);
	while(_task--){
		scanf("%lld %lld %lld", &a, &b, &c);
		printf("%lld\n", a + b + c - 1);
	}
	return 0;
}

