#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
const int MAXN = 110;
typedef long long ll;

ll n, m;
ll mp[MAXN][MAXN];

bool cmp(const ll &x, const ll &y){return x < y;}

int main(){int _task = 1; scanf("%d", &_task);
	while(_task--){
		scanf("%lld %lld", &n, &m);
		for(int i = 1; i <= n; i++){
			for(int j = 1; j <= m; j++){
				scanf("%lld", &mp[i][j]);
			}
		}
		ll ans = 0;
		for(int i = 1; i * 2 <= n; i++){
			for(int j = 1; j * 2 <= m; j++){
				int x1 = i, y1 = j;
				int x2 = n - i + 1, y2 = m - j + 1;
				int x3 = n - i + 1, y3 = j;
				int x4 = i, y4 = m - j + 1;
				ll arr[5];
				arr[1] = mp[x1][y1];
				arr[2] = mp[x2][y2];
				arr[3] = mp[x3][y3];
				arr[4] = mp[x4][y4];
				sort(arr + 1, arr + 5, cmp);
				ans += abs(arr[1] - arr[2]) + abs(arr[3] - arr[2]) + abs(arr[4] - arr[2]);
			}
		}
		if(n % 2 == 1){
			for(int j = 1; j * 2 <= m; j++)
				ans += abs(mp[(n + 1) / 2][j] - mp[(n + 1) / 2][m - j + 1]);
		}
		if(m % 2 == 1){
			for(int i = 1; i * 2 <= n; i++){
				ans += abs(mp[i][(m + 1) / 2] - mp[n - i + 1][(m + 1) / 2]);
			}
		}
		printf("%lld\n", ans);
	}
	return 0;
}

