#include<bits/stdc++.h>
using namespace std;
const int MAXN = 100100;
const int MOD = 1e9 + 7;
typedef long long ll;

int len;
char str[MAXN];
ll pref, ans;

void decrease(ll &x, ll y){
	x = ((x - y % MOD) % MOD + MOD) % MOD;
}

int main(){
	scanf("%s", str + 1);
	len = strlen(str + 1);
	ll pwr = 1ll;
	pref = 0;
	ans = 0;
	for(int i = len; i >= 1; i--){
		ll now = str[i] - '0';
		decrease(ans, pwr * now);
		//����޸ĸ�λ��֮���ֵ������任λ�á�
		ll addi = now * pref % MOD;
//		printf(":%lld\n", addi);
		ans = (ans + addi) % MOD;
		//Ȼ���޸ĸ�λ��֮ǰ��ֵ
		ll tmps = i - 1;
		addi = ((tmps * (tmps + 1) / 2) % MOD + 1) % MOD;
		addi = (addi * pwr * now) % MOD;
//		printf(":%lld\n", addi);
		ans = (ans + addi) % MOD;
//		printf("\n");
		pref = (pref + (pwr * (len - i + 1)) % MOD) % MOD;
		pwr = pwr * 10 % MOD;
		}
	printf("%lld\n", ans);
	return 0;
}
