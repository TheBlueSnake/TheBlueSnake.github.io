#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
const int MAXN = 200100;
const int MAXM = 400100;
typedef long long ll;
typedef pair<int, int> pii;

struct edge{int u, v, l; edge(int au = 0, int av = 0, int al = 0){u = au; v = av; l = al;}};

int n, m;
int sx, sy, fx, fy;
int posx[MAXN], posy[MAXN];
int tot, frt[MAXN], nxt[MAXM]; edge ed[MAXM];
int dis[MAXN];
int xtot, ytot, xpos[MAXN], ypos[MAXN];

bool cmp(int x, int y){
	return x < y;
}

void add_edge(int u, int v, int l){
	printf(":add %d %d %d\n", u, v, l);
	ed[++tot] = edge(u, v, l);
	nxt[tot] = frt[u]; frt[u] = tot;
}

ll dijkstra(ll st, ll edp){
	int u, v, vis[MAXN];
	priority_queue<pii, vector<pii>, greater<pii> > que;
	memset(vis, 0, sizeof(vis));
	memset(dis, 0x3f, sizeof(dis));
	que.push(make_pair(0, st)); dis[st] = 0;
	while(!que.empty()){
		u = que.top().second; que.pop();
		if(!vis[u]){
			vis[u] = 1;
			for(int i = frt[u]; i; i = nxt[i]){
				v = ed[i].v;
				if(dis[v] > dis[u] + ed[i].l){
					dis[v] = dis[u] + ed[i].l;
					que.push(make_pair(dis[v], v));
				}
			}
		}
	}
	return dis[edp];
}

int main(){
	scanf("%d %d", &n, &m);
	scanf("%d %d %d %d", &sx, &sy, &fx, &fy);
	for(int i = 1; i <= m; i++){
		scanf("%d %d", &posx[i], &posy[i]);
		xpos[i] = posx[i];
		ypos[i] = posy[i];
	}
	xpos[m + 1] = sx; xpos[m + 2] = fx;
	ypos[m + 1] = sy; ypos[m + 2] = fy;
	sort(xpos + 1, xpos + m + 3, cmp);
	sort(ypos + 1, ypos + m + 3, cmp);
	xtot = unique(xpos + 1, xpos + m + 3) - xpos - 1;
	ytot = unique(ypos + 1, ypos + m + 3) - ypos - 1;
	for(int i = 1; i <= xtot - 1; i++){
		add_edge(i, i + 1, xpos[i + 1] - xpos[i]);
		add_edge(i + 1, i, xpos[i + 1] - xpos[i]);
	}
	for(int i = 1; i <= ytot - 1; i++){
		add_edge(xtot + i, xtot + i + 1, ypos[i + 1] - ypos[i]);
		add_edge(xtot + i + 1, xtot + i, ypos[i + 1] - ypos[i]);
	}
	for(int i = 1; i <= m; i++){
		int a = lower_bound(xpos + 1, xpos + xtot + 1, posx[i]) - xpos;
		int b = lower_bound(ypos + 1, ypos + ytot + 1, posy[i]) - ypos;
//		printf(":%d %d\n", a, b);
		add_edge(a, xtot + b, 0);
		add_edge(xtot + b, a, 0);
	}
	int sxx = lower_bound(xpos + 1, xpos + xtot + 1, sx) - xpos;
	int syy = lower_bound(ypos + 1, ypos + ytot + 1, sy) - ypos;
	add_edge(xtot + ytot + 1, sxx, 0);
	add_edge(xtot + ytot + 1, xtot + syy, 0);
	int fxx = lower_bound(xpos + 1, xpos + xtot + 1, fx) - xpos;
	int fyy = lower_bound(ypos + 1, ypos + ytot + 1, fy) - ypos;
	add_edge(fxx, xtot + ytot + 2, 0);
	add_edge(xtot + fyy, xtot + ytot + 2, 0);
//	printf(":%d %d\n", xtot, ytot);
	printf("%lld\n", dijkstra(xtot + ytot + 1, xtot + ytot + 2));
	return 0;
}

