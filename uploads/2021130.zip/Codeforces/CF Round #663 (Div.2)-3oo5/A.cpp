#include<bits/stdc++.h>
using namespace std;

int T, n;

int main(){
	scanf("%d", &T); while(T--){
		scanf("%d", &n);
		for(int i = 1; i <= n; i++) printf("%d ", i);
		printf("\n");
	}
	return 0;
}
