#include<bits/stdc++.h>
using namespace std;
const int MAXN = 1000100;
const int INF = 0x3f3f3f3f;

int n, m;
char str[MAXN], mp[5][MAXN];

int main(){
	scanf("%d %d", &n, &m);
	if(n >= 4 && m >= 4){
		printf("-1\n");
		return 0;
	}else{
		if(n == 1 || m == 1){
			printf("0\n");
			return 0;
		}
		if(n == 2 || n == 3){
			for(int i = 1; i <= n; i++){
				scanf("%s", str + 1);
				for(int j = 1; j <= m; j++){
					mp[i][j] = str[j] - '0';
				}
			}
		}else{
			for(int i = 1; i <= n; i++){
				scanf("%s", str + 1);
				for(int j = 1; j <= m; j++){
					mp[j][i] = str[j] - '0';
				}
			}
			swap(i, j);
		}
		if(n == 2){
			
		}
	}
	return 0;
}
