#include<bits/stdc++.h>
using namespace std;
const int MAXN = 110;

int T;
int n, m, ans;
char str[MAXN];

int main(){
	scanf("%d", &T); while(T--){
		scanf("%d %d", &n, &m);
		ans = 0;
		for(int i = 1; i <= n - 1; i++){
			scanf("%s", str + 1);
			if(str[m] == 'R') ans++;
		}
		scanf("%s", str + 1);
		for(int i = 1; i <= m; i++){
			if(str[i] == 'D') ans++;
		}
		printf("%d\n", ans);
	}
	return 0;
}
