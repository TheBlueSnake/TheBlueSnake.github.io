#include<bits/stdc++.h>
using namespace std;
const int MOD = 1e9 + 7;

int n, ans, ans2;

int main(){
	ans = 1; ans2 = 1;
	scanf("%d", &n);
	for(int i = 1; i <= n; i++) ans = (1ll * ans * i) % MOD;
	for(int i = 1; i <= n - 1; i++) ans2 = (1ll * ans2 * 2) % MOD;
	ans = ((ans - ans2) % MOD + MOD) % MOD;
	printf("%d\n", ans);
	return 0;
}
