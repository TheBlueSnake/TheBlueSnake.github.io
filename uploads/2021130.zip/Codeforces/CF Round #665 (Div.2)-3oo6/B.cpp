#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
//const int MAXN = ;
typedef long long ll;

int _x1, __y1, _z1;
int _x2, _y2, _z2;

void work(int &x, int &y){
	int tmps = min(x, y);
	x -= tmps;
	y -= tmps;
}

int main(){int _task = 1; scanf("%d", &_task);
	while(_task--){
		scanf("%d %d %d", &_x1, &__y1, &_z1);
		scanf("%d %d %d", &_x2, &_y2, &_z2);
		int ans = 0;
		ans += min(_z1, _y2) * 2;
		work(_z1, _y2);
		work(_z1, _z2);
		work(__y1, _y2);
		work(_x1, _z2);
		work(_x2, __y1);
		ans -= min(__y1, _z2) * 2;
		printf("%d\n", ans);
	}
	return 0;
}

