#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFll 0x3f3f3f3f3f3f3f3fll
const int MAXN = 100100;
const int MAXE = 200100;
//const int MAXM = 60100;
const int MOD = 1e9 + 7;
typedef long long ll;

ll n, m;
ll tot, frt[MAXN], nxt[MAXE], ed[MAXE];
ll arr[MAXN];
ll fa[MAXN], sz[MAXN], b[MAXN], p[MAXN];

void add_edge(ll u, ll v){
	ed[++tot] = v;
	nxt[tot] = frt[u]; frt[u] = tot;
}
void dfs(ll u, ll f){
	fa[u] = f;
	sz[u] = 1;
	for(int i = frt[u]; i; i = nxt[i]){
		int v = ed[i];
		if(v != f){
			dfs(v, u);
			sz[u] += sz[v];
		}
	}
}
bool cmp(ll x, ll y){return x < y;}
bool cmp1(ll x, ll y){return x > y;}

int main(){
	ll _task = 1; scanf("%lld", &_task); while(_task--){
		scanf("%lld", &n);
		tot = 0;
		for(ll i = 1; i <= n; i++) frt[i] = 0;
		for(ll u, v, i = 1; i <= n - 1; i++){
			scanf("%lld %lld", &u, &v);
			add_edge(u, v);
			add_edge(v, u);
		}
		dfs(1, 0);
		for(ll i = 1; i <= n - 1; i++) b[i] = 1ll * sz[i + 1] * (n - sz[i + 1]) % MOD;
		scanf("%lld", &m);
		for(ll i = 1; i <= m; i++){
			scanf("%lld", &arr[i]);
		}
		sort(arr + 1, arr + m + 1, cmp1);
		sort(b + 1, b + n, cmp1);
		if(m <= n - 1){
			for(int i = 1; i <= m; i++) p[i] = arr[i];
			for(int i = m + 1; i <= n - 1; i++) p[i] = 1;
		}else{
			p[n - 1] = 1;
			for(int i = 1; i <= n - 2; i++) p[i] = arr[m - i + 1];
			for(int i = n - 1; i <= m; i++) p[n - 1] = p[n - 1] * arr[m - i + 1] % MOD;
		}
		ll ans = 0;
		for(int i = 1; i <= n - 1; i++) (ans = ans + p[i] * b[i] % MOD) % MOD;
		printf("%lld\n", ans);
	}
	return 0;
}
