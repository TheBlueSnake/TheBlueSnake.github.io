#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
//const int MAXN = ;
typedef long long ll;

int n, k;

int main(){int _task = 1; scanf("%d", &_task);
	while(_task--){
		scanf("%d %d", &n, &k);
		if(k <= n && k % 2 == n % 2) printf("0\n");
		else if(k <= n) printf("1\n");
		else printf("%d\n", k - n);
	}
	return 0;
}

