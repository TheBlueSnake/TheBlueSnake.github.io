#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
const int MAXN = 100100;
typedef long long ll;

int n, arr[MAXN], minimum;
int srt[MAXN];

bool cmp(const int &x, const int &y){return x < y;}

int main(){int _task = 1; scanf("%d", &_task);
	while(_task--){
		scanf("%d", &n);
		minimum = INF;
		for(int i = 1; i <= n; i++){
			scanf("%d", &arr[i]);
			minimum = min(minimum, arr[i]);
			srt[i] = arr[i];
		}
		bool flag = false;
		sort(srt + 1, srt + n + 1, cmp);
//		printf(":");
		for(int i = 1; i <= n; i++){
//			printf("%d ", srt[i]);
			if(arr[i] != srt[i]){
				if(arr[i] % minimum != 0){
					printf("NO\n");
					flag = true;
				}
			}
			if(flag) break;
		}
		if(!flag) printf("YES\n");
	}
	return 0;
}

