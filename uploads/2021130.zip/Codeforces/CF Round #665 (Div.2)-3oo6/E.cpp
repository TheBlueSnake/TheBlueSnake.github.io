#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
const int MAXN = 100100;
typedef long long ll;

struct line{
	int val, l, r;
	line(int aval = 0, int al = 0, int ar = 0){
		val = aval;
		l = al;
		r = ar;
	}
};
int n, m;
line hor[MAXN], ver[MAXN];

bool cmp1(line x, line y){
	return x.l < y.l;
}
bool cmp2(line x, line y){
	return x.val < y.val;
}

int main(){
	scanf("%d %d", &n, &m);
	for(int i = 1; i <= n; i++){
		scanf("%d %d %d", &hor[i].val, &hor[i].l, &hor[i].r);
	}
	hor[++n] = line(0, 0, 1000000);
	hor[++n] = line(1000000, 0, 1000000);
	for(int i = 1; i <= m; i++){
		scanf("%d %d %d", &ver[i].val, &ver[i].l, &ver[i].r);
	}
	ver[++m] = line(0, 0, 1000000);
	ver[++m] = line(1000000, 0, 1000000);
	sort(hor + 1, hor + n + 1, cmp1);
	sort(ver + 1, ver + m + 1, cmp2);
	priority_queue<pair<int, int> > que;
	set<int> s;
	int pos = 1; int ans = 0;
	for(int i = 1; i <= m; i++){
//		printf(":sz:%d\n", que.size());
		while(!que.empty()){
			pair<int, int> tmps = que.top();
			printf(":%d %d\n", tmps.first, tmps.second);
			if(-tmps.first < ver[i].val){
				s.erase(s.begin());
			}else{
				break;
			}
		}
//		printf(":%d pass1, sz:%d\n", i, que.size());
		if(i != 1){
			set<int>::iterator itl, itr;
			if(ver[i].l == 0){
				itl = s.upper_bound(ver[i].l)--;
				itr = s.upper_bound(ver[i].r)--;
			}else{
				itl = s.lower_bound(ver[i].l)--;
				itr = s.lower_bound(ver[i].r)--;
			}
			ans += distance(itl, itr);
		}
//		printf(":%d pass2, ans:%d\n", i, ans);
		for(; pos <= n; pos++){
			if(hor[pos].l <= ver[i].val){
				s.insert(hor[pos].val);
				que.push(make_pair(-hor[pos].r, hor[pos].val));
			}else{
				break;
			}
		}
//		printf(":%d pass3\n", i);
	}
	printf("%d\n", ans);
	return 0;
}

