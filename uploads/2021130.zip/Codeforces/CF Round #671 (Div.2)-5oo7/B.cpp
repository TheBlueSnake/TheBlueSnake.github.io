#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
//const int MAXN = ;
typedef long long ll;

ll x;

int main(){int _task = 1; scanf("%d", &_task);
	while(_task--){
		scanf("%lld", &x);
		ll side = 1, ans = 0;
		while(x){
			if(x >= side * (side + 1) / 2){
				x -= side * (side + 1) / 2;
				ans++;
				side = side * 2 + 1;
			}else{
				break;
			}
		}
		printf("%d\n", ans);
	}
	return 0;
}

