#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
const int MAXN = 1100;
typedef long long ll;

int n, x, a[MAXN];

int main(){int _task = 1; scanf("%d", &_task);
	while(_task--){
		scanf("%d %d", &n, &x);
		int sum = 0, flag = 0, flag2 = 0;
		for(int i = 1; i <= n; i++){
			scanf("%d", &a[i]);
			sum += a[i];
			if(a[i] != x) flag = 1;
			if(a[i] == x) flag2 = 1;
		}
		if(!flag){
			printf("0\n");
			continue;
		}else if(sum == x * n){
			printf("1\n");
			continue;
		}else if(flag2 == 1){
			printf("1\n");
			continue;
		}else{
			printf("2\n");
			continue;
		}
	}
	return 0;
}

