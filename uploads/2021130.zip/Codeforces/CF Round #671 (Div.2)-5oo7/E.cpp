#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
//const int MAXN = ;
typedef long long ll;

int n, deci;
vector<pair<int, int> > vec;

void dfs(int dep, int val){
	if(dep == deci + 1){
		if(val != 1) printf("%d ", val);
		return;
	}
	int tmps = vec[dep].second, nxt = 1;
	for(int i = 0; i <= tmps; i++){
		dfs(dep + 1, val * nxt);
		nxt = nxt * vec[dep].first;
	}
}

int main(){int _task = 1; scanf("%d", &_task);
	while(_task--){
		scanf("%d", &n);
		vec.clear();
		deci = 0;
		for(int i = 2; i * i <= n; i++){
			int tmps = 0;
			if(n % i == 0){
				while(n % i == 0){
					tmps++;
					n /= i;
				}
				vec.push_back(make_pair(i, tmps));
				deci++;
			}
		}
		if(n != 1) vec.push_back(make_pair(n, 1));
		dfs(0, 1); printf("\n");
	}
	return 0;
}

