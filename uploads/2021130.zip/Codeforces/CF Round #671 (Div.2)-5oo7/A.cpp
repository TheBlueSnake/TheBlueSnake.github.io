#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
const int MAXN = 1100;
typedef long long ll;

int n;
char str[MAXN];

int main(){int _task = 1; scanf("%d", &_task);
	while(_task--){
		scanf("%d", &n);
		scanf("%s", str + 1);
		if(n % 2 == 1){
			bool flag = false;
			for(int i = 1; i <= n; i += 2){
				if((str[i] - '0') % 2 == 1){
					printf("1\n");
					flag = true;
					break;
				}
			}
			if(!flag) printf("2\n");
		}else{
			bool flag = false;
			for(int i = 2; i <= n; i += 2){
				if((str[i] - '0') % 2 == 0){
					printf("2\n");
					flag = true;
					break;
				}
			}
			if(!flag) printf("1\n");
		}
	}
	return 0;
}

