#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
const int MAXN = 100100;
typedef long long ll;

int n, arr[MAXN];
int res[MAXN];

bool cmp(const int &x, const int &y){return x < y;}

int main(){int _task = 1; //scanf("%d", &_task);
	while(_task--){
		scanf("%d", &n);
		for(int i = 1; i <= n; i++){
			scanf("%d", &arr[i]);
		}
		sort(arr + 1, arr + n + 1, cmp);
		int ans = (n - 1) >> 1;
		printf("%d\n", ans);
		memset(res, -1, sizeof(res));
		for(int i = 2, cnt = 1; cnt <= ans; i += 2, cnt++){
			res[i] = arr[cnt];
		}
		for(int i = 1; i <= n; i++){
			if(res[i] == -1) res[i] = arr[++ans];
		}
		for(int i = 1; i <= n; i++){
			printf("%d ", res[i]);
		}
		printf("\n");
	}
	return 0;
}

