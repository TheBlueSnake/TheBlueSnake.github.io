#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
const int MAXN = 100100;
typedef long long ll;

int n, arr[MAXN];
int ans[MAXN];

bool cmp(const int &x, const int &y){return x < y;}

int main(){int _task = 1; //scanf("%d", &_task);
	while(_task--){
		memset(arr, -1, sizeof(arr));
		scanf("%d", &n);
		for(int i = 1; i <= n; i++){
			scanf("%d", &arr[i]);
		}
		sort(arr + 1, arr + n + 1, cmp);
		int tmps = 1;
		memset(ans, -1, sizeof(ans));
		for(int i = 2; i <= n - 1; i += 2){
			ans[i] = arr[tmps];
			arr[tmps] = -1;
			tmps++;
		}
//		for(int i = 1; i <= n; i++) printf("%d ", ans[i]); printf("\n");
		for(int i = 1; i <= n; i += 2){
			while(tmps <= n && (ans[i - 1] >= arr[tmps] || ans[i + 1] >= arr[tmps])) tmps++;
			if(tmps > n) break;
			ans[i] = arr[tmps];
			arr[tmps] = -1;
			tmps++;
		}
//		for(int i = 1; i <= n; i++) printf("%d ", ans[i]); printf("\n");
		tmps = n;
		for(int i = 1; i <= n; i++){
			if(ans[i] != -1) continue;
			while(tmps >= 1 && arr[tmps] == -1) tmps--;
			ans[i] = arr[tmps];
			arr[tmps] = -1;
			tmps--;
		}
//		for(int i = 1; i <= n; i++) printf("%d ", ans[i]); printf("\n");
		int cnt = 0;
		for(int i = 1; i <= n; i++){
			if(ans[i] < ans[i - 1] && ans[i] < ans[i + 1]) cnt++;
		}
		printf("%d\n", cnt);
		for(int i = 1; i <= n; i++){
			printf("%d ", ans[i]);
		}
	}
	return 0;
}

