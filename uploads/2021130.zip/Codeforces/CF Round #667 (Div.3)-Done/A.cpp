#include<bits/stdc++.h>
using namespace std;
//const int MAXN = ;
typedef long long ll;
 
ll a, b;
 
int main(){
	int tskcnt = 1; scanf("%d", &tskcnt);
	while(tskcnt--){
		scanf("%lld %lld", &a, &b);
		printf("%lld\n", (abs(b - a) + 9) / 10);
	}
	return 0;
}
