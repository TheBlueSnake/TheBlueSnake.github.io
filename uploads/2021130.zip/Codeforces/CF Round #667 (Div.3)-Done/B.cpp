#include<bits/stdc++.h>
using namespace std;
//const int MAXN = ;
typedef long long ll;

ll a, b, x, y, n;

int main(){
	int tskcnt = 1; scanf("%d", &tskcnt);
	while(tskcnt--){
		ll tmps;
		scanf("%lld %lld %lld %lld %lld", &a, &b, &x, &y, &n);
		ll ans1, aa, bb, xx, yy, nn;
		aa = a; bb = b; xx = x; yy = y; nn = n;
		tmps = min(nn, aa - xx);
		nn -= tmps; aa -= tmps;
		tmps = min(nn, bb - yy);
		nn -= tmps; bb -= tmps;
		ans1 = aa * bb;
		aa = b; bb = a; xx = y; yy = x; nn = n;
		tmps = min(nn, aa - xx);
		nn -= tmps; aa -= tmps;
		tmps = min(nn, bb - yy);
		nn -= tmps; bb -= tmps;
		printf("%lld\n", min(aa * bb, ans1));
	}
	return 0;
}


