#include<bits/stdc++.h>
using namespace std;
const int MAXN = 210;

int n, ks;
char arr[MAXN], t[5];
int f[MAXN][MAXN][MAXN];

int solve(int i, int j, int k){
//	printf("query(%d, %d, %d)\n", i, j, k);
	if(i == n + 1) return 0;
	if(f[i][j][k] != -1) return f[i][j][k];
	if(arr[i] == t[1]){
		f[i][j][k] = max(f[i][j][k], solve(i + 1, j + 1, k)); //���޸�t[1] 
		if(k >= 1) f[i][j][k] = max(f[i][j][k], solve(i + 1, j, k - 1) + j); //��Ϊt[2] 
	}else if(arr[i] == t[2]){
		f[i][j][k] = max(f[i][j][k], solve(i + 1, j, k) + j); //���޸�t[2]
		if(k >= 1) f[i][j][k] = max(f[i][j][k], solve(i + 1, j + 1, k - 1)); //��Ϊt[1] 
	}else{
		f[i][j][k] = max(f[i][j][k], solve(i + 1, j, k)); //���޸�
		if(k >= 1) f[i][j][k] = max(f[i][j][k], solve(i + 1, j + 1, k - 1)); //��Ϊt[1]
		if(k >= 1) f[i][j][k] = max(f[i][j][k], solve(i + 1, j, k - 1) + j); //��Ϊt[2]
	}
//	printf("f[%d][%d][%d] = %d\n", i, j, k, f[i][j][k]);
	return f[i][j][k];
}

int main(){
	scanf("%d %d", &n, &ks);
	scanf("%s", arr + 1);
	scanf("%s", t + 1);
	if(t[1] == t[2]){
		int cnts = 0;
		for(int i = 1; i <= n; i++){
			if(arr[i] == t[1]) cnts++;
			else if(ks){
				ks--;
				cnts++;
			}
		}
		printf("%lld\n", 1ll * cnts * (cnts - 1) / 2);
	}else{
		memset(f, -1, sizeof(f));
		printf("%d\n", solve(1, 0, ks));
	}
	return 0;
}
