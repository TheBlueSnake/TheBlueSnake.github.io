#include<bits/stdc++.h>
using namespace std;
const int MAXN = 200100;

int n, k;
int x[MAXN], y[MAXN], maxi[MAXN], ans;

bool cmp(const int &x, const int &y){
	return x < y;
}

int main(){
	int tskcnt = 1; scanf("%d", &tskcnt);
	memset(maxi, 0, sizeof(maxi));
	while(tskcnt--){
		scanf("%d %d", &n, &k);
		for(int i = 1; i <= n; i++)
			scanf("%d", &x[i]);
		for(int i = 1; i <= n; i++)
			scanf("%d", &y[i]);
		sort(x + 1, x + n + 1, cmp);
		memset(maxi, 0, sizeof(maxi));
		for(int i = n; i >= 1; i--){
			int edval = x[i] + k;
			int edpos = upper_bound(x + 1, x + n + 1, edval) - x;
			maxi[i] = max(maxi[i + 1], edpos - i);
		}
		ans = 0;
		for(int i = 1; i <= n; i++){
			int tmps = upper_bound(x + 1, x + n + 1, x[i] + k) - x;
			ans = max(ans, tmps - i + maxi[tmps]);
		}
		printf("%d\n", ans);
	}
	return 0;
}


