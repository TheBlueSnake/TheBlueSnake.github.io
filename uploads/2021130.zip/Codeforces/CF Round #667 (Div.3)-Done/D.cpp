#include<bits/stdc++.h>
using namespace std;
//const int MAXN = ;
typedef long long ll;

ll n, s;

ll calc(ll tmps){
	ll ret = 0;
	while(tmps){
		ret += tmps % 10;
		tmps /= 10;
	}
	return ret;
}

int main(){
	int tskcnt = 1; scanf("%d", &tskcnt);
	while(tskcnt--){
		scanf("%lld %lld", &n, &s);
		if(calc(n) <= s){
			printf("0\n");
			continue;
		}
		ll pwr = 1ll, ans = 0ll, tmps = n;
		while(tmps){
			if(tmps % 10 != 0){
				ans += pwr * (10 - tmps % 10);
				tmps += 10 - tmps % 10;
				if(calc(tmps) <= s){
					printf("%lld\n", ans);
					break;
				}
			}
			tmps /= 10; pwr *= 10;
		}
	}
	return 0;
}


