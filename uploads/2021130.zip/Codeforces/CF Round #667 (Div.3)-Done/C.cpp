#include<bits/stdc++.h>
using namespace std;
//const int MAXN = ;
const int INF = 0x3f3f3f3f;

int n, x, y;

int main(){
	int tskcnt = 1; scanf("%d", &tskcnt);
	while(tskcnt--){
		scanf("%d %d %d", &n, &x, &y);
		int ad, apos;
		for(int d = 1; d <= 50; d++){
			if((y - x) % d == 0){
				int lcnt = x % d == 0 ? x / d - 1 : x / d;
				int lpos = x % d == 0 ? d : x % d;
				int midcnt = (y - x) / d + 1;
				if(midcnt > n) continue;
				if(n <= midcnt + lcnt){
					ad = d;
					apos = y - (n - 1) * d;
					break;
				}else{
					ad = d;
					apos = lpos;
					break;
				}
			}
		}
//		printf(":%d %d\n", alpos, ad);
		for(int i = 1; i <= n; i++)
			printf("%d ", apos + (i - 1) * ad);
		printf("\n");
	}
	return 0;
}


