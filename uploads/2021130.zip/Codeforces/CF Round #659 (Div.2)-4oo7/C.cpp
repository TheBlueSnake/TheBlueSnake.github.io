#include<bits/stdc++.h>
using namespace std;
const int MAXN = 100100;

int T;
int n;
char a[MAXN], b[MAXN];

int main(){
	scanf("%d", &T); while(T--){
		scanf("%d", &n);
		scanf("%s", a + 1);
		scanf("%s", b + 1);
		bool flg = false;
		for(int i = 1; i <= n; i++){
			if(a[i] > b[i]){
				flg = true;
				break;
			}
		}
		if(flg){
			printf("-1\n");
			continue;
		}
		int ans = 0;
		for(char i = 'a'; i <= 'z'; i++){
			queue<int> que;
			char dest = 'z';
			for(int j = 1; j <= n + 1; j++){
				if(a[j] == i && a[j] != b[j]){
					que.push(j);
					dest = min(dest, b[j]);
				}
			}
			if(!que.empty()){
				ans++;
				while(!que.empty()) a[que.front()] = dest, que.pop();
			}
		}
		printf("%d\n", ans);
	}
	return 0;
}
