#include<bits/stdc++.h>
using namespace std;
const int MAXN = 300100;

int T;
int n, k, l, arr[MAXN];

inline int f(int x){
	if(0 <= x && x <= k) return x;
	else return k - (x - k);
}

int main(){
	scanf("%d", &T); while(T--){
		scanf("%d %d %d", &n, &k, &l);
		for(int i = 1; i <= n; i++) scanf("%d", &arr[i]);
		int ans = 1;
		int earliest = -1;
		for(int i = 1; i <= n; i++){
			if(arr[i] <= l - k){
				earliest = -1;
				continue;
			}
			if(arr[i] > l){
				ans = 0;
				break;
			}
			int left_time = arr[i] - (l - k);
			int right_time = k + l - arr[i];
//			printf(":%d %d %d -> %d\n", i, left_time, right_time, earliest);
			if(earliest + 1 > right_time){
				ans = 0;
				break;
			}else{
				earliest = max(earliest + 1, left_time);
			}
		}
		if(!ans) printf("No\n");
		else printf("Yes\n");
	}
	return 0;
}
