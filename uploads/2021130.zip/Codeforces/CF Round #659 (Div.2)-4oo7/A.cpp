#include<bits/stdc++.h>
using namespace std;
const int MAXN = 110;

int T;
int n, arr[MAXN], length;
int str[MAXN];

int main(){
	scanf("%d", &T); while(T--){
		scanf("%d", &n);
		length = 1;
		for(int i = 1; i <= n; i++){
			scanf("%d", &arr[i]);
			length = max(length, arr[i]);
		}
		for(int i = 1; i <= length; i++){
			str[i] = 0;
			printf("a");
		}
		printf("\n");
		for(int i = 1; i <= n; i++){
			for(int j = arr[i] + 1; j <= length; j++){
				str[j] = (str[j] + 1) % 26;
			}
			for(int j = 1; j <= length; j++)
				printf("%c", 'a' + str[j]);
			printf("\n");
		}
	}
	return 0;
}
