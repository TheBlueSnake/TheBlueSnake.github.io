#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFll 0x3f3f3f3f3f3f3f3fll
#define mp(x, y) make_pair(x, y)
//const int MAXN = ;
typedef long long ll;
typedef pair<int, int> pii;

ll l, r;

int main(){int _task = 1; scanf("%d", &_task);
while(_task--){
	scanf("%lld %lld", &l, &r);
	if(r >= l * 2){
		printf("NO\n");
	}else{
		printf("YES\n");
	}
}
	return 0;
}

