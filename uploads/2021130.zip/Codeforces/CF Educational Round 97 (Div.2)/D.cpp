#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFll 0x3f3f3f3f3f3f3f3fll
#define mp(x, y) make_pair(x, y)
const int MAXN = 200100;
typedef long long ll;
typedef pair<int, int> pii;

int n, arr[MAXN];

int main(){int _task = 1; scanf("%d", &_task);
while(_task--){
	scanf("%d", &n);
	for(int i = 1; i <= n; i++){
		scanf("%d", &arr[i]);
	}
	vector<int> vec;
	assert(arr[1] == 1);
	int tmps = 0;
	for(int i = 2; i <= n; i++){
		if(arr[i - 1] < arr[i]){
			tmps++;
		}else{
			vec.push_back(tmps);
			tmps = 1;
		}
	}
	vec.push_back(tmps);
	int len = vec.size();
	int ans = 1;
	int max1 = 1, sz = 0, max2 = 0;
	for(int i = 0; i < len; i++){
		sz++;
		if(sz > max1){
			max1 = max2;
			max2 = vec[i];
			sz = 1;
			ans++;
		}else{
			max2 += vec[i];
		}
	}
	printf("%d\n", ans);
}
	return 0;
}

