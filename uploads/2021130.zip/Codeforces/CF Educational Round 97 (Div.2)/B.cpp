#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFll 0x3f3f3f3f3f3f3f3fll
#define mp(x, y) make_pair(x, y)
const int MAXN = 100100;
typedef long long ll;
typedef pair<int, int> pii;

int n;
char str[MAXN];

int main(){int _task = 1; scanf("%d", &_task);
while(_task--){
	scanf("%d", &n);
	scanf("%s", str + 1);
	int ans1 = 0, ans2 = 0, flg = 0;
	for(int i = 1; i <= n; i++){
		if(((str[i] - '0') ^ flg) ^ (i & 1)){
			ans1++; flg ^= 1;
		}
	}
	flg = 0;
	for(int i = 1; i <= n; i++){
		if(((str[i] - '0') ^ flg) ^ (~i & 1)){
			ans2++; flg ^= 1;
		}
	}
	printf("%d\n", min(ans1 + 1, ans2 + 1) >> 1);
}
	return 0;
}

