#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFll 0x3f3f3f3f3f3f3f3fll
#define mp(x, y) make_pair(x, y)
const int MAXN = 210;
const int MAXT = 410;
typedef long long ll;
typedef pair<int, int> pii;

int n;
int t[MAXN];
int f[MAXT][MAXN];

bool cmp(const int &x, const int &y){
	return x < y;
}

int main(){int _task = 1; scanf("%d", &_task);
while(_task--){
	scanf("%d", &n);
	for(int i = 1; i <= n; i++){
		scanf("%d", &t[i]);
	}
	sort(t + 1, t + n + 1, cmp);
	memset(f, 0x3f, sizeof(f));
	f[0][0] = 0;
	for(int i = 1; i <= n * 2; i++){
		f[i][0] = 0;
		for(int j = 1; j <= n; j++){
			f[i][j] = min(f[i - 1][j], f[i - 1][j - 1] + abs(t[j] - i));
//			printf(":f[%d][%d] = %d\n", i, j, f[i][j]);
		}
	}
	printf("%d\n", f[n * 2][n]);
}
	return 0;
}

