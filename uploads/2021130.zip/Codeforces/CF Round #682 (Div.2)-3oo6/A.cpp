#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFll 0x3f3f3f3f3f3f3f3fll
#define mp(x, y) make_pair(x, y)
//const int MAXN = ;
typedef long long ll;
typedef pair<int, int> pii;

int n;

int main(){int _task = 1; scanf("%d", &_task);
while(_task--){
	scanf("%d", &n);
	for(int i = 1; i <= n; i++){
		printf("%d ", 1);
	}
	printf("\n");
}
	return 0;
}

