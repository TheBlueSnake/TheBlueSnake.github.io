#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFll 0x3f3f3f3f3f3f3f3fll
#define mp(x, y) make_pair(x, y)
const int MAXN = 1100;
typedef long long ll;
typedef pair<int, int> pii;

int n, arr[MAXN];

int main(){int _task = 1; scanf("%d", &_task);
while(_task--){
	scanf("%d", &n);
	for(int i = 1; i <= n; i++){
		scanf("%d", &arr[i]);
	}
	bool flag = false;
	for(int i = 1; i <= n; i++){
		for(int j = i + 1; j <= n; j++){
			if(arr[i] == arr[j]){
				printf("YES\n");
				flag = true;
				break;
			}
		}
		if(flag) break;
	}
	if(!flag) printf("NO\n");
}
	return 0;
}

