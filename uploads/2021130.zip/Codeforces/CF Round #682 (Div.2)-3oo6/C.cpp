#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFll 0x3f3f3f3f3f3f3f3fll
#define mp(x, y) make_pair(x, y)
const int MAXN = 110;
typedef long long ll;
typedef pair<int, int> pii;

int n, m, mp[MAXN][MAXN];

int main(){int _task = 1; scanf("%d", &_task);
while(_task--){
	scanf("%d %d", &n, &m);
	for(int i = 1; i <= n; i++){
		for(int j = 1; j <= m; j++){
			scanf("%d", &mp[i][j]);
		}
	}
	for(int i = 1; i <= n; i++){
		for(int j = 1; j <= m; j++){
			if((i + j) % 2 != mp[i][j] % 2){
				mp[i][j]++;
			}
		}
	}
	for(int i = 1; i <= n; i++){
		for(int j = 1; j <= m; j++){
			printf("%d ", mp[i][j]);
		}
		printf("\n");
	}
}
	return 0;
}

