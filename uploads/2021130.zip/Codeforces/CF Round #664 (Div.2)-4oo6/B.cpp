#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
const int MAXN = 110;
typedef long long ll;

int n, m, sx, sy;
int mp[MAXN][MAXN];

inline void prt(){
	printf("%d %d\n", sx, sy);
	mp[sx][sy] = 1;
}

int main(){int _task = 1; //scanf("%d", &_task);
	while(_task--){
		memset(mp, 0, sizeof(mp));
		scanf("%d %d %d %d", &n, &m, &sx, &sy);
		prt();
		for(sx-- ; sx >= 1; sx--) prt(); sx++;
		for(sy-- ; sy >= 1; sy--) prt(); sy++;
		for(int i = 1; i <= n; i++){
			for(int j = 1; j <= m; j++){
				if(mp[i][j] == 0){
					sy = j;
					prt();
				}
			}
			sx++; if(sx != n + 1) prt();
		}
	}
	return 0;
}

