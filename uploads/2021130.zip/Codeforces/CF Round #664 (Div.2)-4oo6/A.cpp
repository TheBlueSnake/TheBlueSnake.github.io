#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
//const int MAXN = ;
typedef long long ll;

int r, g, b, w;

int main(){int _task = 1; scanf("%d", &_task);
	while(_task--){
		scanf("%d %d %d %d", &r, &g, &b, &w);
		int cnt = 0;
		if(r % 2 == 1) cnt++;
		if(g % 2 == 1) cnt++;
		if(b % 2 == 1) cnt++;
		if(w % 2 == 1) cnt++;
		if(cnt == 0 || cnt == 1 || cnt == 4) printf("Yes\n");
		else if(cnt == 3 && (r == 0 || g == 0 || b == 0)) printf("No\n");
		else if(cnt == 3) printf("Yes\n");
		else printf("No\n");
	}
	return 0;
}

