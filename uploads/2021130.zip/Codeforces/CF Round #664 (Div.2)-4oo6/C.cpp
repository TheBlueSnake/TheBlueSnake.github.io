#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
const int MAXN = 210;
typedef long long ll;

int n, m;
int a[MAXN], b[MAXN], mk[20];

bool chk(int i, int j){
	for(int d = 9; d >= 0; d--){
		if(mk[d] == -1) continue;
		else if((a[i] & (1 << d)) & (b[j] & (1 << d))) return false;
	}
	return true;
}
bool test(int dig){
	for(int i = 1; i <= n; i++){
		int flag = 0;
		for(int j = 1; j <= m; j++){
			if(chk(i, j)){
				if((a[i] & (1 << dig)) & (b[j] & (1 << dig)));
				else{
//					printf(":Yes go %d, %d %d\n", dig, i, j);
					flag = 1;
					break;
				}
			}else{
//				printf(":%d %d fail\n", i, j);
			}
		}
		if(!flag) return false;
//		printf(":dig, %d; %d go\n", dig, i);
	}
	return true;
}

int main(){int _task = 1; //scanf("%d", &_task);
	while(_task--){
		scanf("%d %d", &n, &m);
		for(int i = 1; i <= n; i++) scanf("%d", &a[i]);
		for(int i = 1; i <= m; i++) scanf("%d", &b[i]);
		memset(mk, -1, sizeof(mk));
		int ans = 0;
		for(int i = 9; i >= 0; i--){
			if(test(i)) mk[i] = 1;
			else ans |= (1 << i);
		}
		printf("%d\n", ans);
	}
	return 0;
}

