#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
const int MAXN = 100100;
typedef long long ll;

ll n, d, m;
ll mini[MAXN], maxi[MAXN], tot1, tot2;

bool cmp(const ll &x, const ll &y){return x > y;}

int main(){int _task = 1; //scanf("%d", &_task);
	while(_task--){
		scanf("%lld %lld %lld", &n, &d, &m);
		tot1 = tot2 = 0;
		for(ll tmps, i = 1; i <= n; i++){
			scanf("%lld", &tmps);
			if(tmps <= m) mini[++tot1] = tmps;
			else maxi[++tot2] = tmps;
		}
		if(tot2 == 0){
			ll ans = 0;
			for(ll i = 1; i <= n; i++) ans += mini[i];
			printf("%lld\n", ans);
			return 0;
		}
		sort(mini + 1, mini + tot1 + 1, cmp);
		sort(maxi + 1, maxi + tot2 + 1, cmp);
		for(ll i = 1; i <= tot1; i++) mini[i] += mini[i - 1];
		for(ll i = tot1 + 1; i <= n; i++) mini[i] = mini[tot1];
		for(ll i = 1; i <= tot2; i++) maxi[i] += maxi[i - 1];
//		printf(":%d:", tot1); for(int i = 1; i <= tot1; i++) printf("%d ", mini[i]); printf("\n");
		ll ans = 0;
		for(ll i = 1; i <= tot2; i++){
			if((i - 1) * (d + 1) + 1 <= n){
				ans = max(ans, maxi[i] + mini[n - ((i - 1) * (d + 1) + 1)]);
//				printf(":%d %d %d\n", i, sum, mini[tot1]);
			}
		}
		printf("%lld\n", ans);
	}
	return 0;
}
