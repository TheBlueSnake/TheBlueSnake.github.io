#include<bits/stdc++.h>
using namespace std;
const int MAXN = 20100;
const int MAXA = 20100;
typedef long long ll;

ll n, p;
ll arr[MAXN], cnt[MAXA << 1];
vector<ll> ans;

bool cmp(const ll &x, const ll &y){return x < y;}

int main(){
	scanf("%lld %lld", &n, &p);
	for(ll i = 1; i <= n; i++) scanf("%lld", &arr[i]);
	sort(arr + 1, arr + n + 1, cmp);
	for(ll i = 1; i <= n; i++) cnt[arr[i]]++;
	for(ll i = 1; i <= arr[n] + n; i++) cnt[i] = cnt[i] + cnt[i - 1];
	for(ll x = max(0ll, arr[n] - n + 1); x <= arr[n]; x++){
		bool flg = false;
		for(ll i = x; i < x + n - 1; i++){
			if((cnt[i] - i + x) % p == 0){
				flg = true;
				break;
			}
		}
		if(!flg) ans.push_back(x);
	}
	ll length = ans.size();
	printf("%lld\n", length);
	for(ll i = 0; i < length; i++) printf("%lld ", ans[i]);
	printf("\n");
	return 0;
}
