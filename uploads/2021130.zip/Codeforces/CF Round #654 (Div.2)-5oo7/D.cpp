#include<bits/stdc++.h>
using namespace std;
const int MAXN = 310;

int t;
int n, k;
int mp[MAXN][MAXN];

int main(){
	scanf("%d", &t); while(t--){
		scanf("%d %d", &n, &k);
		if(k % n == 0) printf("%d\n", 0);
		else printf("%d\n", 2);
		memset(mp, 0, sizeof(mp));
		for(int xpos = 0, ypos = 0, cnt = 0, initpos = 0, i = 1; i <= k; i++){
			cnt++;
			mp[xpos][ypos] = 1;
//			printf(":%d %d\n", xpos, ypos);
			if(cnt < n){
				xpos = (xpos + 1) % n;
				ypos = (ypos + 1) % n;
			}else{
				initpos = initpos + 1;
				xpos = initpos;
				ypos = 0;
				cnt = 0;
			}
		}
		for(int i = 0; i < n; i++){
			for(int j = 0; j < n; j++)
				printf("%d", mp[i][j]);
			printf("\n");
		}
	}
	return 0;
}
