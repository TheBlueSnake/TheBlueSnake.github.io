#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

ll t;
ll n, r;

int main(){
	scanf("%lld", &t); while(t--){
		scanf("%lld %lld", &n, &r);
		if(n > r) printf("%lld\n", r * (r + 1) / 2);
		else printf("%lld\n", (n - 1) * n / 2 + 1);
	}
	return 0;
}
