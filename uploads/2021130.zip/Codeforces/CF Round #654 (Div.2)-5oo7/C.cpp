#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

ll t;
ll a, b, n, m;

inline void positive(){
	printf("Yes\n");
}
inline void negative(){
	printf("No\n");
}

int main(){
	scanf("%lld", &t); while(t--){
		scanf("%lld %lld %lld %lld", &a, &b, &n, &m);
		if(m > min(a, b)) negative();
		else if(a + b >= n + m) positive();
		else negative();
	}
	return 0;
}
