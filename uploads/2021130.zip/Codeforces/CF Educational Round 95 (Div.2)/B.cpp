#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
const int MAXN = 110;
typedef long long ll;

int n;
int arr[MAXN], locked[MAXN];
int tot, tmps[MAXN];

bool cmp(const int &x, const int &y){return x > y;}

int main(){int _task = 1; scanf("%d", &_task);
	while(_task--){
		scanf("%d", &n);
		for(int i = 1; i <= n; i++){
			scanf("%d", &arr[i]);
		}
		for(int i = 1; i <= n; i++){
			scanf("%d", &locked[i]);
		}
		tot = 0;
		for(int i = 1; i <= n; i++){
			if(locked[i] == 0){
				tmps[++tot] = arr[i];
			}
		}
		sort(tmps + 1, tmps + tot + 1, cmp);
		tot = 0;
		for(int i = 1; i <= n; i++){
			if(locked[i] == 0){
				arr[i] = tmps[++tot];
			}
		}
		int pref = 0, ans = 0;
		for(int i = 1; i <= n; i++){
			pref += arr[i];
			if(ans >= 0){
				ans = i - 1;
				break;
			}
		}
		for(int i = 1; i <= n; i++)
			printf("%d ", arr[i]);
		printf("\n");
	}
	return 0;
}

