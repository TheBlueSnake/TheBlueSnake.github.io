#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFll 0x3f3f3f3f3f3f3f3fll
//const int MAXN = ;
typedef long long ll;

ll x, y, k;
ll required_sticks;

bool judge(ll mid){
	return mid * (x - 1ll) >= (required_sticks - 1ll);
}

int main(){int _task = 1; scanf("%d", &_task);
	while(_task--){
		scanf("%lld %lld %lld", &x, &y, &k);
//		ll ans = ceil((required_sticks - 1) / (x - 1));
		ll lft = 1, rht = INFll / (x - 1ll), mid, ans;
		required_sticks = k + k * y;
		while(lft <= rht){
			mid = (lft + rht) >> 1;
//			printf(":%lld %d\n", mid, judge(mid));
			if(judge(mid)) ans = mid, rht = mid - 1;
			else lft = mid + 1;
		}
		printf("%lld\n", ans + k);
	}
	return 0;
}

