#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
const int MAXN = 200100;
typedef long long ll;

int n;
int arr[MAXN], pref[MAXN], f[MAXN][2]; //0friend, 1me

int main(){int _task = 1; scanf("%d", &_task);
	while(_task--){
		scanf("%d", &n);
		pref[0] = 0;
		for(int i = 1; i <= n; i++){
			scanf("%d", &arr[i]);
			pref[i] = pref[i - 1] + arr[i];
		}
		f[0][0] = 0;
		f[0][1] = INF;
		for(int i = 1; i <= n; i++){
			f[i][0] = f[i][1] = INF;
			if(i >= 2){
				f[i][0] = f[i - 2][1];
				f[i][1] = f[i - 2][0] + pref[i] - pref[i - 2];
			}
			f[i][0] = min(f[i - 1][1], f[i][0]);
			f[i][1] = min(f[i - 1][0] + pref[i] - pref[i - 1], f[i][1]);
		}
		printf("%d\n", min(f[n][0], f[n][1]));
	}
	return 0;
}

