#include<bits/stdc++.h>
#include<set>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
const int MAXN = 100100;
typedef long long ll;
typedef set<int>::iterator _it;

int n, q;
set<int> arr;
multiset<int, greater<int> > st;

bool cmp(const int &x, const int &y){return x < y;}

int main(){int _task = 1; //scanf("%d", &_task);
	while(_task--){
		scanf("%d %d", &n, &q);
		for(int input, i = 1; i <= n; i++){
			scanf("%d", &input);
			arr.insert(input);
		}
		
		for(_it i = arr.begin(); i != arr.end(); ){
			int nval = *i;
			int nxtval = *(++i);
			st.insert(nxtval - nval);
		}
		printf("%d\n", *(--arr.end()) - *arr.begin() - *st.begin());
		for(int t, x, i = 1; i <= q; i++){
			scanf("%d %d", &t, &x);
			if(t == 1){
				if(arr.find(x) != arr.end()){
					_it lpos = arr.lower_bound(x);
					_it rpos = arr.upper_bound(x);
					if(lpos != arr.begin() && rpos != arr.end()){st.erase(st.find(*(rpos) - *(--lpos))); lpos++;}
					if(lpos != arr.begin()){st.insert(x - *(--lpos)); lpos++;}
					if(rpos != arr.end()) st.insert(*(rpos) - x);
					arr.insert(x);
				}
				printf("%d\n", *(--arr.end()) - *arr.begin() - *st.begin());
			}else{
				arr.erase(arr.find(x));
				_it lpos = arr.lower_bound(x);
				_it rpos = arr.upper_bound(x);
				if(lpos != arr.begin() && rpos != arr.end()){st.insert(*(rpos) - *(--lpos)); lpos++;}
				if(lpos != arr.begin()){st.erase(st.find(x - *(--lpos))); lpos++;}
				if(rpos != arr.end()) st.erase(st.find(*(rpos) - x));
				printf("%d\n", *(--arr.end()) - *arr.begin() - *st.begin());
			}
		}
	}
	return 0;
}

