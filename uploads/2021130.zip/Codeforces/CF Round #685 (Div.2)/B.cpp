#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFll 0x3f3f3f3f3f3f3f3fll
#define mp(x, y) make_pair(x, y)
const int MAXN = 110;
typedef long long ll;
typedef pair<int, int> pii;

int n, q;
char str[MAXN];

int main(){int _task = 1; scanf("%d", &_task);
while(_task--){
	scanf("%d %d", &n, &q);
	scanf("%s", str + 1);
	int fst1 = -1, fst0 = -1, lst1 = -1, lst0 = -1;
	for(int i = 1; i <= n; i++){
		if(str[i] == '1'){
			fst1 = i;
			break;
		}
	}
	for(int i = 1; i <= n; i++){
		if(str[i] == '0'){
			fst0 = i;
			break;
		}
	}
	for(int i = n; i >= 1; i--){
		if(str[i] == '1'){
			lst1 = i;
			break;
		}
	}
	for(int i = n; i >= 1; i--){
		if(str[i] == '0'){
			lst0 = i;
			break;
		}
	}
//	printf(":%d %d %d %d\n", fst0, fst1, lst0, lst1);
	for(int li, ri, i = 1; i <= q; i++){
		scanf("%d %d", &li, &ri);
		if(ri - li + 1 < 2){
			printf("NO\n");
			continue;
		}else if((li == fst1 || li == fst0) && (ri == lst1 || ri == lst0)){
			printf("NO\n");
			continue;
		}else{
			printf("YES\n");
			continue;
		}
	}
}
	return 0;
}

