#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFll 0x3f3f3f3f3f3f3f3fll
#define mp(x, y) make_pair(x, y)
//const int MAXN = ;
typedef long long ll;
typedef pair<int, int> pii;

int di, k;

int main(){int _task = 1; scanf("%d", &_task);
while(_task--){
	scanf("%d %d", &di, &k);
	double dis = floor(1.0 * di / sqrt(2) / k);
	if(1.0 * dis * dis + 1.0 * (dis + 1) * (dis + 1) <= 1.0 * di * di / k / k){
		printf("Ashish\n");
	}else{
		printf("Utkarsh\n");
	}
}
	return 0;
}

