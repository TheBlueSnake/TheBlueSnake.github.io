#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFll 0x3f3f3f3f3f3f3f3fll
#define mp(x, y) make_pair(x, y)
const int MAXN = 1000100;
typedef long long ll;
typedef pair<int, int> pii;

int n, k;
char str[MAXN];
int l1[30], l2[30];

int main(){int _task = 1; scanf("%d", &_task);
while(_task--){
	scanf("%d %d", &n, &k);
	memset(l1, 0, sizeof(l1));
	memset(l2, 0, sizeof(l2));
	scanf("%s", str + 1);
	for(int i = 1; i <= n; i++){
		l1[str[i] - 'a' + 1]++;
	}
	scanf("%s", str + 1);
	for(int i = 1; i <= n; i++){
		l2[str[i] - 'a' + 1]++;
	}
	bool flag = false;
	for(int i = 1; i <= 26; i++){
//		printf(":%c: %d %d\n", 'a' + i - 1, l1[i], l2[i]);
		if(l1[i] - l2[i] >= 0 && (l1[i] - l2[i]) % k == 0){
			l1[i + 1] += l1[i] - l2[i];
		}else{
			printf("No\n");
			flag = true;
			break;
		}
	}
	if(!flag){
		printf("Yes\n");
		continue;
	}
}
	return 0;
}

