#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFll 0x3f3f3f3f3f3f3f3fll
#define mp(x, y) make_pair(x, y)
//const int MAXN = ;
typedef long long ll;
typedef pair<int, int> pii;

int n;

int main(){int _task = 1; scanf("%d", &_task);
while(_task--){
	scanf("%d", &n);
	if(n == 1){
		printf("0\n");
		continue;
	}else if(n == 2){
		printf("1\n");
		continue;
	}else if(n == 3){
		printf("2\n");
		continue;
	}else if(n % 2 == 0){
		printf("2\n");
		continue;
	}else if(n % 2 == 1){
		printf("3\n");
		continue;
	}
}
	return 0;
}

