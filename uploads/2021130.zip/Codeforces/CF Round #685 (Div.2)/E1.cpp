#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFll 0x3f3f3f3f3f3f3f3fll
#define mp(x, y) make_pair(x, y)
const int MAXN = 100100;
typedef long long ll;
typedef pair<int, int> pii;

int n;
int arr[MAXN];

int xxor(int l, int r){
	int ret;
	printf("XOR %d %d\n", l, r);
	fflush(stdout);
	scanf("%d", &ret);
	return ret;
}

int aand(int l, int r){
	int ret;
	printf("AND %d %d\n", l, r);
	fflush(stdout);
	scanf("%d", &ret);
	return ret;
}

int oor(int l, int r){
	int ret;
	printf("OR %d %d\n", l, r);
	fflush(stdout);
	scanf("%d", &ret);
	return ret;
}

int main(){
	scanf("%d", &n);
	int xxor12 = xxor(1, 2), aand12 = aand(1, 2);
	int xxor23 = xxor(2, 3), aand23 = aand(2, 3);
	int sum12 = xxor12 + (aand12 << 1);
	int sum23 = xxor23 + (aand23 << 1);
	int xxor13 = xxor12 ^ xxor23;
	int aand13 = aand(1, 3);
	int sum13 = xxor13 + (aand13 << 1);
	int sum123 = (sum12 + sum23 + sum13) / 2;
	arr[1] = sum123 - sum23;
	arr[2] = sum123 - sum13;
	arr[3] = sum123 - sum12;
	for(int i = 4; i <= n; i++){
		arr[i] = arr[i - 1] ^ xxor(i - 1, i);
	}
	printf("! ");
	for(int i = 1; i <= n; i++){
		printf("%d ", arr[i]);
	}
	fflush(stdout);
	return 0;
}

