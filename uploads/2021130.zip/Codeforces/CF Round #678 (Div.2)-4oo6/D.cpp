#include<bits/stdc++.h>
using namespace std;
const int MAXN = 200100;
const int MAXM = 400100;
typedef long long ll;

int n;
int tot, frt[MAXN], nxt[MAXM], ed[MAXM];
ll sz[MAXN], son[MAXN], f[MAXN];

void add_edge(int u, int v){
	ed[++tot] = v;
	nxt[tot] = frt[u]; frt[u] = tot;
}

void dfs(int u, int fa){
	int v;
	int flag = 0;
	for(int i = frt[u]; i; i = nxt[i]){
		v = ed[i];
		if(v != fa){
			flag = 1;
			dfs(v, u);
			sz[u] += sz[v];
			son[u] += son[v];
			f[u] = max(f[u], f[v]);
		}
	}
	if(!flag){
		son[u] = 1;
		f[u] = sz[u];
	}else{
		if(son[u] * f[u] >= sz[u]){
			return;
		}else{
			f[u] = sz[u] / son[u] + (sz[u] % son[u] == 0 ? 0 : 1);
		}
	}
}

int main(){
	scanf("%d", &n);
	for(int pi, i = 2; i <= n; i++){
		scanf("%d", &pi);
		add_edge(pi, i);
	}
	for(int i = 1; i <= n; i++){
		scanf("%lld", &sz[i]);
	}
	dfs(1, 0);
	printf("%lld\n", f[1]);
	return 0;
}
