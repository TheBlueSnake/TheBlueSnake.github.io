#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFll 0x3f3f3f3f3f3f3f3fll
#define mp(x, y) make_pair(x, y)
const int MAXN = 110;
typedef long long ll;
typedef pair<int, int> pii;

int n;
int mp[MAXN][MAXN];

bool judge(int x){
	int tmps = sqrt(x);
	for(int i = 2; i <= tmps; i++){
		if(x % i == 0) return false;
	}
	return true;
}

int main(){int _task = 1; scanf("%d", &_task);
while(_task--){
	scanf("%d", &n);
	for(int i = 1; i <= n - 1; i++){
		for(int j = 1; j <= n - 1; j++){
			mp[i][j] = 1;
		}
	}
	int tmps;
	for(int i = 0; ; i++){
		if(!judge(i) && judge(n - 1 + i)){
			tmps = i;
			break;
		}
	}
	for(int i = 1; i <= n - 1; i++) mp[n][i] = tmps;
	for(int i = 1; i <= n - 1; i++) mp[i][n] = tmps;
	for(int i = 1; ; i++){
		if(!judge(i) && judge(tmps * (n - 1) + i)){
			mp[n][n] = i;
			break;
		}
	}
	for(int i = 1; i <= n; i++){
		for(int j = 1; j <= n; j++){
			printf("%d ", mp[i][j]);
		}
		printf("\n");
	}
}
	return 0;
}

