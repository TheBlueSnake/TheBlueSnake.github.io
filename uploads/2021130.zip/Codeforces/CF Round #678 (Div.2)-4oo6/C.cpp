#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFll 0x3f3f3f3f3f3f3f3fll
#define mp(x, y) make_pair(x, y)
//const int MAXN = ;
const int MOD = 1000000007;
typedef long long ll;
typedef pair<int, int> pii;

int n, x, pos;
int ans;

int main(){int _task = 1; //scanf("%d", &_task);
while(_task--){
	ans = 1;
	scanf("%d %d %d", &n, &x, &pos);
	int lft = 0, rht = n, mid, lessr = 0, greatr = 0;
	while(lft < rht){
		mid = (lft + rht) >> 1;
		if(mid == pos){
			lft = mid + 1;
		}else if(mid <= pos){
			lessr++;
			lft = mid + 1;
		}else{
			greatr++;
			rht = mid;
		}
	}
//	printf(":%d %d\n", greatr, lessr);
	//exact = 1;
	int val1 = n - x;
	for(int i = 1; i <= greatr; i++){
		ans = 1ll * ans * val1 % MOD;
		val1--;
	}
	int val2 = x - 1;
	for(int i = 1; i <= lessr; i++){
		ans = 1ll * ans * val2 % MOD;
		val2--;
	}
	int val3 = n - lessr - greatr - 1;
	for(int i = val3; i >= 1; i--){
		ans = 1ll * ans * i % MOD;
	}
	printf("%d\n", ans);
}
	return 0;
}

