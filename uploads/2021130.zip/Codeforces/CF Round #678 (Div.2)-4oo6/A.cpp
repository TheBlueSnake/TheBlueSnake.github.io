#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFll 0x3f3f3f3f3f3f3f3fll
#define mp(x, y) make_pair(x, y)
const int MAXN = 110;
typedef long long ll;
typedef pair<int, int> pii;

int n, m, arr[MAXN];

int main(){
int _task = 1; scanf("%d", &_task);
while(_task--){
	scanf("%d %d", &n, &m);
	int sum = 0;
	for(int i = 1; i <= n; i++){
		scanf("%d", &arr[i]);
		sum += arr[i];
	}
	if(sum == m) printf("YES\n");
	else printf("NO\n");
}
	return 0;
}

