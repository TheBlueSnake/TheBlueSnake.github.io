#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

int t;
ll n;

int main(){
	scanf("%d", &t); while(t--){
		scanf("%lld", &n);
		if((90 * n) % 360 == 0) printf("YES\n");
		else printf("NO\n");
	}
	return 0;
}
