#include<bits/stdc++.h>
using namespace std;
const int MAXN = 2000100;
const int MOD = 1e9 + 7;
typedef long long ll;

ll t;
ll n, f[MAXN], head[MAXN];

int main(){
	memset(f, 0, sizeof(f));
	memset(head, 0, sizeof(head));
	for(ll i = 3; i <= 2000000; i++){
		f[i] = (1ll * f[i - 1] + 1ll * f[i - 2] * 2) % MOD;
		if(head[i - 2] == 0 && head[i - 1] == 0){
			f[i] = (f[i] + 4) % MOD;
			head[i] = 1;
		}
	}
	scanf("%lld", &t);
	for(ll inpt, i = 1; i <= t; i++){
		scanf("%lld", &inpt);
		printf("%lld\n", f[inpt]);
	}
	return 0;
}
