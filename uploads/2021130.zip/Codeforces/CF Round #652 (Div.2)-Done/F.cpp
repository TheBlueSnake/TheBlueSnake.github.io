#include<bits/stdc++.h>
using namespace std;
const int MAXN = 100100;
typedef long long ll;

ll n;
ll f[MAXN][2][2];

int main(){
	scanf("%lld", &n);
	memset(f, 0, sizeof(f));
	f[0][0][0] = 1;
	for(ll i = 1; i <= n; i++){
		ll e, s, tmps;
		scanf("%lld %lld", &e, &s); tmps = s;
		bool firstwin, secondwin;
		while(true){
			if(tmps & 1ll){firstwin = (tmps - e) & 1ll; secondwin = firstwin ^ 1; break;}
			ll l = tmps / 2ll, r = tmps / 4ll;
			if(e > l){
				firstwin = (tmps - e) & 1ll;
				secondwin = firstwin ^ 1;
				break;
			}else if(e > r){
				firstwin = true; secondwin = false;
				break;
			}else tmps = r;
		}
		bool firstlose, secondlose;
		if(e > s / 2ll){firstlose = 1; secondlose = 0;}
		else{
			tmps = s / 2ll;
			while(true){
				if(tmps & 1ll){firstlose = (tmps - e) & 1ll; secondlose = firstlose ^ 1; break;}
				ll l = tmps / 2ll, r = tmps / 4ll;
				if(e > l){
					firstlose = (tmps - e) & 1ll;
					secondlose = firstlose ^ 1;
					break;
				}else if(e > r){
					firstlose = true; secondlose = false;
					break;
				}else tmps = r;
			}
		}
		f[i][0][0] = (f[i - 1][0][0] | f[i - 1][1][0]) & firstlose;
		f[i][1][0] = (f[i - 1][0][1] | f[i - 1][1][1]) & secondlose;
		f[i][0][1] = (f[i - 1][0][0] | f[i - 1][1][0]) & firstwin;
		f[i][1][1] = (f[i - 1][0][1] | f[i - 1][1][1]) & secondwin;
	}
	printf("%lld %lld\n", f[n][0][1] | f[n][1][1], f[n][0][0] | f[n][1][0]);
	return 0;
}
