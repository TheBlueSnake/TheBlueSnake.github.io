#include<bits/stdc++.h>
using namespace std;
const int MAXN = 100100;

int t;
int n; char str[MAXN];

int main(){
	scanf("%d", &t); while(t--){
		scanf("%d", &n);
		scanf("%s", str + 1);
		int xpos = n, ypos = 1;
		for(int i = 1; i <= n; i++){
			if(str[i] == '1'){
				xpos = i - 1;
				break;
			}
		}
		for(int i = n; i >= 1; i--){
			if(str[i] == '0'){
				ypos = i + 1;
				break;
			}
		}
//		printf(":%d %d\n", xpos, ypos);
		for(int i = 1; i <= xpos; i++) printf("0");
		if(ypos != xpos + 1) printf("0");
		for(int i = 1; i <= n - ypos + 1; i++) printf("1");
		printf("\n");
	}
	return 0;
}
