#include<bits/stdc++.h>
using namespace std;
const int MAXN = 100100;
const int MAXM = 200100;

int n, m;
pair<int, int> fri[MAXM];
int w[MAXN];
vector<int> loved[MAXN];
queue<int> que;
int vis[MAXN], exist[MAXM];
vector<int> ans;

inline void remove(int pos){
	if(++w[pos] >= 0 && !vis[pos]){
		que.push(pos);
		vis[pos] = true;
	}
}

int main(){
	scanf("%d %d", &n, &m);
	for(int i = 1; i <= n; i++) scanf("%d", &w[i]);
	for(int i = 1; i <= m; i++){
		scanf("%d %d", &fri[i].first, &fri[i].second);
		w[fri[i].first]--;
		w[fri[i].second]--;
		loved[fri[i].first].push_back(i);
		loved[fri[i].second].push_back(i);
	}
	memset(vis, 0, sizeof(vis));
	memset(exist, 0, sizeof(exist));
	for(int i = 1; i <= n; i++) if(w[i] >= 0) que.push(i), vis[i] = true;
	while(!que.empty()){
		int tp = que.front(); que.pop();
//		printf(":%d\n", tp);
		int length = loved[tp].size();
		for(int i = 0; i < length; i++){
			remove(fri[loved[tp][i]].first);
			remove(fri[loved[tp][i]].second);
			if(!exist[loved[tp][i]]){
				ans.push_back(loved[tp][i]);
//				printf(":push%d\n", loved[tp][i]);
				exist[loved[tp][i]] = true;
			}
		}
	}
	int length = ans.size();
	if(length < m) printf("DEAD\n");
	else{
		printf("ALIVE\n");
		for(int i = length - 1; i >= 0; i--)
			printf("%d ", ans[i]);
		printf("\n");
	}
	return 0;
}
