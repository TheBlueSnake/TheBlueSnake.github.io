#include<bits/stdc++.h>
using namespace std;
const int MAXN = 200100;
const int MAXM = 200100;
typedef long long ll;

int t;
int n, k;
ll arr[MAXN], cnt[MAXM], ans = 0;

bool cmp(const ll &x, const ll &y){return x < y;}

int main(){
	scanf("%d", &t); while(t--){
		scanf("%d %d", &n, &k);
		for(int i = 1; i <= n; i++) scanf("%lld", &arr[i]);
		for(int i = 1; i <= k; i++){
			scanf("%lld", &cnt[i]);
			cnt[i]--;
		}
		sort(arr + 1, arr + n + 1, cmp);
		sort(cnt + 1, cnt + k + 1, cmp);
		ans = 0;
		for(int i = 1; i <= k; i++){
			ans += arr[n - i + 1];
			if(cnt[i] == 0) ans += arr[n - i + 1];
		}
		for(int sum = 1, i = k; i >= 1; i--){
//			printf(":%d %d %d\n", cnt[i], sum, ans);
			if(cnt[i] == 0) continue;
			ans += arr[sum];
			sum += cnt[i];
		}
		printf("%lld\n", ans);
	}
	return 0;
}
