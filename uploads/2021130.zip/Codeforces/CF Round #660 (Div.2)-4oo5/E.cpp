#include<bits/stdc++.h>
using namespace std;
const int MAXN = 2100;
const int MAXQ = 4000100;
const double INF = DBL_MAX;

struct node{
	double xl, xr, y;
	node(double axl = 0, double axr = 0, double ay = 0){
		xl = axl; xr = axr; y = ay;
	}
};
struct _queue{
	int hd, tl;
	pair<double, double> val[MAXN];
	_queue(){hd = 1; tl = 0;}
	void push(pair<double, double> x){val[++tl] = x;}
	void pop(){hd++;}
	pair<double, double> front(){return val[hd];}
	pair<double, double> second(){return val[hd + 1];}
	bool empty(){return tl < hd;}
	int sz(){return tl - hd + 1;}
};

int n;
node arr[MAXN];
_queue lq, rq;
int tot; pair<double, double> diff[MAXQ];
double ans;

bool cmp1(const node &x, const node &y){return x.y < y.y || x.y == y.y && x.xl < y.xl;}
bool cmp2(const node &x, const node &y){return x.y < y.y || x.y == y.y && x.xr > y.xr;}
bool cmp3(const pair<double, double> &x, const pair<double, double> &y){return x.first < y.first || x.first == y.first && x.second < y.second;}

int main(){
	scanf("%d", &n);
	for(int i = 1; i <= n; i++){
		scanf("%lf %lf %lf", &arr[i].xl, &arr[i].xr, &arr[i].y);
	}
	sort(arr + 1, arr + n + 1, cmp1);
	for(int prevy = 0, i = 1; i <= n; i++){
		if(arr[i].y != prevy){
			prevy = arr[i].y;
			lq.push(make_pair(arr[i].xl, arr[i].y));
		}
	}
	sort(arr + 1, arr + n + 1, cmp2);
	for(int prevy = 0, i = 1; i <= n; i++){
		if(arr[i].y != prevy){
			prevy = arr[i].y;
			rq.push(make_pair(arr[i].xr, arr[i].y));
		}
	}
//	for(int i = 1; i <= lq.sz(); i++) printf("(%lf, %lf) ", lq.val[i].first, lq.val[i].second); printf("\n");
//	for(int i = 1; i <= rq.sz(); i++) printf("(%lf, %lf) ", rq.val[i].first, rq.val[i].second); printf("\n");
	tot = 0;
	for(int i = 1; i <= n; i++){
		for(int j = 1; j <= n; j++){
			diff[++tot].first = (arr[i].xl - arr[i].xr) / (arr[j].y - arr[i].y);
			diff[tot].second = (arr[j].xr - arr[i].xl) / (arr[j].y - arr[i].y);
		}
	}
	sort(diff + 1, diff + tot + 1, cmp3);
	ans = INF;
	double prev = -INF;
	for(int i = 1; i <= tot; i++){
		if(prev <= diff[i].first){
			update(prev);
			update(diff[i].first);
			if(prev < 0 && diff[i].first > 0) update(0);
		}
		prev = diff[i].second;
	}
	return 0;
}
//#include<bits/stdc++.h>
//using namespace std;
//const int MAXN = 2100;
//const double INF = DBL_MAX;
//
//struct node{double xl, xr, y; node(double axl = 0, double axr = 0, double ay = 0){xl = axl; xr = axr; y = ay;}};
//struct dif{double x, y; dif(double ax = 0, double ay = 0){x = ax; y = ay;}};
//
//int n;
//node ed[MAXN];
//dif seq[MAXN * MAXN];
//double negans, ans;
//
//bool cmp_node(const node &x, const node &y){return x.y < y.y;}
//bool cmp_dif(const dif &x, const dif &y){return x.x < y.x || x.x == y.x && x.y < y.y;}
//void update(double &x, double y){
//	if(x < 0 && y > 0) negans = x, ans = y;
//	if(abs(y) < abs(x)) x = y;
//}
//
//int main(){
//	scanf("%d", &n);
//	for(int i = 1; i <= n; i++)
//		scanf("%lf %lf %lf", &ed[i].xl, &ed[i].xr, &ed[i].y);
//	sort(ed + 1, ed + n + 1, cmp_node);
////	for(int i = 1; i <= n; i++)
////		printf(":%d:%.7lf %.7lf %.7lf\n", i, ed[i].xl, ed[i].xr, ed[i].y);
//	int tot = 0;
//	for(int i = 1; i <= n; i++)
//		for(int j = i + 1; j <= n; j++){
//			if(ed[i].y == ed[j].y) continue;
//			seq[++tot].y = (ed[j].xr - ed[i].xl) / (ed[j].y - ed[i].y);
//			seq[tot].x = (ed[j].xl - ed[i].xr) / (ed[j].y - ed[i].y);
////			printf(":%d %d:%.7lf %.7lf\n", i, j, seq[tot].x, seq[tot].y);
//		}
//	double pre_most_rht = -INF;
//	ans = INF; negans = 2333;
//	sort(seq + 1, seq + tot + 1, cmp_dif);
//	for(int i = 1; i <= tot; i++){
////		printf(":%lf %lf\n", seq[i].x, seq[i].y);
//		if(seq[i].x >= pre_most_rht){
//			if(pre_most_rht < 0 && seq[i].x > 0){
//				double most_lft, most_rht;
//				most_lft = INF; most_rht = -INF;
//				for(int i = 1; i <= n; i++){
//					most_lft = min(most_lft, ed[i].xl);
//					most_rht = max(most_rht, ed[i].xr);
//				}
//				printf("%.7lf\n", most_rht - most_lft);
//				return 0;
//			}
//			update(ans, pre_most_rht);
//			update(ans, seq[i].x);
//		}
//		pre_most_rht = max(pre_most_rht, seq[i].y);
////		printf(":%lf\n", ans);
//	}
//	update(ans, pre_most_rht);
//	if(tot == 0){
//		ans = 0.0;
//	}
////	printf(":%.7lf\n", ans);
////	ans = 17.0;
//	double most_lft, most_rht;
//	most_lft = INF; most_rht = -INF;
//	for(int i = 1; i <= n; i++){
//		most_lft = min(most_lft, ed[i].xl - ed[i].y * ans);
//		most_rht = max(most_rht, ed[i].xr - ed[i].y * ans);
//	}
//	double tmps = most_rht - most_lft;
//	if(negans != 2333){
//		most_lft = INF; most_rht = -INF;
//		for(int i = 1; i <= n; i++){
//			most_lft = min(most_lft, ed[i].xl - ed[i].y * negans);
//			most_rht = max(most_rht, ed[i].xr - ed[i].y * negans);
//		}
//	}
//	printf("%.7lf\n", min(most_rht - most_lft, tmps));
//	return 0;
//}
