#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MAXN = 100100;
const int MAXM = 200100;

struct edge{ll u, v; edge(ll au = 0, ll av = 0){u = au; v = av;}};

ll T;
ll n, m, p[MAXN], h[MAXN];
ll tot, frt[MAXN], nxt[MAXM]; edge ed[MAXM];
ll total[MAXN], happy[MAXN], sad[MAXN];

inline void add_edge(ll u, ll v){
	ed[++tot] = edge(u, v);
	nxt[tot] = frt[u]; frt[u] = tot;
}
void dfs1(ll u, ll fa){
	total[u] = p[u];
	for(int v, i = frt[u]; i; i = nxt[i]){
		v = ed[i].v;
		if(v != fa){
			dfs1(v, u);
			total[u] += total[v];
		}
	}
}
bool dfs2(ll u, ll fa){
	ll tmps = 0;
	for(ll v, i = frt[u]; i; i = nxt[i]){
		v = ed[i].v;
		if(v != fa){
			if(dfs2(v, u)) tmps += happy[v];
			else return false;
		}
	}
	return tmps <= happy[u];
}

int main(){
	scanf("%lld", &T); while(T--){
		scanf("%lld %lld", &n, &m);
		//-init
		tot = 0;
		for(ll i = 1; i <= n; i++) frt[i] = 0;
		//
		bool tmpsflag = false;
		for(ll i = 1; i <= n; i++) scanf("%lld", &p[i]);
		for(ll i = 1; i <= n; i++)	scanf("%lld", &h[i]);
		for(ll u, v, i = 1; i <= n - 1; i++){
			scanf("%lld %lld", &u, &v);
			add_edge(u, v);
			add_edge(v, u);
		}
		dfs1(1, 0);
		for(ll i = 1; i <= n; i++){
			if(total[i] % 2 != abs(h[i]) % 2) tmpsflag = true;
			if(abs(h[i]) > total[i]) tmpsflag = true;
			happy[i] = (total[i] + h[i]) / 2;
			sad[i] = (total[i] - h[i]) / 2;
//			printf(":%d:%d %d %d\n", i, total[i], happy[i], sad[i]);
		}
		if(tmpsflag) printf("NO\n");
		else printf("%s\n", dfs2(1, 0) ? "YES" : "NO");
	}
	return 0;
}
