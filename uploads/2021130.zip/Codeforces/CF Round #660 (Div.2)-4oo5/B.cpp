#include<bits/stdc++.h>
using namespace std;

int T;
int n;

int main(){
	scanf("%d", &T); while(T--){
		scanf("%d", &n);
		int tmps = n << 2;
		while(tmps){
			if(tmps - n >= 4) printf("9");
			else if(tmps - n > 0){
				if(tmps - n == 3) printf("8");
				else if(tmps - n == 2) printf("8");
				else if(tmps - n == 1) printf("8");
			}else{
				printf("8");
			}
			tmps -= 4;
		}
		printf("\n");
	}
	return 0;
}
