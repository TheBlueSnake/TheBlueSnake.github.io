#include<bits/stdc++.h>
using namespace std;

int T;
int n;

int main(){
	scanf("%d", &T); while(T--){
		scanf("%d", &n);
		if(n < 31){
			printf("NO\n");
		}else{
			if(n != 36 && n != 40 && n != 44){
				printf("YES\n");
				printf("%d %d %d %d\n", n - 30, 6, 10, 14);
			}else{
				printf("YES\n");
				printf("%d %d %d %d\n", n - 31, 6, 10, 15);
			}
		}
	}
	return 0;
}
