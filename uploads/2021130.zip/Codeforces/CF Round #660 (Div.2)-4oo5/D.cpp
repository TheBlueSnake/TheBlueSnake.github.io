#include<bits/stdc++.h>
using namespace std;
const int MAXN = 200100;
const int MAXM = 400100;
typedef long long ll;

struct edge{int u, v; edge(int au = 0, int av = 0){u = au; v = av;}};

int n, a[MAXN], b[MAXN];
int vis[MAXN];
int tot, frt[MAXN], nxt[MAXM]; edge ed[MAXM];
ll deg[MAXN], f[MAXN];
vector<int> vec;

void add_edge(int u, int v){
	ed[++tot] = edge(u, v); deg[v]++;
	nxt[tot] = frt[u]; frt[u] = tot;
}
void dfs(int u, int fa){
	f[u] = a[u];
	for(int v, i = frt[u]; i; i = nxt[i]){
		v = ed[i].v;
		if(v != fa){
			dfs(v, u);
			if(f[v] > 0) f[u] += f[v];
		}
	}
}
void solve(int u, int fa){
	for(int v, i = frt[u]; i; i = nxt[i]){
		v = ed[i].v;
		if(f[v] > 0) solve(v, u);
	}
	printf("%d ", u);
	for(int v, i = frt[u]; i; i = nxt[i]){
		v = ed[i].v;
		if(f[v] <= 0) solve(v, u);
	}
}

int main(){
	scanf("%d", &n);
	for(int i = 1; i <= n; i++) scanf("%d", &a[i]);
	for(int i = 1; i <= n; i++) scanf("%d", &b[i]);
	for(int i = 1; i <= n; i++){
		if(b[i] == -1) continue;
		add_edge(b[i], i);
	}
	ll ans = 0;
	for(int i = 1; i <= n; i++){
		if(deg[i] == 0){
			dfs(i, -1);
		}
	}
	for(int i = 1; i <= n; i++){
//		printf("%d ", f[i]);
		ans += f[i];
	}
//	printf("\n");
	printf("%lld\n", ans);
	for(int i = 1; i <= n; i++){
		if(deg[i] == 0){
			solve(i, -1);
		}
	}
	printf("\n");
	return 0;
}
