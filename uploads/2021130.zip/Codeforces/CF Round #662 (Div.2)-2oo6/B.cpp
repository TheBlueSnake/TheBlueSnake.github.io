#include<bits/stdc++.h>
using namespace std;
const int MAXN = 100100;

int n, q;
int cnt[MAXN];
int eql, quadeql, pendeql, eeql;

void insert(int x){
	cnt[x]++;
	if(cnt[x] == 2) eql++;
	else if(cnt[x] == 4) eql--, quadeql++;
	else if(cnt[x] == 6) quadeql--, pendeql++;
	else if(cnt[x] == 8) pendeql--, eeql++;
}
void remove(int x){
	cnt[x]--;
	if(cnt[x] == 1) eql--;
	else if(cnt[x] == 3) eql++, quadeql--;
	else if(cnt[x] == 5) quadeql++, pendeql--;
	else if(cnt[x] == 7) pendeql++, eeql--;
}

int main(){
	scanf("%d", &n);
	memset(cnt, 0, sizeof(cnt));
	eql = quadeql = pendeql = 0;
	for(int ai, i = 1; i <= n; i++){
		scanf("%d", &ai);
		insert(ai);
	}
	scanf("%d", &q);
	for(int i = 1; i <= q; i++){
		char str[4];
		int val;
		scanf("%s %d", str, &val);
		if(str[0] == '+') insert(val);
		else remove(val);
//		printf(":%d %d %d\n", eql, quadeql, pendeql);
		if(eeql >= 1 || quadeql + pendeql + eeql >= 2) printf("YES\n"); //2square
		else if(quadeql + pendeql >= 1 && (eql + pendeql >= 2 || (pendeql == 0 && quadeql >= 2))) printf("YES\n"); //square + 1rectangle
		else printf("NO\n");
	}
	return 0;
}
