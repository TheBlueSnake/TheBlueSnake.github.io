#include<bits/stdc++.h>
using namespace std;
const int MAXN = 2100;
const int dirx[4] = {0, 0, -1, 1};
const int diry[4] = {-1, 1, 0, 0};

char str[MAXN], mp[MAXN][MAXN];
int n, m, ans, flag[2][MAXN][MAXN];

int main(){
	scanf("%d %d", &n, &m);
	for(int i = 1; i <= n; i++){
		scanf("%s", str + 1);		
		for(int j = 1; j <= m; j++){
			mp[i][j] = str[j];
		}
	}
	ans = 0;
	memset(flag, 0, sizeof(flag));
	for(int l = 2; l + l - 1 <= min(n, m); l++){
//		printf(":%d\n", l);
		for(int i = l; i <= n - l + 1; i++){
			for(int j = l; j <= m - l + 1; j++){
//				printf(":%d %d\n", i, j);
				for(int k = 0; k < 4; k++)
					flag[l & 1][i][j] = flag[l & 1][i][j] | flag[(l - 1) & 1][i + dirx[k]][j + diry[k]];
				if(flag[l & 1][i][j] == 0){
					for(int k = 0; k < 4; k++){
						if(mp[i][j] != mp[i + dirx[k]][j + diry[k]]){
							flag[l & 1][i][j] = 1;
							break;
						}
					}
				}
				ans += (flag[l & 1][i][j] == 0);
			}
		}
	}
	printf("%d\n", ans + n * m);
	return 0;
}
