#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
#define mp(x) make_pair(x)
const int MAXN = 100;
typedef long long ll;
typedef pair<int, int> pii;

int n, arr[MAXN];

int main(){int _task = 1; scanf("%d", &_task);
while(_task--){
	scanf("%d", &n);
	int lpos, rpos, sum = 0;
	for(int i = 1; i <= n; i++){
		scanf("%d", &arr[i]);
		sum += arr[i];
	}
	for(lpos = 1; lpos <= n; lpos++){
		if(arr[lpos] == 1) break;
	}
	for(rpos = n; rpos >= 1; rpos--){
		if(arr[rpos] == 1) break;
	}
	printf("%d\n", rpos - lpos + 1 - sum);
}
	return 0;
}

