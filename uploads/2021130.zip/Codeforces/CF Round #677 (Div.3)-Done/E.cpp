#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
#define mp(x) make_pair(x)
//const int MAXN = ;
typedef long long ll;
typedef pair<int, int> pii;

ll n;

int main(){int _task = 1; //scanf("%d", &_task);
while(_task--){
	scanf("%lld", &n);
	ll ans = 1;
	for(ll i = n; i >= 1; i--){
		ans = ans * i;
	}
	printf("%lld\n", ans / n * 2 / n);
}
	return 0;
}

