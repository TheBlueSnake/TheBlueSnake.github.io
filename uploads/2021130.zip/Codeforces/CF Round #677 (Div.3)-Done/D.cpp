#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
#define mp(x) make_pair(x)
const int MAXN = 5100;
typedef long long ll;
typedef pair<int, int> pii;

int n, arr[MAXN];

int main(){int _task = 1; scanf("%d", &_task);
while(_task--){
	scanf("%d", &n);
	for(int i = 1; i <= n; i++){
		scanf("%d", &arr[i]);
	}
	int rtx = 1, rty;
	for(rty = 2; rty <= n; rty++){
		if(arr[rtx] != arr[rty]){
			break;
		}
	}
	if(rty == n + 1){
		printf("NO\n");
	}else{
		printf("YES\n");
		printf("%d %d\n", rtx, rty);
		for(int i = 2; i <= n; i++){
			if(i != rty){
				printf("%d %d\n", i, arr[i] == arr[rtx] ? rty : rtx);
			}
		}
	}
}
	return 0;
}

