#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
#define mp(x) make_pair(x)
//const int MAXN = ;
typedef long long ll;
typedef pair<int, int> pii;
const int seq[] = {0, 1, 3, 6, 10};

int x;

int main(){int _task = 1; scanf("%d", &_task);
while(_task--){
	scanf("%d", &x);
	int p = x % 10;
	int dig = 0;
	while(x){
		x = x / 10;
		dig++;
	}
	printf("%d\n", (p - 1) * 10 + seq[dig]);
}
	return 0;
}

