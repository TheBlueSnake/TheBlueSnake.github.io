#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
#define mp(x) make_pair(x)
const int MAXN = 100;
const int MAXM = 100;
const int MAXK = 100;
typedef long long ll;
typedef pair<int, int> pii;

int n, m, s;
int arr[MAXM];
int f[MAXN][MAXM][MAXK], g[MAXK];

int main(){int _task = 1; //scanf("%d", &_task);
while(_task--){
	memset(g, 0x80, sizeof(g));
	g[0] = 0;
	memset(f, 0x80, sizeof(f));
	scanf("%d %d %d", &n, &m, &s);
	for(int i = 0; i <= m; i++) f[i][0][0] = 0;
	for(int ii = 1; ii <= n; ii++){
		for(int i = 1; i <= m; i++){
			scanf("%d", &arr[i]);
		}
		for(int i = 0; i <= m; i++){
			for(int j = 0; j <= m / 2; j++){
				for(int k = 0; k < s; k++){
					f[i][j][k] = -INF;
				}
			}
		}
		for(int i = 0; i <= m; i++) f[i][0][0] = 0;
		for(int i = 0; i < s; i++) f[0][0][i] = g[i];
		for(int i = 1; i <= m; i++){
			for(int k = 0; k < s; k++) f[i][0][k] = f[i - 1][0][k];
			for(int j = 1; j <= m / 2; j++){
				for(int k = 0; k < s; k++){
					f[i][j][k] = max(f[i - 1][j][k], f[i - 1][j - 1][((k - arr[i] % s) % s + s) % s] + arr[i]);
//					printf(":f[%d][%d][%d] = %d\n", i, j, k, f[i][j][k]);
				}
			}
		}
		for(int k = 0; k < s; k++){
			int maxi = -INF;
			for(int j = 0; j <= m / 2; j++){
				maxi = max(maxi, f[m][j][k]);
//				printf(":f[%d][%d][%d] = %d\n", m, j, k, f[m][j][k]);
			}
			g[k] = maxi;
//			printf(":g[%d] = %d\n", k, g[k]);
		}
	}
	printf("%d\n", g[0]);
}
	return 0;
}

