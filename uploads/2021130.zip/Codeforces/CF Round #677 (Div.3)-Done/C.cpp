#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
#define mp(x) make_pair(x)
const int MAXN = 300100;
typedef long long ll;
typedef pair<int, int> pii;

int n, arr[MAXN], ans;

int main(){int _task = 1; scanf("%d", &_task);
while(_task--){
	scanf("%d", &n);
	ans = 0;
	for(int i = 1; i <= n; i++){
		scanf("%d", &arr[i]);
	}
	int flag = 0;
	for(int i = 1; i <= n; i++){
		if(arr[i] != arr[1]){
			flag = 1;
			break;
		}
	}
	if(!flag) printf("-1\n");
	else{
		int pos = -1;
		arr[0] = arr[n + 1] = INF;
		for(int i = 1; i <= n; i++){
			if(arr[i] > ans && (arr[i - 1] < arr[i] || arr[i + 1] < arr[i])){
				ans = arr[i];
				pos = i;
			}
		}
		printf("%d\n", pos);
	}
}
	return 0;
}

