#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFll 0x3f3f3f3f3f3f3f3fll
#define mp(x, y) make_pair(x, y)
const int MAXN = 1100;
const int MAXM = 2100;
typedef long long ll;
typedef pair<int, int> pii;

struct edge{int u, v, w; edge(int au = 0, int av = 0, int aw = 0){u = au; v = av; w = aw;}};

int n, m, k;
int x[MAXN], y[MAXN];
int tot, frt[MAXN], nxt[MAXM]; edge ed[MAXM];
int a[MAXN], b[MAXN];
int dis[MAXN][MAXN], vis[MAXN];

void add_edge(int u, int v, int w){
	ed[++tot] = edge(u, v, w);
	nxt[tot] = frt[u]; frt[u] = tot;
}

void dijkstra(int s){
	int u, v, w;
	priority_queue<pii, vector<pii>, greater<pii> > que;
	memset(dis[s], 0x3f, sizeof(dis[s]));
	memset(vis, 0, sizeof(vis));
	que.push(mp(0, s));
	dis[s][s] = 0;
	while(!que.empty()){
		u = que.top().second; que.pop();
		if(!vis[u]){
			vis[u] = 1;
			for(int i = frt[u]; i; i = nxt[i]){
				v = ed[i].v;
				w = ed[i].w;
				if(dis[s][v] > dis[s][u] + w){
					dis[s][v] = dis[s][u] + w;
					que.push(mp(dis[s][v], v));
				}
			}
		}
	}
}


int main(){int _task = 1; //scanf("%d", &_task);
while(_task--){
	scanf("%d %d %d", &n, &m, &k);
	for(int w, i = 1; i <= m; i++){
		scanf("%d %d %d", &x[i], &y[i], &w);
		add_edge(x[i], y[i], w);
		add_edge(y[i], x[i], w);
	}
	for(int i = 1; i <= k; i++){
		scanf("%d %d", &a[i], &b[i]);
	}
	for(int i = 1; i <= n; i++){
		dijkstra(i);
	}
	int ans = 0, tmps;
	for(int i = 1; i <= k; i++){
		ans += dis[a[i]][b[i]];
	}
	for(int i = 1; i <= m; i++){
		tmps = 0;
		for(int j = 1; j <= k; j++){
			tmps += min(dis[a[j]][b[j]], min(dis[a[j]][x[i]] + dis[y[i]][b[j]], dis[a[j]][y[i]] + dis[x[i]][b[j]]));
		}
		ans = min(ans, tmps);
	}
	printf("%d\n", ans);
}
	return 0;
}

