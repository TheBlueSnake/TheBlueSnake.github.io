#include<bits/stdc++.h>
using namespace std;
const int MAXN = 100100;

int T;
int n, arr[MAXN];

int main(){
	scanf("%d", &T); while(T--){
		scanf("%d", &n);
		for(int i = 1; i <= n; i++) scanf("%d", &arr[i]);
		bool flag = false;
		for(int i = 1; i <= n; i++){
			if(arr[i] == 1) flag ^= 1;
			else{
				flag ^= 1;
				break;
			}
		}
		printf("%s\n", flag ? "First" : "Second");
	}
	return 0;
}
