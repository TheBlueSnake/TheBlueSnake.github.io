#include<bits/stdc++.h>
using namespace std;
const int MAXN = 4100;

int T;
int n, arr[MAXN], pos[MAXN], exist[MAXN];
int blk[MAXN], f[MAXN][MAXN];

int main(){
	scanf("%d", &T); while(T--){
		scanf("%d", &n); n <<= 1;
		for(int i = 1; i <= n; i++){
			scanf("%d", &arr[i]);
			pos[arr[i]] = i;
		}
		for(int i = 1; i <= n; i++) exist[i] = -1;
		blk[0] = 0;
		for(int prev = n + 1, i = n; i >= 1; i--){
			if(exist[i] == -1){
				exist[i] = 1;
				for(int j = pos[i]; j <= prev - 1; j++)
					exist[arr[j]] = 1;
				blk[++blk[0]] = prev - pos[i];
				prev = pos[i];
			}
		}
//		printf(":");
//		for(int i = 1; i <= blk[0]; i++)
//			printf("%d ", blk[i]);
//		printf("\n");
		f[0][0] = 1;
		for(int i = 1; i <= blk[0]; i++){
			for(int j = 0; j <= (n >> 1); j++){
				f[i][j] = f[i - 1][j];
				if(j - blk[i] >= 0) f[i][j] |= f[i - 1][j - blk[i]];
			}
		}
		printf("%s\n", f[blk[0]][n >> 1] ? "YES" : "NO");
	}
	return 0;
}
