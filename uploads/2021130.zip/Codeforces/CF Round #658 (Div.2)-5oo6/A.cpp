#include<bits/stdc++.h>
using namespace std;
const int MAXN = 1100;

int t;
int n, m, a[MAXN], b[MAXN];

bool cmp(const int &x, const int &y){return x < y;}

int main(){
	scanf("%d", &t); while(t--){
		scanf("%d %d", &n, &m);
		for(int i = 1; i <= n; i++) scanf("%d", &a[i]);
		for(int i = 1; i <= m; i++) scanf("%d", &b[i]);
		bool flag = false;
		for(int i = 1; i <= n; i++){
			for(int j = 1; j <= m; j++){
				if(a[i] == b[j]){
				 	flag = true;
				 	printf("YES\n");
				 	printf("%d %d\n", 1, a[i]);
				 	break;
				}
			}
			if(flag) break;
		}
		if(!flag) printf("NO\n");
	}
	return 0;
}
