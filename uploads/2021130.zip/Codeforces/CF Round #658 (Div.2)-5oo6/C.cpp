#include<bits/stdc++.h>
using namespace std;
const int MAXN = 100100;

int T;
int n, firstpos;
char arr[MAXN], b[MAXN];
int ans, rev; queue<int> que, str;

int chk(int val){
	if(!rev) return firstpos + val - 1;
	else return firstpos - val + 1;
}

int main(){
//	freopen("C.in", "r", stdin);
//	freopen("C.out", "w", stdout);
	scanf("%d", &T); int tmps = T; while(T--){
		scanf("%d", &n);
		scanf("%s", arr + 1);
		scanf("%s", b + 1);
		firstpos = 1;
		ans = rev = 0;
		while(!que.empty()) que.pop();
		for(int i = n; i >= 1; i--){
			if(((arr[chk(i)] - '0') ^ (rev)) != (b[i] - '0')){
//				if(tmps == 1) printf(":inside %d\n", i);
//				printf("%d %d %d\n", i, ans, rev);
				if(((arr[chk(1)] - '0') ^ (rev)) == (b[i] - '0')){
					que.push(1);
					ans++;
				}
				firstpos = chk(i);
				que.push(i);
				ans++; rev ^= 1;
			}
		}
		printf("%d ", ans);
		while(!que.empty()){
			printf("%d ", que.front());
			que.pop();
		}
		printf("\n");
	}
	return 0;
}
