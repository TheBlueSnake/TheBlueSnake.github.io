#include<bits/stdc++.h>
using namespace std;

int main(){
	freopen("C.in", "w", stdout);
	srand((unsigned)time(NULL));
	printf("1\n");
	int n = 25;
	printf("%d\n", n);
	for(int i = 1; i <= n; i++) printf("%d", rand() & 1); printf("\n");
	for(int i = 1; i <= n; i++) printf("%d", rand() & 1); printf("\n");
	return 0;
}
