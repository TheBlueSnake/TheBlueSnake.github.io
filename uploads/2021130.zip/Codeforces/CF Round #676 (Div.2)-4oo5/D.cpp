#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
//const int MAXN = ;
typedef long long ll;

ll x, y;
ll c[10];

int main(){int _task = 1; scanf("%d", &_task);
	while(_task--){
		scanf("%lld %lld", &x, &y);
		for(int i = 1; i <= 6; i++){
			scanf("%lld", &c[i]);
		}
		if(x == 0 && y == 0){
			printf("%lld\n", 0ll);
			continue;
		}
		ll ans = INFL;
		if(x <= 0 && y <= 0){
			x = -x, y = -y;
			ans = min(ans, x * c[3] + y * c[5]);
			if(x >= y) ans = min(ans, y * c[4] + (x - y) * c[3] );
			else ans = min(ans, x * c[4] + (y - x) * c[5]);
			if(x >= y) ans = min(ans, x * c[4] + (x - y) * c[2]);
			else ans = min(ans, y * c[4] + (y - x) * c[6]);
		}
		else if(x <= 0 && y>= 0){
			x = -x;
			ans = min(ans, x * c[3] + y * c[2]);
			ans = min(ans, x * c[4] + (x + y) * c[2]);
			ans = min(ans, y * c[1] + (x + y) * c[3]);
		}
		else if(x >= 0 && y <= 0){
			y = -y;
			ans = min(ans, x * c[6] + y * c[5]);
			ans = min(ans, x * c[1] + (x + y) * c[5]);
			ans = min(ans, y * c[4] + (x + y) * c[6]);
		}
		else{
			ans = min(ans, x * c[6] + y * c[2]);
			if(x >= y) ans = min(ans, y * c[1] + (x - y) * c[6]);
			else ans = min(ans, x * c[1] + (y - x) * c[2]);
			if(x >= y) ans = min(ans, x * c[1] + (x - y) * c[5]);
			else ans = min(ans, y * c[1] + (y - x) * c[3]);
		}
		printf("%lld\n",ans);
	}
	return 0;
}

