#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
const int MAXN = 100100;
typedef long long ll;

int n;
char str[MAXN];

int main(){
	scanf("%s", str + 1);
	n = strlen(str + 1);
	printf("3\n");
	printf("L %d\n", 2); n++;
	printf("R %d\n", 2); n += n - 2;
	printf("R %d\n", n - 1);
	return 0;
}

