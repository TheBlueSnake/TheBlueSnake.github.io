#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
//const int MAXN = ;
typedef long long ll;

int a, b;

int main(){int _task = 1; scanf("%d", &_task);
	while(_task--){
		int val = 1, ans = 0;
		scanf("%d %d", &a, &b);
		while(a || b){
			if((a & 1) ^ (b & 1) == 1){
				ans += val;
			}
			val <<= 1;
			a >>= 1; b >>= 1;
		}
		printf("%d\n", ans);
	}
	return 0;
}

