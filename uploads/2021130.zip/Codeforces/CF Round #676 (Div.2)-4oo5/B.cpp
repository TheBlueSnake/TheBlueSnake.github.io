#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define INFL 0x3f3f3f3f3f3f3f3fll
const int MAXN = 210;
typedef long long ll;

int n;
char str[MAXN];
int mp[MAXN][MAXN];

int main(){int _task = 1; scanf("%d", &_task);
	while(_task--){
		scanf("%d", &n);
		for(int i = 1; i <= n; i++){
			scanf("%s", str + 1);
			for(int j = 1; j <= n; j++){
				if(str[j] == 'S') mp[i][j] = -1;
				if(str[j] == 'F') mp[i][j] = -2;
				else mp[i][j] = str[j] - '0'; 
			}
		}
		if(mp[1][2] == mp[2][1] && mp[n][n - 1] == mp[n - 1][n]){
			if(mp[1][2] == mp[n][n - 1]){
				printf("2\n1 2\n2 1\n");
			}else{
				printf("0\n");
			}
		}else if(mp[1][2] == mp[2][1] && mp[n][n - 1] != mp[n - 1][n]){
			if(mp[1][2] == mp[n][n - 1]){
				printf("1\n%d %d\n", n, n - 1);
			}else{
				printf("1\n%d %d\n", n - 1, n);
			}
		}else if(mp[1][2] != mp[2][1] && mp[n][n - 1] == mp[n - 1][n]){
			if(mp[1][2] == mp[n][n - 1]){
				printf("1\n1 2\n");
			}else{
				printf("1\n2 1\n");
			}
		}else{
			if(mp[1][2] == mp[n][n - 1]){
				printf("2\n1 2\n%d %d\n", n - 1, n);
			}else{
				printf("2\n2 1\n%d %d\n", n - 1, n);
			}
		}
	}
	return 0;
}

